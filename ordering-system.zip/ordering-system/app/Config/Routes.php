<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ---- Guest / public ----
$routes->get('/', 'Guest\HomeController::index');
$routes->get('menu', 'Guest\MenuController::index');
$routes->get('menu/(:num)', 'Guest\MenuController::show/$1');
$routes->get('about', 'Guest\AboutController::index');

// ---- Auth ----
$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::attemptLogin');
$routes->get('register', 'AuthController::register');
$routes->post('register', 'AuthController::attemptRegister');
$routes->get('logout', 'AuthController::logout');

// ---- Customer (must be signed in with role=customer) ----
$routes->group('customer', ['filter' => 'customerAuth'], function ($routes) {
    $routes->get('home', 'Customer\HomeController::index');
    $routes->get('menu', 'Customer\MenuController::index');
    $routes->get('menu/(:num)', 'Customer\MenuController::show/$1');
    $routes->post('cart/add/(:num)', 'Customer\MenuController::addToCart/$1');

    $routes->get('cart', 'Customer\CartController::index');
    $routes->post('cart/update/(:num)', 'Customer\CartController::updateQty/$1');
    $routes->post('cart/remove/(:num)', 'Customer\CartController::remove/$1');

    $routes->get('checkout', 'Customer\CheckoutController::index');
    $routes->post('checkout', 'Customer\CheckoutController::placeOrder');
    $routes->get('checkout/success/(:segment)', 'Customer\CheckoutController::success/$1');

    $routes->get('track-order', 'Customer\TrackOrderController::index');
    $routes->post('track-order', 'Customer\TrackOrderController::track');

    $routes->get('order/view/(:segment)', 'Customer\OrderController::view/$1');

    $routes->get('history', 'Customer\HistoryController::index');
    $routes->post('history/cancel/(:segment)', 'Customer\HistoryController::cancel/$1');

    $routes->get('profile', 'Customer\ProfileController::index');
    $routes->post('profile', 'Customer\ProfileController::update');
});

// ---- Admin (must be signed in with role=admin) ----
$routes->group('admin', ['filter' => 'adminAuth'], function ($routes) {
    $routes->get('dashboard', 'Admin\DashboardController::index');

    $routes->get('orders', 'Admin\OrdersController::index');
    $routes->post('orders/update-status/(:segment)', 'Admin\OrdersController::updateStatus/$1');
    $routes->get('orders/view/(:segment)', 'Admin\OrdersController::viewOrder/$1');
    $routes->get('orders/payment/(:segment)', 'Admin\OrdersController::paymentDetails/$1');
    $routes->post('orders/verify-payment/(:segment)', 'Admin\OrdersController::verifyPayment/$1');
    $routes->post('orders/refund/(:segment)', 'Admin\OrdersController::refund/$1');

    $routes->get('menu', 'Admin\MenuController::index');
    $routes->get('menu/create', 'Admin\MenuController::create');
    $routes->post('menu/create', 'Admin\MenuController::store');
    $routes->get('menu/edit/(:num)', 'Admin\MenuController::edit/$1');
    $routes->post('menu/edit/(:num)', 'Admin\MenuController::update/$1');
    $routes->post('menu/delete/(:num)', 'Admin\MenuController::delete/$1');
    $routes->post('menu/unavailable/(:num)', 'Admin\MenuController::unavailable/$1');

    $routes->get('inventory', 'Admin\InventoryController::index');
    $routes->get('inventory/(:num)', 'Admin\InventoryController::manage/$1');
    $routes->post('inventory/restock/(:num)', 'Admin\InventoryController::restock/$1');
    $routes->post('inventory/set/(:num)', 'Admin\InventoryController::setCount/$1');
    $routes->post('inventory/threshold/(:num)', 'Admin\InventoryController::threshold/$1');
    $routes->post('inventory/untrack/(:num)', 'Admin\InventoryController::untrack/$1');

    $routes->get('customers', 'Admin\CustomersController::index');

    $routes->get('reports', 'Admin\ReportsController::index');
    $routes->get('reports/export-csv', 'Admin\ReportsController::exportCsv');
    $routes->get('reports/export-pdf', 'Admin\ReportsController::exportPdf');
});