<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class CustomersController extends BaseController
{
    public function index()
    {
        $q         = $this->request->getGet('q');
        $customers = DataStore::deriveCustomers();

        if (! empty($q)) {
            $needle    = mb_strtolower($q);
            $customers = array_values(array_filter(
                $customers,
                fn ($c) => str_contains(mb_strtolower($c['name']), $needle) || str_contains(mb_strtolower($c['email']), $needle)
            ));
        }

        $data = [
            'title'     => 'List of Customer — Admin',
            'active'    => 'customers',
            'q'         => $q,
            'customers' => $customers,
        ];

        return view('admin/customers', $data);
    }
}