<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class DashboardController extends BaseController
{
    public function index()
    {
        $orders    = DataStore::getOrders();
        $menu      = DataStore::getMenu();
        $customers = DataStore::deriveCustomers();

        $recent = array_slice(array_reverse(array_values(array_filter($orders, fn ($o) => $o['status'] !== 'delivered'))), 0, 4);

        $period    = $this->request->getGet('period') ?? 'all';
        $itemStats = DataStore::computeItemStats($period);
        $revenues  = array_column($itemStats, 'revenue');
        $maxRev    = $revenues ? max(1, max($revenues)) : 1;
        foreach ($itemStats as &$s) {
            $s['pct'] = round($s['revenue'] / $maxRev * 100, 1);
        }
        unset($s);

        $data = [
            'title'         => 'Dashboard — Admin',
            'active'        => 'dashboard',
            'totalRevenue'  => array_sum(array_column($orders, 'total')),
            'totalOrders'   => count($orders),
            'pendingCount'  => count(array_filter($orders, fn ($o) => $o['status'] === 'pending')),
            'menuCount'     => count($menu),
            'availCount'    => count(array_filter($menu, fn ($p) => ($p['avail'] ?? true) !== false)),
            'customerCount' => count($customers),
            'itemStats'     => $itemStats,
            'recent'        => $recent,
            'period'        => $period,
            'lowStockItems' => array_values(array_filter($menu, fn ($p) => in_array(DataStore::stockStatus($p), ['low', 'out'], true))),
        ];

        return view('admin/dashboard', $data);
    }
}