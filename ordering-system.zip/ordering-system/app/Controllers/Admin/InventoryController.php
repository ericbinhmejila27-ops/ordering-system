<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class InventoryController extends BaseController
{
    public function index()
    {
        $items  = DataStore::getInventory();
        $filter = $this->request->getGet('filter') ?? 'all';

        $tracked = array_filter($items, fn ($p) => $p['stockStatus'] !== 'untracked');
        $low     = array_filter($items, fn ($p) => $p['stockStatus'] === 'low');
        $out     = array_filter($items, fn ($p) => $p['stockStatus'] === 'out');

        $list = match ($filter) {
            'low'       => array_values($low),
            'out'       => array_values($out),
            'untracked' => array_values(array_filter($items, fn ($p) => $p['stockStatus'] === 'untracked')),
            default     => $items,
        };

        $data = [
            'title'        => 'Inventory — Admin',
            'active'       => 'inventory',
            'items'        => $list,
            'filter'       => $filter,
            'trackedCount' => count($tracked),
            'unitsOnHand'  => array_sum(array_map(fn ($p) => max(0, (int) $p['stock']), $tracked)),
            'lowCount'     => count($low),
            'outCount'     => count($out),
            'logs'         => DataStore::getInventoryLogs(null, 30),
        ];

        return view('admin/inventory', $data);
    }

    public function manage($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item) {
            return redirect()->to('/admin/inventory')->with('error', 'Item not found.');
        }
        $item['stockStatus'] = DataStore::stockStatus($item);

        return view('admin/inventory_item', [
            'title'  => $item['name'] . ' — Inventory — Admin',
            'active' => 'inventory',
            'item'   => $item,
            'logs'   => DataStore::getInventoryLogs((int) $id, 100),
        ]);
    }

    public function restock($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        $qty  = (int) $this->request->getPost('qty');
        if (! $item) {
            return redirect()->to('/admin/inventory')->with('error', 'Item not found.');
        }
        if ($qty <= 0) {
            return redirect()->back()->with('error', 'Enter how many to add (at least 1).');
        }

        DataStore::restock((int) $id, $qty, trim((string) $this->request->getPost('note')));

        return redirect()->back()->with('message', "Added {$qty} to {$item['name']}");
    }

    public function setCount($id)
    {
        $item  = DataStore::findMenuItem((int) $id);
        $raw   = $this->request->getPost('count');
        $count = (int) $raw;
        if (! $item) {
            return redirect()->to('/admin/inventory')->with('error', 'Item not found.');
        }
        if ($raw === null || $raw === '' || $count < 0) {
            return redirect()->back()->with('error', 'Enter the actual count (0 or more).');
        }

        $reason = trim((string) $this->request->getPost('reason'));
        $note   = trim((string) $this->request->getPost('note'));
        $full   = trim($reason . ($reason !== '' && $note !== '' ? ' — ' : '') . $note);

        $wasTracked = $item['stock'] !== null;
        DataStore::setStock((int) $id, $count, $full !== '' ? $full : ($wasTracked ? 'Count correction' : 'Started tracking'));

        $msg = $wasTracked
            ? "{$item['name']} stock set to {$count}"
            : "Now tracking {$item['name']} — {$count} in stock";

        return redirect()->back()->with('message', $msg);
    }

    public function threshold($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item) {
            return redirect()->to('/admin/inventory')->with('error', 'Item not found.');
        }
        $value = max(0, (int) $this->request->getPost('low_stock'));
        DataStore::setLowStock((int) $id, $value);

        return redirect()->back()->with('message', "Low-stock alert for {$item['name']} set to {$value}");
    }

    public function untrack($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item) {
            return redirect()->to('/admin/inventory')->with('error', 'Item not found.');
        }
        DataStore::stopTracking((int) $id);

        return redirect()->to('/admin/inventory')->with('message', "{$item['name']} is no longer stock-tracked");
    }
}