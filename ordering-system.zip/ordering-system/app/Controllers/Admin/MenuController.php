<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class MenuController extends BaseController
{
    public function index()
    {
        $data = [
            'title'  => 'List of Menu — Admin',
            'active' => 'menu',
            'menu'   => DataStore::getMenu(),
        ];

        return view('admin/menu', $data);
    }

    public function create()
    {
        $data = [
            'title'  => 'Add Item — Admin',
            'active' => 'menu',
            'item'   => null,
            'categories' => DataStore::getCategories(),
        ];

        return view('admin/menu_form', $data);
    }

    public function edit($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item) {
            return redirect()->to('/admin/menu')->with('error', 'Item not found.');
        }

        $data = [
            'title'  => 'Edit Item — Admin',
            'active' => 'menu',
            'item'   => $item,
            'categories' => DataStore::getCategories(),
        ];

        return view('admin/menu_form', $data);
    }

    private function fromPost(): array
    {
        $name  = trim((string) $this->request->getPost('name'));
        $cat   = $this->request->getPost('cat') ?: 'savory';
        $price = (float) $this->request->getPost('price');
        $emoji = trim((string) $this->request->getPost('emoji')) ?: '🍽️';
        $badge = $this->request->getPost('badge') ?: null;
        $desc  = trim((string) $this->request->getPost('desc'));
        $avail = (bool) $this->request->getPost('avail');

        return compact('name', 'cat', 'price', 'emoji', 'badge', 'desc', 'avail');
    }

    /**
     * Handles an optional menu photo and returns its relative public path.
     */
    private function handleImageUpload(): ?string
    {
        $file = $this->request->getFile('photo');
        if ($file && $file->isValid() && ! $file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(FCPATH . 'assets/uploads/menu', $newName);

            return 'assets/uploads/menu/' . $newName;
        }

        return null;
    }

    public function store()
    {
        $fields = $this->fromPost();
        if ($fields['name'] === '') {
            return redirect()->back()->withInput()->with('error', 'Enter an item name.');
        }
        if ($fields['price'] <= 0) {
            return redirect()->back()->withInput()->with('error', 'Enter a valid price.');
        }

        $img = $this->handleImageUpload() ?? '';

        $newId = DataStore::addMenuItem(array_merge($fields, ['img' => $img]));

        // Optional starting stock — blank means not tracked (no limit).
        $startStock = trim((string) $this->request->getPost('stock'));
        if ($startStock !== '' && (int) $startStock >= 0) {
            DataStore::setStock($newId, (int) $startStock, 'Starting stock');
        }

        return redirect()->to('/admin/menu')->with('message', "{$fields['name']} added to menu");
    }

    public function update($id)
    {
        // Editing only allows price and availability to change; name,
        // category, emoji, badge, photo, and description are locked once
        // an item exists so they can't be altered from the edit form.
        $price = (float) $this->request->getPost('price');
        $avail = (bool) $this->request->getPost('avail');
        if ($price <= 0) {
            return redirect()->back()->withInput()->with('error', 'Enter a valid price.');
        }

        $current = DataStore::findMenuItem((int) $id);
        if ($avail && $current && $current['stock'] !== null && $current['stock'] <= 0) {
            return redirect()->back()->withInput()->with('error', "{$current['name']} has 0 stock. Restock it in Inventory first.");
        }

        if (! $current) {
            return redirect()->to('/admin/menu')->with('error', 'Item not found.');
        }
        DataStore::updateMenuItem((int) $id, ['price' => $price, 'avail' => $avail]);

        return redirect()->to('/admin/menu')->with('message', "{$current['name']} updated");
    }

    public function unavailable($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item) {
            return redirect()->to('/admin/menu')->with('error', 'Item not found.');
        }
        DataStore::setAvailability((int) $id, false);

        return redirect()->to('/admin/menu')->with('message', "{$item['name']} marked as not available");
    }

    public function delete($id)
    {
        $item = DataStore::findMenuItem((int) $id);
        if (! $item || ! DataStore::archiveMenuItem((int) $id)) {
            return redirect()->to('/admin/menu')->with('error', 'Item not found.');
        }

        $name = $item['name'] ?? 'Item';

        return redirect()->to('/admin/menu')->with('message', "{$name} removed from menu");
    }
}