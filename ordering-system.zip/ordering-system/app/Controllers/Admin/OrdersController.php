<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class OrdersController extends BaseController
{
    public function index()
    {
        $status = $this->request->getGet('status') ?? 'Pending';
        $orders = array_reverse(array_values(array_filter(
            DataStore::getOrders(),
            fn ($o) => $o['status'] !== 'delivered' && $o['status'] !== 'cancelled'
        )));

        $filtered = array_values(array_filter($orders, fn ($o) => $o['status'] === strtolower($status)));

        $data = [
            'title'  => 'List of Order — Admin',
            'active' => 'orders',
            'status' => $status,
            'orders' => $filtered,
        ];

        return view('admin/orders', $data);
    }

    public function updateStatus($orderId)
    {
        $newStatus = (string) $this->request->getPost('status');
        if (! DataStore::setOrderStatus((string) $orderId, $newStatus)) {
            $order = DataStore::findOrder((string) $orderId);
            $currentStatus = $order['status'] ?? 'not found';
            return redirect()->back()->with('error', "Can't move {$orderId} from {$currentStatus} to \"{$newStatus}\".");
        }

        return redirect()->back()->with('message', "{$orderId} marked as {$newStatus}");
    }

    public function viewOrder($orderId)
    {
        $order = DataStore::findOrder($orderId);
        if (! $order) {
            return redirect()->to('/admin/orders')->with('error', 'Order not found.');
        }

        // If this view was opened from Reports, "back" should return there
        // (keeping whatever filters/tab/page were active) instead of
        // always jumping to the Orders list.
        $referer     = $this->request->getServer('HTTP_REFERER') ?? '';
        $fromReports = strpos($referer, site_url('admin/reports')) !== false;
        $backUrl     = $fromReports ? $referer : site_url('admin/orders');

        return view('admin/order_receipt', [
            'title'   => $orderId . ' — Admin',
            'active'  => $fromReports ? 'reports' : 'orders',
            'o'       => $order,
            'backUrl' => $backUrl,
        ]);
    }

    public function paymentDetails($orderId)
    {
        $order = DataStore::findOrder($orderId);
        if (! $order) {
            return redirect()->to('/admin/orders')->with('error', 'Order not found.');
        }

        return view('admin/payment_details', [
            'title'  => $orderId . ' — Payment — Admin',
            'active' => 'orders',
            'o'      => $order,
        ]);
    }

    public function verifyPayment($orderId)
    {
        if (! DataStore::setPaymentStatus((string) $orderId, 'verified')) {
            return redirect()->back()->with('error', 'Payment not found or already updated.');
        }

        return redirect()->back()->with('message', "{$orderId} marked as paid");
    }

    public function refund($orderId)
    {
        if (! DataStore::setRefundStatus((string) $orderId, 'refunded')) {
            return redirect()->back()->with('error', 'Payment not found or refund status could not be updated.');
        }

        return redirect()->back()->with('message', "{$orderId} marked as refunded");
    }
}