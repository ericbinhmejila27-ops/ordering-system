<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class ReportsController extends BaseController
{
    private const PER_PAGE = 10;

    /**
     * Applies the Date From / Date To / Status / Payment / Delivery
     * filters (shared by the page, CSV export, and PDF export so all
     * three always agree on the same result set).
     */
    private function filteredOrders(): array
    {
        $tab      = $this->request->getGet('tab') ?: 'All';
        $status   = $this->request->getGet('status') ?: '';
        $payment  = $this->request->getGet('payment') ?: '';
        $delivery = $this->request->getGet('delivery') ?: '';
        $dateFrom = $this->request->getGet('date_from') ?: '';
        $dateTo   = $this->request->getGet('date_to') ?: '';
        $search   = trim((string) ($this->request->getGet('q') ?? ''));

        // The ALL / PAID / COMPLETE / CANCELLED tabs are just a shortcut
        // for the Status dropdown — clicking a tab sets the same filter.
        if ($tab === 'Paid') {
            $status = 'paid';
        } elseif ($tab === 'Complete') {
            $status = 'complete';
        } elseif ($tab === 'Cancelled') {
            $status = 'cancelled';
        }

        $orders = DataStore::getOrders();

        if ($status !== '') {
            $orders = array_filter($orders, fn ($o) => DataStore::reportStatus($o) === $status);
        }
        if ($payment !== '') {
            $orders = array_filter($orders, fn ($o) => ($o['paymentMethod'] ?? 'cod') === $payment);
        }
        if ($delivery !== '') {
            $orders = array_filter($orders, fn ($o) => ($o['del'] ?? '') === $delivery);
        }
        if ($dateFrom !== '') {
            $from   = strtotime($dateFrom);
            $orders = array_filter($orders, fn ($o) => strtotime($o['dateTime']) >= $from);
        }
        if ($dateTo !== '') {
            $to     = strtotime($dateTo . ' 23:59:59');
            $orders = array_filter($orders, fn ($o) => strtotime($o['dateTime']) <= $to);
        }

        if ($search !== '') {
            // Matches order ID, customer name, email, phone, items, or
            // payment reference number (case-insensitive).
            $orders = array_filter($orders, function ($o) use ($search) {
                foreach (['id', 'custName', 'custEmail', 'custPhone', 'itemsText', 'paymentRef'] as $field) {
                    if (mb_stripos((string) ($o[$field] ?? ''), $search) !== false) {
                        return true;
                    }
                }

                return false;
            });
        }

        return array_reverse(array_values($orders));
    }

    public function index()
    {
        $allOrders = DataStore::getOrders();
        $delivered = array_values(array_filter($allOrders, fn ($o) => $o['status'] === 'delivered'));
        $cancelled = array_values(array_filter($allOrders, fn ($o) => $o['status'] === 'cancelled'));
        $revenue   = array_sum(array_column($delivered, 'total'));

        $filtered = $this->filteredOrders();

        $page      = max(1, (int) ($this->request->getGet('page') ?? 1));
        $totalRows = count($filtered);
        $lastPage  = max(1, (int) ceil($totalRows / self::PER_PAGE));
        $page      = min($page, $lastPage);
        $rows      = array_slice($filtered, ($page - 1) * self::PER_PAGE, self::PER_PAGE);

        // Preserve every active filter across pagination / tab / export links.
        $query = $this->request->getGet() ?? [];

        $data = [
            'title'            => 'List of Transaction Reports — Admin',
            'active'           => 'reports',
            'deliveryMethods'  => DataStore::deliveryMethods(),
            'tab'              => $this->request->getGet('tab') ?: 'All',
            'filters'          => [
                'status'    => $this->request->getGet('status') ?: '',
                'payment'   => $this->request->getGet('payment') ?: '',
                'delivery'  => $this->request->getGet('delivery') ?: '',
                'date_from' => $this->request->getGet('date_from') ?: '',
                'date_to'   => $this->request->getGet('date_to') ?: '',
                'q'         => trim((string) ($this->request->getGet('q') ?? '')),
            ],
            'deliveredCount'   => count($delivered),
            'cancelledCount'   => count($cancelled),
            'deliveredRevenue' => $revenue,
            'avgOrderValue'    => $delivered ? round($revenue / count($delivered)) : 0,
            'customerCount'    => count(DataStore::deriveCustomers()),
            'rows'             => $rows,
            'totalRows'        => $totalRows,
            'page'             => $page,
            'lastPage'         => $lastPage,
            'query'            => $query,
        ];

        return view('admin/reports', $data);
    }

    private function csvRows(array $orders): array
    {
        $header = ['Order ID', 'Customer', 'Email', 'Phone', 'Items', 'Delivery', 'Total', 'Report Status', 'Payment Method', 'Amount Paid', 'Balance', 'Payment Ref', 'Date'];
        $rows   = array_map(fn ($o) => [
            $o['id'], $o['custName'], $o['custEmail'], $o['custPhone'], $o['itemsText'], $o['del'],
            $o['total'], ucfirst(DataStore::reportStatus($o)), $o['paymentLabel'] ?? 'Cash on Delivery',
            $o['amountPaid'] ?? 0, $o['balance'] ?? $o['total'], $o['paymentRef'] ?? '', $o['date'],
        ], $orders);

        return [$header, ...$rows];
    }

    public function exportCsv()
    {
        $orders = $this->filteredOrders();

        $csv = '';
        foreach ($this->csvRows($orders) as $row) {
            $csv .= implode(',', array_map(fn ($v) => '"' . str_replace('"', '""', (string) $v) . '"', $row)) . "\r\n";
        }

        return $this->response
            ->setHeader('Content-Type', 'text/csv')
            ->setHeader('Content-Disposition', 'attachment; filename="alyanah-transaction-report-' . date('Y-m-d') . '.csv"')
            ->setBody($csv);
    }

    /**
     * No PDF library dependency required: renders a print-friendly HTML
     * page and auto-opens the browser's print dialog, where "Save as PDF"
     * produces the file.
     */
    public function exportPdf()
    {
        $orders = $this->filteredOrders();

        return view('admin/reports_pdf', [
            'orders'   => $orders,
            'total'    => array_sum(array_column($orders, 'total')),
            'generated' => date('F j, Y g:ia'),
        ]);
    }
}