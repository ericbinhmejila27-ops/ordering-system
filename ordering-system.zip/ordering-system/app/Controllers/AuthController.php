<?php

namespace App\Controllers;

use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class AuthController extends BaseController
{
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            $role = session()->get('role');

            return redirect()->to($role === 'admin' ? '/admin/dashboard' : '/customer/home');
        }

        return view('auth/login', [
            'title' => "Sign in — Alyanah's Homemade",
        ]);
    }

    public function attemptLogin()
    {
        $email    = trim((string) $this->request->getPost('email'));
        $password = (string) $this->request->getPost('password');

        if ($email === '' || ! str_contains($email, '@')) {
            return redirect()->to('/login')->withInput()->with('error', 'Enter a valid email address.');
        }
        if (strlen($password) < 6) {
            return redirect()->to('/login')->withInput()->with('error', 'Password is too short.');
        }

        $key = strtolower($email);
        $user = DataStore::checkLogin($key, $password);
        if (! $user) {
            return redirect()->to('/login')->withInput()->with('error', 'Invalid email or password.');
        }

        session()->regenerate();
        session()->set([
            'isLoggedIn' => true,
            'email'      => $key,
            'name'       => $user['name'],
            'phone'      => $user['phone'] ?? '',
            'address'    => $user['address'] ?? '',
            'role'       => $user['role'],
        ]);
        if ($user['role'] === 'customer') {
            CartHelper::restoreForCustomer($key);
        }

        return redirect()->to($user['role'] === 'admin' ? '/admin/dashboard' : '/customer/home');
    }

    public function register()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to(session()->get('role') === 'admin' ? '/admin/dashboard' : '/customer/home');
        }

        return view('auth/register', [
            'title' => "Create account — Alyanah's Homemade",
        ]);
    }

    public function attemptRegister()
    {
        $fname   = trim((string) $this->request->getPost('fname'));
        $lname   = trim((string) $this->request->getPost('lname'));
        $email   = trim((string) $this->request->getPost('email'));
        $phone   = trim((string) $this->request->getPost('phone'));
        $address = trim((string) $this->request->getPost('address'));
        $pass    = (string) $this->request->getPost('password');

        if ($fname === '') {
            return redirect()->to('/register')->withInput()->with('error', 'Enter your first name.');
        }
        if ($email === '' || ! str_contains($email, '@')) {
            return redirect()->to('/register')->withInput()->with('error', 'Enter a valid email address.');
        }
        if (strlen($pass) < 6) {
            return redirect()->to('/register')->withInput()->with('error', 'Password must be at least 6 characters.');
        }

        $key  = strtolower($email);
        $name = trim($fname . ' ' . $lname);

        if (DataStore::findUser($key) !== null) {
            return redirect()->to('/register')->withInput()->with('error', 'This email is already registered.');
        }

        DataStore::createUser($key, $name, $phone, $pass, $address);

        session()->regenerate();
        session()->set([
            'isLoggedIn' => true,
            'email'      => $key,
            'name'       => $name,
            'phone'      => $phone,
            'address'    => $address,
            'role'       => 'customer',
            'cart'       => [],
        ]);

        return redirect()->to('/customer/home')->with('message', "Welcome, {$fname}! Account created.");
    }

    public function logout()
    {
        session()->destroy();

        return redirect()->to('/login')->with('message', 'You have been signed out.');
    }
}