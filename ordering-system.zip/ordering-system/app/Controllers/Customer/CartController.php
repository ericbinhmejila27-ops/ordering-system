<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class CartController extends BaseController
{
    public function index()
    {
        $data = [
            'title'        => "Your Cart — Alyanah's Homemade",
            'active'       => 'cart',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'lines'        => CartHelper::lines(),
            'subtotal'     => CartHelper::subtotal(),
            'deliveryFee'  => CartHelper::deliveryFee(),
            'total'        => CartHelper::total(),
        ];

        return view('customer/cart', $data);
    }

    public function updateQty($id)
    {
        $qty   = (int) $this->request->getPost('qty');
        $stock = DataStore::stockFor((int) $id);

        if ($stock !== null && $qty > $stock) {
            CartHelper::updateQty((int) $id, $stock);

            return redirect()->to('/customer/cart')->with('error', $stock > 0 ? "Only {$stock} left in stock." : 'Sorry, this item just sold out.');
        }

        CartHelper::updateQty((int) $id, $qty);

        return redirect()->to('/customer/cart');
    }

    public function remove($id)
    {
        CartHelper::remove((int) $id);

        return redirect()->to('/customer/cart')->with('message', 'Item removed from cart.');
    }
}