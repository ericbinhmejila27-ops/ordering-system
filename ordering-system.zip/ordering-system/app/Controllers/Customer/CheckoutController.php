<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class CheckoutController extends BaseController
{
    public function index()
    {
        if (! CartHelper::get()) {
            return redirect()->to('/customer/cart')->with('error', 'Your cart is empty.');
        }

        $data = [
            'title'        => "Checkout — Alyanah's Homemade",
            'active'       => 'cart',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'lines'        => CartHelper::lines(),
            'subtotal'     => CartHelper::subtotal(),
            'deliveryFee'  => CartHelper::deliveryFee(),
            'total'        => CartHelper::total(),
        ];

        return view('customer/checkout', $data);
    }

    public function placeOrder()
    {
        $lines = CartHelper::lines();
        if (! $lines) {
            return redirect()->to('/customer/cart')->with('error', 'Your cart is empty.');
        }

        $name  = trim((string) $this->request->getPost('name'));
        $phone = trim((string) $this->request->getPost('phone'));
        $addr  = trim((string) $this->request->getPost('address'));

        if ($name === '' || $phone === '') {
            return redirect()->back()->withInput()->with('error', 'Fill in your name and phone number.');
        }

        $payMethod = (string) ($this->request->getPost('payment') ?: 'cod');
        if (! in_array($payMethod, ['cod', 'gcash', 'bank'], true)) {
            return redirect()->back()->withInput()->with('error', 'Choose a valid payment method.');
        }
        $paymentRef  = '';
        $paymentProof = '';
        $paymentType = 'full';

        if (in_array($payMethod, ['gcash', 'bank'], true)) {
            $paymentRef = trim((string) $this->request->getPost('payref'));
            if ($paymentRef === '') {
                $label = $payMethod === 'gcash' ? 'GCash' : 'bank transfer';

                return redirect()->back()->withInput()->with('error', "Enter your {$label} reference number.");
            }

            $file = $this->request->getFile('payproof');
            if ($file && $file->isValid() && ! $file->hasMoved()) {
                $newName = $file->getRandomName();
                $file->move(FCPATH . 'assets/uploads/payments', $newName);
                $paymentProof = 'assets/uploads/payments/' . $newName;
            }

            // Down payment: customer pays 50% now via GCash/Bank, the rest
            // (balance) is collected as cash on delivery.
            $paymentType = $this->request->getPost('payment_type') === 'partial' ? 'partial' : 'full';
        }

        // Save delivery details back to the account for next time.
        session()->set(['name' => $name, 'phone' => $phone, 'address' => $addr ?: session()->get('address')]);
        DataStore::updateProfile(
            (string) session()->get('email'),
            $name,
            $phone,
            $addr ?: (string) session()->get('address')
        );

        $delivery = (string) ($this->request->getPost('delivery') ?: 'delivery');
        if (! in_array($delivery, ['delivery', 'pickup', 'foodpanda'], true)) {
            return redirect()->back()->withInput()->with('error', 'Choose a valid delivery method.');
        }
        try {
            $id = DataStore::placeOrder(
                (string) session()->get('email'),
                $lines,
                $delivery,
                $payMethod,
                $paymentType,
                $paymentRef,
                $paymentProof,
                (float) CartHelper::deliveryFee()
            );
        } catch (\DomainException $e) {
            return redirect()->to('/customer/cart')->with('error', $e->getMessage());
        }

        CartHelper::clear();

        return redirect()->to('/customer/checkout/success/' . $id);
    }

    public function success(string $orderId)
    {
        $order = DataStore::findOrder($orderId);
        if (! $order || $order['custEmail'] !== session()->get('email')) {
            return redirect()->to('/customer/home');
        }

        $data = [
            'title'        => "Order placed — Alyanah's Homemade",
            'active'       => 'cart',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'order'        => $order,
        ];

        return view('customer/checkout_success', $data);
    }
}