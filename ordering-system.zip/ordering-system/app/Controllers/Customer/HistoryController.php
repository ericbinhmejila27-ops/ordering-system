<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class HistoryController extends BaseController
{
    public function index()
    {
        $email  = session()->get('email');
        $period = $this->request->getGet('period') ?? 'all';

        $mine = array_values(array_filter(
            DataStore::getOrders(),
            fn ($o) => $o['custEmail'] === $email && $o['status'] === 'delivered'
        ));

        if ($period !== 'all') {
            $cutoff = $period === 'month' ? strtotime('-1 month') : strtotime('-3 months');
            $mine   = array_values(array_filter(
                $mine,
                fn ($o) => ($ts = strtotime($o['date'] ?? '')) !== false && $ts >= $cutoff
            ));
        }

        $mine = array_reverse($mine);
        $perPage = 10;
        $totalPages = max(1, (int) ceil(count($mine) / $perPage));
        $page = min(max(1, (int) $this->request->getGet('page')), $totalPages);
        $mine = array_slice($mine, ($page - 1) * $perPage, $perPage);

        $data = [
            'title'        => "Order History — Alyanah's Homemade",
            'active'       => 'history',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'orders'       => $mine,
            'period'       => $period,
            'page'         => $page,
            'totalPages'   => $totalPages,
        ];

        return view('customer/history', $data);
    }

    public function cancel($id)
    {
        $cancelled = DataStore::cancelOrder((string) $id, (string) session()->get('email'));
        if (! $cancelled) {
            return redirect()->to('/customer/history')->with('error', 'This order cannot be cancelled.');
        }

        return redirect()->to('/customer/history')->with('message', "{$id} has been cancelled");
    }
}