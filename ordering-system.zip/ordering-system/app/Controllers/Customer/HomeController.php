<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class HomeController extends BaseController
{
    public function index()
    {
        $data = [
            'title'        => "Alyanah's Homemade",
            'active'       => 'home',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'menu'         => DataStore::getMenu(),
        ];

        return view('customer/home', $data);
    }
}
