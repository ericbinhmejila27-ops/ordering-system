<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class MenuController extends BaseController
{
    public function index()
    {
        $filter = $this->request->getGet('filter') ?? 'All';
        $menu   = DataStore::getMenu();

        $list = match ($filter) {
            'Savory'       => array_values(array_filter($menu, fn ($p) => $p['cat'] === 'savory')),
            'Desserts'     => array_values(array_filter($menu, fn ($p) => $p['cat'] === 'dessert')),
            'Best Sellers' => array_values(array_filter($menu, fn ($p) => ($p['badge'] ?? null) === 'bestseller')),
            default        => $menu,
        };

        $data = [
            'title'        => "Menu — Alyanah's Homemade",
            'active'       => 'menu',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'filter'       => $filter,
            'menu'         => $list,
        ];

        return view('customer/menu', $data);
    }

    public function show(int $id)
    {
        $p = DataStore::findMenuItem($id);
        if (! $p) {
            return redirect()->to('/customer/menu')->with('error', 'Item not found.');
        }

        $data = [
            'title'        => $p['name'] . " — Alyanah's Homemade",
            'active'       => 'menu',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'item'         => $p,
        ];

        return view('customer/product', $data);
    }

    /**
     * Handles the "Add to cart" form submit for a given product id.
     * No JS — plain POST + redirect back with a flash message.
     */
    public function addToCart($productId)
    {
        $qty = max(1, (int) ($this->request->getPost('qty') ?? 1));
        $p   = DataStore::findMenuItem((int) $productId);

        if (! $p) {
            return redirect()->back()->with('error', 'Item not found.');
        }
        if (($p['avail'] ?? true) === false) {
            return redirect()->back()->with('error', 'This item is currently sold out.');
        }

        // Inventory: can't add more than what's left (counting what's
        // already in the cart).
        if ($p['stock'] !== null) {
            $inCart = (int) (CartHelper::get()[(int) $productId] ?? 0);
            $left   = $p['stock'] - $inCart;
            if ($left <= 0) {
                return redirect()->back()->with('error', $inCart > 0
                    ? "You already have all {$p['stock']} remaining {$p['name']} in your cart."
                    : "{$p['name']} is currently sold out.");
            }
            if ($qty > $left) {
                CartHelper::add((int) $productId, $left);

                return redirect()->back()->with('info', "Only {$left} {$p['name']} left — added {$left} to your cart.");
            }
        }

        CartHelper::add((int) $productId, $qty);

        return redirect()->back()->with('message', $p['name'] . ' added to cart!');
    }
}