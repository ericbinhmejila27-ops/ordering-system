<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class OrderController extends BaseController
{
    public function view($orderId)
    {
        $email = session()->get('email');
        $order = DataStore::findOrder($orderId);

        // Only the owning customer can view their own order.
        if (! $order || $order['custEmail'] !== $email) {
            return redirect()->to('/customer/track-order')->with('error', 'Order not found.');
        }

        $data = [
            'title'        => $order['id'] . ' — Order Details',
            'active'       => 'track',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'o'            => $order,
        ];

        return view('customer/order_details', $data);
    }
}