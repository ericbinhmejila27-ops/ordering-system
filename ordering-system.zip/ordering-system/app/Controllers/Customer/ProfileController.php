<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class ProfileController extends BaseController
{
    public function index()
    {
        $data = [
            'title'          => "My Profile — Alyanah's Homemade",
            'active'         => 'profile',
            'customerName'   => session()->get('name') ?? 'Customer',
            'customerEmail'  => session()->get('email') ?? '',
            'customerPhone'  => session()->get('phone') ?? '',
            'customerAddress' => session()->get('address') ?? '',
            'cartCount'      => CartHelper::count(),
        ];

        return view('customer/profile', $data);
    }

    public function update()
    {
        $name    = trim((string) $this->request->getPost('name'));
        $phone   = trim((string) $this->request->getPost('phone'));
        $address = trim((string) $this->request->getPost('address'));

        if ($name === '') {
            return redirect()->back()->withInput()->with('error', 'Name cannot be empty.');
        }

        session()->set(['name' => $name, 'phone' => $phone, 'address' => $address]);
        DataStore::updateProfile((string) session()->get('email'), $name, $phone, $address);

        return redirect()->to('/customer/profile')->with('message', 'Profile saved.');
    }
}
