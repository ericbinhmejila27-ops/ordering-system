<?php

namespace App\Controllers\Customer;

use App\Controllers\BaseController;
use App\Libraries\CartHelper;
use App\Libraries\DataStore;

class TrackOrderController extends BaseController
{
    public function index()
    {
        $email = session()->get('email');
        // Delivered orders belong in Order History, not Track Order.
        $mine  = array_values(array_filter(
            DataStore::getOrders(),
            fn ($o) => $o['custEmail'] === $email && $o['status'] !== 'delivered'
        ));
        $mine  = array_reverse($mine);
        $perPage = 10;
        $totalPages = max(1, (int) ceil(count($mine) / $perPage));
        $page = min(max(1, (int) $this->request->getGet('page')), $totalPages);
        $mine = array_slice($mine, ($page - 1) * $perPage, $perPage);

        $data = [
            'title'        => "Track Order — Alyanah's Homemade",
            'active'       => 'track',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'mine'         => $mine,
            'page'         => $page,
            'totalPages'   => $totalPages,
            'trackId'      => null,
            'found'        => null,
            'isDelivered'  => false,
        ];

        return view('customer/track_order', $data);
    }

    public function track()
    {
        $orderId = trim((string) $this->request->getPost('order_id'));
        $email   = session()->get('email');
        // Delivered orders belong in Order History, not Track Order.
        $mine    = array_reverse(array_values(array_filter(
            DataStore::getOrders(),
            fn ($o) => $o['custEmail'] === $email && $o['status'] !== 'delivered'
        )));
        $perPage = 10;
        $totalPages = max(1, (int) ceil(count($mine) / $perPage));
        $page = min(max(1, (int) $this->request->getGet('page')), $totalPages);
        $mine = array_slice($mine, ($page - 1) * $perPage, $perPage);

        $found         = null;
        $isDelivered   = false;
        if ($orderId !== '') {
            $order = DataStore::findOrder(strtoupper($orderId));
            if ($order && $order['status'] === 'delivered') {
                // Already delivered — it now lives in Order History instead.
                $isDelivered = true;
                $found       = false;
            } else {
                $found = $order ?: false;
            }
        }

        $data = [
            'title'        => "Track Order — Alyanah's Homemade",
            'active'       => 'track',
            'customerName' => session()->get('name') ?? 'Customer',
            'cartCount'    => CartHelper::count(),
            'mine'         => $mine,
            'page'         => $page,
            'totalPages'   => $totalPages,
            'trackId'      => $orderId,
            'found'        => $found,
            'isDelivered'  => $isDelivered,
        ];

        return view('customer/track_order', $data);
    }
}