<?php

namespace App\Controllers\Guest;

use App\Controllers\BaseController;

class AboutController extends BaseController
{
    public function index()
    {
        $data = [
            'title'  => "About Us — Alyanah's Homemade",
            'active' => 'about',
        ];

        return view('guest/about', $data);
    }
}
