<?php

namespace App\Controllers\Guest;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class HomeController extends BaseController
{
    public function index()
    {
        $data = [
            'title'  => "Alyanah's Homemade — Fresh Homemade Filipino Food",
            'active' => 'home',
            'menu'   => DataStore::getMenu(),
        ];

        return view('guest/home', $data);
    }
}
