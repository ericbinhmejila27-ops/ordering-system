<?php

namespace App\Controllers\Guest;

use App\Controllers\BaseController;
use App\Libraries\DataStore;

class MenuController extends BaseController
{
    public function index()
    {
        $filter = $this->request->getGet('filter') ?? 'All';
        $menu   = DataStore::getMenu();

        $list = match ($filter) {
            'Savory'       => array_values(array_filter($menu, fn ($p) => $p['cat'] === 'savory')),
            'Desserts'     => array_values(array_filter($menu, fn ($p) => $p['cat'] === 'dessert')),
            'Best Sellers' => array_values(array_filter($menu, fn ($p) => ($p['badge'] ?? null) === 'bestseller')),
            default        => $menu,
        };

        $data = [
            'title'   => "Menu — Alyanah's Homemade",
            'active'  => 'menu',
            'filter'  => $filter,
            'menu'    => $list,
        ];

        return view('guest/menu', $data);
    }

    public function show(int $id)
    {
        $p = DataStore::findMenuItem($id);
        if (! $p) {
            return redirect()->to('/menu')->with('error', 'Item not found.');
        }

        $data = [
            'title'  => $p['name'] . " — Alyanah's Homemade",
            'active' => 'menu',
            'item'   => $p,
        ];

        return view('guest/product', $data);
    }
}
