<?php

namespace App\Helpers;

/**
 * Database helper using PDO connection
 * PDO is more compatible than MySQLi in this environment
 */
class DbHelper
{
    private static $conn = null;
    private static $enabled = null;

    /**
     * Get PDO database connection
     */
    public static function getConnection(): ?\PDO
    {
        // Check once if PDO MySQL is available
        if (self::$enabled === null) {
            self::$enabled = class_exists('PDO') && in_array('mysql', \PDO::getAvailableDrivers(), true);
        }

        if (!self::$enabled) {
            return null;
        }

        if (self::$conn === null) {
            try {
                self::$conn = new \PDO('mysql:host=localhost;dbname=alyanah_db;charset=utf8mb4', 'root', '');
                self::$conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                self::$conn->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);
            } catch (\PDOException $e) {
                throw new \RuntimeException('Unable to connect to alyanah_db: ' . $e->getMessage(), 0, $e);
            }
        }
        return self::$conn;
    }

}