<?php

namespace App\Libraries;

/**
 * Session-backed cart mirrored to the signed-in customer's persistent cart.
 */
class CartHelper
{
    public static function get(): array
    {
        return session()->get('cart') ?? [];
    }

    public static function count(): int
    {
        return array_sum(self::get());
    }

    public static function add(int $id, int $qty = 1): void
    {
        $cart       = self::get();
        $cart[$id]  = ($cart[$id] ?? 0) + $qty;
        self::store($cart);
    }

    public static function updateQty(int $id, int $qty): void
    {
        $cart = self::get();
        if ($qty <= 0) {
            unset($cart[$id]);
        } else {
            $cart[$id] = $qty;
        }
        self::store($cart);
    }

    public static function remove(int $id): void
    {
        $cart = self::get();
        unset($cart[$id]);
        self::store($cart);
    }

    public static function clear(): void
    {
        self::store([]);
    }

    public static function restoreForCustomer(string $email): void
    {
        $cart = DataStore::customerCart($email);
        if (! $cart) {
            $cart = self::get();
        }
        self::store($cart, false);
        DataStore::saveCustomerCart($email, $cart);
    }

    private static function store(array $cart, bool $persist = true): void
    {
        if ($persist && session()->get('role') === 'customer' && session()->get('email')) {
            DataStore::saveCustomerCart((string) session()->get('email'), $cart);
        }
        session()->set('cart', $cart);
    }

    /**
     * Returns cart lines merged with menu item details:
     * [['id'=>,'name'=>,'price'=>,'qty'=>,'emoji'=>,'img'=>,'bg'=>,'lineTotal'=>], ...]
     */
    public static function lines(): array
    {
        $menu  = DataStore::getMenu();
        $lines = [];
        foreach (self::get() as $id => $qty) {
            foreach ($menu as $p) {
                if ((int) $p['id'] === (int) $id) {
                    $lines[] = array_merge($p, ['qty' => $qty, 'lineTotal' => $p['price'] * $qty]);
                }
            }
        }

        return $lines;
    }

    public static function subtotal(): float
    {
        return array_sum(array_column(self::lines(), 'lineTotal'));
    }

    public static function deliveryFee(): int
    {
        return self::subtotal() >= 500 ? 0 : 80;
    }

    public static function total(): float
    {
        return self::subtotal() + self::deliveryFee();
    }
}
