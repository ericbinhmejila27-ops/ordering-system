<?php

namespace App\Libraries;

use App\Helpers\DbHelper;

class DataStore
{
    private static ?\PDO $database = null;
    private static bool $configured = false;

    private const ORDER_STATUSES = ['pending', 'preparing', 'on delivery', 'delivered', 'cancelled'];
    private const STATUS_SEQUENCE = ['pending', 'preparing', 'on delivery', 'delivered'];

    private static function db(): \PDO
    {
        if (self::$database === null) {
            self::$database = DbHelper::getConnection();
            if (self::$database === null) {
                throw new \RuntimeException('PDO MySQL is unavailable. Enable the pdo_mysql extension for the PHP runtime.');
            }
        }
        if (! self::$configured) {
            self::$database->exec('SET SESSION group_concat_max_len = 10000');
            self::$configured = true;
        }

        return self::$database;
    }

    public static function paymentInfo(): array
    {
        $methods = self::paymentMethods();
        if (! isset($methods['gcash'], $methods['bank'])) {
            throw new \RuntimeException('GCash and bank payment details are not configured in payment_methods.');
        }
        return [
            'gcash_number' => $methods['gcash']['account_number'] ?? '',
            'gcash_name' => $methods['gcash']['account_name'] ?? '',
            'gcash_qr' => $methods['gcash']['qr_image'] ?? 'assets/images/qr/gcash-qr.png',
            'bank_name' => $methods['bank']['bank_name'] ?? '',
            'bank_account_name' => $methods['bank']['account_name'] ?? '',
            'bank_account_number' => $methods['bank']['account_number'] ?? '',
            'bank_qr' => $methods['bank']['qr_image'] ?? 'assets/images/qr/bank-qr.png',
        ];
    }

    public static function paymentMethods(): array
    {
        $methods = [];
        foreach (self::db()->query(
            'SELECT pm.*, pm.payment_name AS name FROM payment_methods pm ORDER BY pm.payment_method_id'
        )->fetchAll(\PDO::FETCH_ASSOC) as $method) {
            $methods[$method['payment_code']] = $method;
        }

        return $methods;
    }

    public static function customerCart(string $email): array
    {
        $stmt = self::db()->prepare(
            'SELECT ci.menu_id, ci.quantity
             FROM customer_cart_items ci
             JOIN users u ON u.user_id = ci.user_id
             WHERE u.email = ?'
        );
        $stmt->execute([strtolower($email)]);
        $cart = [];
        foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
            $cart[(int) $row['menu_id']] = (int) $row['quantity'];
        }

        return $cart;
    }

    public static function saveCustomerCart(string $email, array $cart): void
    {
        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT user_id FROM users WHERE email = ? FOR UPDATE');
            $stmt->execute([strtolower($email)]);
            $userId = $stmt->fetchColumn();
            if ($userId === false) {
                throw new \RuntimeException('Your account could not be found while saving your cart.');
            }

            $db->prepare('DELETE FROM customer_cart_items WHERE user_id = ?')->execute([(int) $userId]);
            $insert = $db->prepare(
                'INSERT INTO customer_cart_items (user_id, menu_id, quantity) VALUES (?, ?, ?)'
            );
            foreach ($cart as $menuId => $quantity) {
                $menuId = (int) $menuId;
                $quantity = (int) $quantity;
                if ($menuId < 1 || $quantity < 1) {
                    throw new \InvalidArgumentException('Cart items must have a valid item and positive quantity.');
                }
                $insert->execute([(int) $userId, $menuId, $quantity]);
            }

            $db->commit();
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    public static function getCategories(): array
    {
        return self::db()->query(
            'SELECT category_id, category_name AS name, bg_color FROM categories ORDER BY category_name'
        )
            ->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function deliveryMethods(): array
    {
        return self::db()->query(
            'SELECT delivery_method_id, delivery_code, delivery_name AS name
             FROM delivery_methods ORDER BY delivery_method_id'
        )
            ->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function getMenu(): array
    {
        $sql = 'SELECT m.menu_id, m.menu_name AS name, m.emoji, m.image, m.description, m.price,
                       m.badge, m.is_available, m.is_archived,
                       c.category_name, c.bg_color,
                       i.stock AS inv_stock, i.low_stock AS inv_low
                FROM menu_items m
                JOIN categories c ON c.category_id = m.category_id
                LEFT JOIN inventory i ON i.menu_id = m.menu_id
                WHERE m.is_archived = 0
                ORDER BY m.menu_id';
        return array_map([self::class, 'menuRow'], self::db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC));
    }

    public static function findMenuItem(int $id): ?array
    {
        $stmt = self::db()->prepare(
            'SELECT m.menu_id, m.menu_name AS name, m.emoji, m.image, m.description, m.price,
                    m.badge, m.is_available, m.is_archived,
                    c.category_name, c.bg_color,
                    i.stock AS inv_stock, i.low_stock AS inv_low
             FROM menu_items m
             JOIN categories c ON c.category_id = m.category_id
             LEFT JOIN inventory i ON i.menu_id = m.menu_id
             WHERE m.menu_id = ? AND m.is_archived = 0'
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return $row ? self::menuRow($row) : null;
    }

    private static function menuRow(array $row): array
    {
        return [
            'id' => (int) $row['menu_id'],
            'name' => $row['name'],
            'emoji' => $row['emoji'] ?? '',
            'img' => $row['image'] ?? '',
            'desc' => $row['description'] ?? '',
            'price' => (float) $row['price'],
            'badge' => $row['badge'] ?? null,
            'bg' => $row['bg_color'] ?? '#f5e0d0',
            'cat' => $row['category_name'] ?? '',
            'avail' => (bool) $row['is_available'],
            'archived' => (bool) $row['is_archived'],
            'stock' => array_key_exists('inv_stock', $row) && $row['inv_stock'] !== null ? (int) $row['inv_stock'] : null,
            'lowStock' => isset($row['inv_low']) ? (int) $row['inv_low'] : 5,
        ];
    }

    private static function categoryId(string $category): int
    {
        $stmt = self::db()->prepare('SELECT category_id FROM categories WHERE category_name = ?');
        $stmt->execute([trim($category)]);
        $id = $stmt->fetchColumn();
        if ($id === false) {
            throw new \InvalidArgumentException('Choose a valid menu category.');
        }

        return (int) $id;
    }

    public static function addMenuItem(array $item): int
    {
        $stmt = self::db()->prepare(
            'INSERT INTO menu_items (category_id, menu_name, emoji, image, description, price, badge, is_available)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            self::categoryId((string) $item['cat']),
            trim((string) $item['name']),
            $item['emoji'] ?? null,
            $item['img'] ?? null,
            $item['desc'] ?? null,
            (float) $item['price'],
            $item['badge'] ?? null,
            ! empty($item['avail']) ? 1 : 0,
        ]);

        return (int) self::db()->lastInsertId();
    }

    public static function updateMenuItem(int $id, array $fields): bool
    {
        $stmt = self::db()->prepare(
            'UPDATE menu_items SET price = ?, is_available = ? WHERE menu_id = ? AND is_archived = 0'
        );
        $stmt->execute([(float) $fields['price'], ! empty($fields['avail']) ? 1 : 0, $id]);

        return $stmt->rowCount() > 0 || self::findMenuItem($id) !== null;
    }

    public static function setAvailability(int $id, bool $available): bool
    {
        $db = self::db();
        if ($available) {
            $stmt = $db->prepare('SELECT stock FROM inventory WHERE menu_id = ?');
            $stmt->execute([$id]);
            $stock = $stmt->fetchColumn();
            if ($stock !== false && $stock !== null && (int) $stock <= 0) {
                return false;
            }
        }
        $stmt = $db->prepare('UPDATE menu_items SET is_available = ? WHERE menu_id = ? AND is_archived = 0');
        $stmt->execute([$available ? 1 : 0, $id]);

        return $stmt->rowCount() > 0 || self::findMenuItem($id) !== null;
    }

    public static function archiveMenuItem(int $id): bool
    {
        $stmt = self::db()->prepare(
            'UPDATE menu_items SET is_archived = 1, is_available = 0 WHERE menu_id = ? AND is_archived = 0'
        );
        $stmt->execute([$id]);

        return $stmt->rowCount() > 0;
    }

    public static function getOrders(): array
    {
        $sql = self::orderSelect() . ' ORDER BY o.order_date DESC, o.order_id DESC';
        return array_map([self::class, 'orderRow'], self::db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC));
    }

    public static function findOrder(string $id): ?array
    {
        $orderId = self::numericOrderId($id);
        if ($orderId === null) {
            return null;
        }
        $stmt = self::db()->prepare(self::orderSelect() . ' WHERE o.order_id = ?');
        $stmt->execute([$orderId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return $row ? self::orderRow($row) : null;
    }

    private static function orderSelect(): string
    {
        return "SELECT o.order_id, u.user_name AS cust_name, u.email AS cust_email, u.phone AS cust_phone,
                       o.status, o.order_date, dm.delivery_name,
                       pm.payment_code AS payment_method, pm.payment_name AS payment_label,
                       p.reference_no AS payment_ref, p.proof_image AS payment_proof,
                       p.status AS payment_status, p.payment_type, p.amount_paid,
                       p.refund_status, o.delivery_fee,
                       COALESCE(oi.subtotal, 0) + o.delivery_fee AS total,
                       COALESCE(oi.items_text, '') AS items_text,
                       COALESCE(oi.subtotal, 0) + o.delivery_fee - COALESCE(p.amount_paid, 0) AS balance
                FROM orders o
                JOIN users u ON u.user_id = o.user_id
                JOIN delivery_methods dm ON dm.delivery_method_id = o.delivery_method_id
                LEFT JOIN (
                    SELECT od.order_id,
                           SUM(od.quantity * od.unit_price) AS subtotal,
                           GROUP_CONCAT(CONCAT(mi.menu_name, ' ×', od.quantity)
                               ORDER BY od.order_item_id SEPARATOR ', ') AS items_text
                    FROM order_details od
                    JOIN menu_items mi ON mi.menu_id = od.menu_id
                    GROUP BY od.order_id
                ) oi ON oi.order_id = o.order_id
                LEFT JOIN payments p ON p.order_id = o.order_id
                LEFT JOIN payment_methods pm ON pm.payment_method_id = p.payment_method_id";
    }

    private static function numericOrderId(string $id): ?int
    {
        if (! preg_match('/^(?:ORD-)?(\d+)$/i', trim($id), $matches)) {
            return null;
        }

        return (int) $matches[1];
    }

    private static function orderRow(array $row): array
    {
        $date = strtotime((string) $row['order_date']);

        return [
            'id' => 'ORD-' . (int) $row['order_id'],
            'custName' => $row['cust_name'],
            'custEmail' => $row['cust_email'],
            'custPhone' => $row['cust_phone'] ?? '',
            'itemsText' => $row['items_text'] ?? '',
            'total' => (float) $row['total'],
            'status' => $row['status'],
            'date' => $date === false ? (string) $row['order_date'] : date('M j, Y', $date),
            'dateTime' => (string) $row['order_date'],
            'del' => $row['delivery_name'] ?? '',
            'paymentMethod' => $row['payment_method'] ?? 'cod',
            'paymentLabel' => $row['payment_label'] ?? 'Cash on Delivery',
            'paymentRef' => $row['payment_ref'] ?? '',
            'paymentProof' => $row['payment_proof'] ?? '',
            'paymentStatus' => $row['payment_status'] ?? 'cod',
            'paymentType' => $row['payment_type'] ?? 'full',
            'amountPaid' => (float) ($row['amount_paid'] ?? 0),
            'balance' => (float) ($row['balance'] ?? $row['total']),
            'refundStatus' => $row['refund_status'] ?? 'none',
        ];
    }

    public static function nextOrderId(): string
    {
        $next = (int) self::db()->query('SELECT COALESCE(MAX(order_id), 1000) + 1 FROM orders')->fetchColumn();
        return 'ORD-' . $next;
    }

    public static function placeOrder(
        string $email,
        array $lines,
        string $deliveryCode,
        string $paymentCode,
        string $paymentType,
        string $paymentRef,
        string $paymentProof,
        float $deliveryFee
    ): string {
        $db = self::db();
        if (! in_array($paymentCode, ['cod', 'gcash', 'bank'], true)) {
            throw new \InvalidArgumentException('Choose a valid payment method.');
        }
        if (! in_array($deliveryCode, ['delivery', 'pickup', 'foodpanda'], true)) {
            throw new \InvalidArgumentException('Choose a valid delivery method.');
        }
        if (! in_array($paymentType, ['full', 'partial'], true)) {
            throw new \InvalidArgumentException('Choose a valid payment type.');
        }
        if ($deliveryFee < 0) {
            throw new \InvalidArgumentException('Delivery fee cannot be negative.');
        }
        if ($paymentCode !== 'cod' && trim($paymentRef) === '') {
            throw new \DomainException('Enter your payment reference number.');
        }

        $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT user_id FROM users WHERE email = ? FOR UPDATE');
            $stmt->execute([strtolower($email)]);
            $userId = $stmt->fetchColumn();
            if ($userId === false) {
                throw new \RuntimeException('Your account could not be found. Please sign in again.');
            }

            $stmt = $db->prepare('SELECT delivery_method_id FROM delivery_methods WHERE delivery_code = ?');
            $stmt->execute([$deliveryCode]);
            $deliveryId = $stmt->fetchColumn();
            $stmt = $db->prepare('SELECT payment_method_id FROM payment_methods WHERE payment_code = ?');
            $stmt->execute([$paymentCode]);
            $paymentId = $stmt->fetchColumn();
            if ($deliveryId === false || $paymentId === false) {
                throw new \RuntimeException('A configured delivery or payment method is missing.');
            }

            $stmt = $db->prepare(
                'INSERT INTO orders (user_id, delivery_method_id, status, delivery_fee, order_date)
                 VALUES (?, ?, \'pending\', ?, NOW())'
            );
            $stmt->execute([(int) $userId, (int) $deliveryId, round($deliveryFee, 2)]);
            $orderId = (int) $db->lastInsertId();

            $itemInsert = $db->prepare(
                'INSERT INTO order_details (order_id, menu_id, quantity, unit_price) VALUES (?, ?, ?, ?)'
            );
            foreach ($lines as $line) {
                $menuId = (int) $line['id'];
                $quantity = (int) $line['qty'];
                if ($quantity < 1) {
                    throw new \InvalidArgumentException('Every order item must have a positive quantity.');
                }

                $itemStmt = $db->prepare(
                    'SELECT menu_name AS name, price, is_available, is_archived
                     FROM menu_items WHERE menu_id = ? FOR UPDATE'
                );
                $itemStmt->execute([$menuId]);
                $item = $itemStmt->fetch(\PDO::FETCH_ASSOC);
                if (! $item || (int) $item['is_archived'] === 1 || (int) $item['is_available'] !== 1) {
                    throw new \DomainException('An item in your cart is no longer available. Please review your cart.');
                }
                $itemInsert->execute([$orderId, $menuId, $quantity, (float) $item['price']]);

                $stock = self::lockStock($db, $menuId);
                if ($stock !== null) {
                    if ($stock < $quantity) {
                        throw new \DomainException(
                            $stock <= 0
                                ? "Sorry, {$item['name']} just sold out. Please remove it from your cart."
                                : "Sorry, only {$stock} {$item['name']} left. Please lower the quantity in your cart."
                        );
                    }
                    self::writeStock(
                        $db,
                        $menuId,
                        $stock - $quantity,
                        -$quantity,
                        'order',
                        $orderId,
                        ''
                    );
                }
            }

            $subtotalStmt = $db->prepare(
                'SELECT COALESCE(SUM(quantity * unit_price), 0) FROM order_details WHERE order_id = ?'
            );
            $subtotalStmt->execute([$orderId]);
            $orderTotal = round((float) $subtotalStmt->fetchColumn() + $deliveryFee, 2);
            $amountPaid = $paymentCode === 'cod'
                ? 0.0
                : ($paymentType === 'partial' ? round($orderTotal / 2, 2) : $orderTotal);

            $status = $paymentCode === 'cod' ? 'cod' : 'pending_verification';
            $paymentInsert = $db->prepare(
                'INSERT INTO payments
                 (order_id, payment_method_id, payment_type, amount_paid, reference_no, proof_image, status, refund_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, \'none\')'
            );
            $paymentInsert->execute([
                $orderId,
                (int) $paymentId,
                $paymentType,
                round($amountPaid, 2),
                $paymentRef !== '' ? $paymentRef : null,
                $paymentProof !== '' ? $paymentProof : null,
                $status,
            ]);
            $db->commit();

            return 'ORD-' . $orderId;
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    public static function cancelOrder(string $id, string $email): bool
    {
        $orderId = self::numericOrderId($id);
        if ($orderId === null) {
            return false;
        }

        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare(
                'SELECT o.status, p.amount_paid, pm.payment_code
                 FROM orders o
                 JOIN users u ON u.user_id = o.user_id
                 LEFT JOIN payments p ON p.order_id = o.order_id
                 LEFT JOIN payment_methods pm ON pm.payment_method_id = p.payment_method_id
                 WHERE o.order_id = ? AND u.email = ? FOR UPDATE'
            );
            $stmt->execute([$orderId, strtolower($email)]);
            $order = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (! $order || $order['status'] !== 'pending') {
                $db->rollBack();
                return false;
            }

            $refund = $order['payment_code'] !== 'cod' && (float) $order['amount_paid'] > 0 ? 'pending' : 'none';
            $db->prepare("UPDATE orders SET status = 'cancelled' WHERE order_id = ?")->execute([$orderId]);
            $db->prepare('UPDATE payments SET refund_status = ? WHERE order_id = ?')->execute([$refund, $orderId]);

            $stmt = $db->prepare(
                "SELECT menu_id, SUM(change_qty) AS net
                 FROM inventory_logs WHERE order_id = ? AND type IN ('order', 'cancel')
                 GROUP BY menu_id"
            );
            $stmt->execute([$orderId]);
            foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
                $net = (int) $row['net'];
                if ($net >= 0) {
                    continue;
                }
                $menuId = (int) $row['menu_id'];
                $current = self::lockStock($db, $menuId);
                if ($current === null) {
                    continue;
                }
                self::writeStock($db, $menuId, $current - $net, -$net, 'cancel', $orderId, 'Order cancelled');
            }
            $db->commit();

            return true;
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    public static function setOrderStatus(string $id, string $newStatus): bool
    {
        $orderId = self::numericOrderId($id);
        if ($orderId === null || ! in_array($newStatus, self::ORDER_STATUSES, true)) {
            return false;
        }
        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT status FROM orders WHERE order_id = ? FOR UPDATE');
            $stmt->execute([$orderId]);
            $current = $stmt->fetchColumn();
            $oldIndex = array_search($current, self::STATUS_SEQUENCE, true);
            $newIndex = array_search($newStatus, self::STATUS_SEQUENCE, true);
            if ($current === false || $oldIndex === false || $newIndex === false || $newIndex < $oldIndex) {
                $db->rollBack();
                return false;
            }

            $db->prepare('UPDATE orders SET status = ? WHERE order_id = ?')->execute([$newStatus, $orderId]);
            if ($newStatus === 'delivered') {
                $db->prepare("UPDATE payments SET status = 'verified' WHERE order_id = ? AND status <> 'cod'")
                    ->execute([$orderId]);
            }
            $db->commit();

            return true;
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    public static function setPaymentStatus(string $id, string $status): bool
    {
        $orderId = self::numericOrderId($id);
        if ($orderId === null || ! in_array($status, ['cod', 'pending_verification', 'verified'], true)) {
            return false;
        }

        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT status FROM orders WHERE order_id = ? FOR UPDATE');
            $stmt->execute([$orderId]);
            $orderStatus = $stmt->fetchColumn();
            if ($orderStatus === false) {
                $db->rollBack();
                return false;
            }
            $stmt = $db->prepare('UPDATE payments SET status = ? WHERE order_id = ?');
            $stmt->execute([$status, $orderId]);
            if ($stmt->rowCount() === 0) {
                $db->rollBack();
                return false;
            }
            if ($status === 'verified' && $orderStatus === 'pending') {
                $db->prepare("UPDATE orders SET status = 'preparing' WHERE order_id = ?")->execute([$orderId]);
            }
            $db->commit();

            return true;
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    public static function setRefundStatus(string $id, string $status): bool
    {
        $orderId = self::numericOrderId($id);
        if ($orderId === null || ! in_array($status, ['none', 'pending', 'refunded'], true)) {
            return false;
        }
        $stmt = self::db()->prepare('UPDATE payments SET refund_status = ? WHERE order_id = ?');
        $stmt->execute([$status, $orderId]);

        return $stmt->rowCount() > 0;
    }

    public static function checkLogin(string $email, string $password): ?array
    {
        $user = self::findUser($email);
        if (! $user || ! password_verify($password, (string) $user['password'])) {
            return null;
        }

        return $user;
    }

    public static function findUser(string $email): ?array
    {
        $stmt = self::db()->prepare('SELECT u.*, u.user_name AS name FROM users u WHERE u.email = ?');
        $stmt->execute([strtolower(trim($email))]);
        return $stmt->fetch(\PDO::FETCH_ASSOC) ?: null;
    }

    public static function createUser(
        string $email,
        string $name,
        string $phone,
        string $password,
        string $address = '',
        string $role = 'customer'
    ): bool {
        if (! in_array($role, ['customer', 'admin'], true)) {
            throw new \InvalidArgumentException('Invalid user role.');
        }
        $stmt = self::db()->prepare(
            'INSERT INTO users (email, user_name, phone, address, password, role) VALUES (?, ?, ?, ?, ?, ?)'
        );
        return $stmt->execute([
            strtolower(trim($email)),
            trim($name),
            trim($phone),
            trim($address),
            password_hash($password, PASSWORD_BCRYPT),
            $role,
        ]);
    }

    public static function updateProfile(string $email, string $name, string $phone, string $address): bool
    {
        $stmt = self::db()->prepare(
            'UPDATE users SET user_name = ?, phone = ?, address = ? WHERE email = ?'
        );
        $stmt->execute([trim($name), trim($phone), trim($address), strtolower(trim($email))]);

        return $stmt->rowCount() > 0 || self::findUser($email) !== null;
    }

    public static function stockStatus(array $item): string
    {
        if (! array_key_exists('stock', $item) || $item['stock'] === null) {
            return 'untracked';
        }
        if ((int) $item['stock'] <= 0) {
            return 'out';
        }

        return (int) $item['stock'] <= (int) ($item['lowStock'] ?? 5) ? 'low' : 'ok';
    }

    public static function getInventory(): array
    {
        return array_map(
            static fn ($item) => $item + ['stockStatus' => self::stockStatus($item)],
            self::getMenu()
        );
    }

    public static function stockFor(int $menuId): ?int
    {
        $item = self::findMenuItem($menuId);
        return $item['stock'] ?? null;
    }

    public static function getInventoryLogs(?int $menuId = null, int $limit = 50): array
    {
        $limit = max(1, min(500, $limit));
        $sql = "SELECT l.log_id, l.menu_id, l.type, l.change_qty, l.stock_after, l.note, l.created_at,
                       m.menu_name AS item_name,
                       CASE WHEN o.order_id IS NULL THEN NULL ELSE CONCAT('ORD-', o.order_id) END AS reference
                FROM inventory_logs l
                JOIN menu_items m ON m.menu_id = l.menu_id
                LEFT JOIN orders o ON o.order_id = l.order_id";
        if ($menuId !== null) {
            $stmt = self::db()->prepare($sql . " WHERE l.menu_id = ? ORDER BY l.log_id DESC LIMIT {$limit}");
            $stmt->execute([$menuId]);
            return $stmt->fetchAll(\PDO::FETCH_ASSOC);
        }

        return self::db()->query($sql . " ORDER BY l.log_id DESC LIMIT {$limit}")->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function restock(int $menuId, int $quantity, string $note = ''): void
    {
        if ($quantity <= 0) {
            throw new \InvalidArgumentException('Restock quantity must be at least 1.');
        }
        self::changeStock($menuId, $quantity, 'restock', $note);
    }

    public static function setStock(int $menuId, int $count, string $note = ''): void
    {
        if ($count < 0) {
            throw new \InvalidArgumentException('Stock count cannot be negative.');
        }
        self::changeStock($menuId, $count, 'adjust', $note, true);
    }

    public static function setLowStock(int $menuId, int $threshold): void
    {
        $stmt = self::db()->prepare(
            'INSERT INTO inventory (menu_id, low_stock, updated_at) VALUES (?, ?, NOW())
             ON DUPLICATE KEY UPDATE low_stock = VALUES(low_stock), updated_at = VALUES(updated_at)'
        );
        $stmt->execute([$menuId, max(0, $threshold)]);
    }

    public static function stopTracking(int $menuId): void
    {
        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT auto_soldout FROM inventory WHERE menu_id = ? FOR UPDATE');
            $stmt->execute([$menuId]);
            $wasAutoSoldout = (int) $stmt->fetchColumn() === 1;
            if ($wasAutoSoldout) {
                $db->prepare('UPDATE menu_items SET is_available = 1 WHERE menu_id = ? AND is_archived = 0')
                    ->execute([$menuId]);
            }
            $db->prepare('UPDATE inventory SET stock = NULL, auto_soldout = 0, updated_at = NOW() WHERE menu_id = ?')
                ->execute([$menuId]);
            $db->commit();
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    private static function changeStock(int $menuId, int $value, string $type, string $note, bool $setExact = false): void
    {
        $db = self::db();
        $db->beginTransaction();
        try {
            $stmt = $db->prepare(
                'SELECT menu_name FROM menu_items WHERE menu_id = ? AND is_archived = 0 FOR UPDATE'
            );
            $stmt->execute([$menuId]);
            $name = $stmt->fetchColumn();
            if ($name === false) {
                throw new \InvalidArgumentException('Menu item not found.');
            }
            $current = self::lockStock($db, $menuId);
            $newStock = $setExact ? $value : ($current ?? 0) + $value;
            $change = $newStock - ($current ?? 0);
            self::writeStock($db, $menuId, $newStock, $change, $type, null, $note);
            $db->commit();
        } catch (\Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
    }

    private static function lockStock(\PDO $db, int $menuId): ?int
    {
        $stmt = $db->prepare('SELECT stock FROM inventory WHERE menu_id = ? FOR UPDATE');
        $stmt->execute([$menuId]);
        $stock = $stmt->fetchColumn();

        return $stock === false || $stock === null ? null : (int) $stock;
    }

    private static function writeStock(
        \PDO $db,
        int $menuId,
        int $newStock,
        int $change,
        string $type,
        ?int $orderId,
        string $note
    ): void {
        $now = date('Y-m-d H:i:s');
        $db->prepare(
            'INSERT INTO inventory (menu_id, stock, updated_at) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE stock = VALUES(stock), updated_at = VALUES(updated_at)'
        )->execute([$menuId, $newStock, $now]);
        $db->prepare(
            'INSERT INTO inventory_logs (menu_id, order_id, type, change_qty, stock_after, note, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        )->execute([$menuId, $orderId, $type, $change, $newStock, $note !== '' ? $note : null, $now]);

        $soldOutStmt = $db->prepare('SELECT is_available FROM menu_items WHERE menu_id = ? FOR UPDATE');
        $soldOutStmt->execute([$menuId]);
        $isAvailable = (int) $soldOutStmt->fetchColumn() === 1;
        if ($newStock <= 0 && $isAvailable) {
            $db->prepare('UPDATE menu_items SET is_available = 0 WHERE menu_id = ?')->execute([$menuId]);
            $db->prepare('UPDATE inventory SET auto_soldout = 1 WHERE menu_id = ?')->execute([$menuId]);
        } elseif ($newStock > 0) {
            $stmt = $db->prepare('SELECT auto_soldout FROM inventory WHERE menu_id = ?');
            $stmt->execute([$menuId]);
            if ((int) $stmt->fetchColumn() === 1) {
                $db->prepare('UPDATE menu_items SET is_available = 1 WHERE menu_id = ? AND is_archived = 0')
                    ->execute([$menuId]);
                $db->prepare('UPDATE inventory SET auto_soldout = 0 WHERE menu_id = ?')->execute([$menuId]);
            }
        }
    }

    public static function deriveCustomers(): array
    {
        $customers = [];
        foreach (self::getOrders() as $order) {
            $key = strtolower($order['custEmail']);
            if (! isset($customers[$key])) {
                $customers[$key] = [
                    'name' => $order['custName'],
                    'email' => $order['custEmail'],
                    'phone' => $order['custPhone'] ?: '—',
                    'orderCount' => 0,
                    'totalSpent' => 0,
                    'firstDate' => $order['date'],
                ];
            }
            $customers[$key]['name'] = $order['custName'];
            if ($order['custPhone'] !== '') {
                $customers[$key]['phone'] = $order['custPhone'];
            }
            $customers[$key]['orderCount']++;
            $customers[$key]['totalSpent'] += $order['total'];
        }
        $list = array_values($customers);
        usort($list, static fn ($a, $b) => $b['totalSpent'] <=> $a['totalSpent']);

        return $list;
    }

    public static function computeItemStats(string $period = 'all'): array
    {
        $cutoff = match ($period) {
            'week' => date('Y-m-d H:i:s', strtotime('-1 week')),
            'month' => date('Y-m-d H:i:s', strtotime('-1 month')),
            'year' => date('Y-m-d H:i:s', strtotime('-1 year')),
            default => null,
        };
        $sql = "SELECT m.menu_name AS name, m.emoji,
                       COALESCE(SUM(CASE WHEN o.order_id IS NOT NULL THEN oi.quantity ELSE 0 END), 0) AS qty,
                       COALESCE(SUM(CASE WHEN o.order_id IS NOT NULL THEN oi.quantity * oi.unit_price ELSE 0 END), 0) AS revenue
                FROM menu_items m
                LEFT JOIN order_details oi ON oi.menu_id = m.menu_id
                LEFT JOIN orders o ON o.order_id = oi.order_id AND o.status <> 'cancelled'";
        if ($cutoff !== null) {
            $sql .= ' AND o.order_date >= ' . self::db()->quote($cutoff);
        }
        $sql .= ' GROUP BY m.menu_id, m.menu_name, m.emoji ORDER BY revenue DESC';

        return array_map(static fn ($row) => [
            'name' => $row['name'],
            'emoji' => $row['emoji'] ?? '',
            'qty' => (int) $row['qty'],
            'revenue' => (float) $row['revenue'],
        ], self::db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC));
    }

    public static function reportStatus(array $order): string
    {
        if ($order['status'] === 'cancelled') {
            return 'cancelled';
        }
        if ($order['status'] === 'delivered') {
            return 'complete';
        }
        $hasDownPayment = ($order['paymentType'] ?? 'full') === 'partial' && (float) ($order['amountPaid'] ?? 0) > 0;
        if (($order['paymentStatus'] ?? 'cod') === 'verified'
            || ($order['paymentStatus'] ?? 'cod') === 'cod'
            || $hasDownPayment) {
            return 'paid';
        }

        return 'unpaid';
    }

    public static function fmt($value): string
    {
        return '₱' . number_format((float) $value, 2);
    }
}
