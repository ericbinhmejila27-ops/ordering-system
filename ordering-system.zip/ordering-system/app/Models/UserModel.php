<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['email', 'user_name', 'phone', 'address', 'password', 'role'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Find user by email
     */
    public function findByEmail(string $email)
    {
        return $this->select('users.*, user_name AS name')
            ->where('email', strtolower($email))
            ->first();
    }

    /**
     * Check if email already exists
     */
    public function emailExists(string $email): bool
    {
        return $this->where('email', strtolower($email))->countAllResults() > 0;
    }

    public function createUser(string $email, string $name, string $phone, string $password): bool
    {
        return $this->insert([
            'email' => strtolower($email),
            'user_name' => $name,
            'phone' => $phone,
            'address' => '',
            'password' => password_hash($password, PASSWORD_BCRYPT),
            'role' => 'customer',
        ]);
    }

    /**
     * Update user information
     */
    public function updateUserInfo(string $email, array $data): bool
    {
        if (array_key_exists('name', $data)) {
            $data['user_name'] = $data['name'];
            unset($data['name']);
        }

        return $this->where('email', strtolower($email))->set($data)->update();
    }

    /**
     * Verify password
     */
    public function verifyPassword(string $email, string $password): bool
    {
        $user = $this->findByEmail($email);
        if (!$user) {
            return false;
        }
        return password_verify($password, $user['password']);
    }
}
?>
