<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
  <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3)">List of Customer</h2>
  <form method="get" action="<?= site_url('admin/customers') ?>">
    <input class="auth-input" name="q" placeholder="Search name or email" value="<?= esc($q ?? '') ?>" style="margin-bottom:0;min-width:220px">
  </form>
</div>

<div class="table-wrap">
  <table class="tbl">
    <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Total Orders</th><th>Total Spent</th><th>Last Order</th></tr></thead>
    <tbody>
      <?php if (empty($customers)) : ?>
        <tr><td colspan="6" style="text-align:center;color:var(--gray3);padding:24px">No customers yet.</td></tr>
      <?php else : ?>
        <?php foreach ($customers as $c) : ?>
          <tr>
            <td><strong><?= esc($c['name']) ?></strong></td>
            <td style="color:var(--gray3)"><?= esc($c['email']) ?></td>
            <td><?= esc($c['phone']) ?></td>
            <td style="text-align:center"><?= $c['orderCount'] ?></td>
            <td style="color:var(--orange);font-weight:500"><?= App\Libraries\DataStore::fmt($c['totalSpent']) ?></td>
            <td style="color:var(--gray3)"><?= esc($c['firstDate']) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?= $this->endSection() ?>