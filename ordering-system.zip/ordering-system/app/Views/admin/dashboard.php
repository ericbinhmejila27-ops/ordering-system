<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3);margin-bottom:20px">Dashboard</h2>

<?php if (! empty($lowStockItems)) : ?>
  <div class="inv-alert">
    <span>⚠️ <strong><?= count($lowStockItems) ?></strong> item<?= count($lowStockItems) > 1 ? 's' : '' ?> running low or out of stock:
      <?= esc(implode(', ', array_map(fn ($p) => $p['name'] . ' (' . (int) $p['stock'] . ')', $lowStockItems))) ?></span>
    <a href="<?= site_url('admin/inventory') ?>">Restock →</a>
  </div>
<?php endif; ?>

<div class="stat-grid">
  <div class="stat-card"><p class="stat-label">Total Revenue</p><p class="stat-val"><?= App\Libraries\DataStore::fmt($totalRevenue) ?></p><p class="stat-sub">Across all orders</p></div>
  <div class="stat-card"><p class="stat-label">Total Orders</p><p class="stat-val"><?= $totalOrders ?></p><p class="stat-sub"><?= $pendingCount ?> pending</p></div>
  <div class="stat-card"><p class="stat-label">Menu Items</p><p class="stat-val"><?= $menuCount ?></p><p class="stat-sub"><?= $availCount ?> available</p></div>
  <div class="stat-card"><p class="stat-label">Customers</p><p class="stat-val"><?= $customerCount ?></p><p class="stat-sub">Unique buyers</p></div>
</div>

<div class="chart-card">
  <div class="chart-card-head">
    <h3>Revenue by Item</h3>
    <div style="display:flex;align-items:center;gap:14px">
      <div style="display:flex;gap:4px">
        <?php foreach (['week' => 'Week', 'month' => 'Month', 'year' => 'Year', 'all' => 'All'] as $val => $label) : ?>
          <a class="btn btn-sm <?= $period === $val ? 'btn-brown' : 'btn-outline' ?>" style="padding:4px 10px;font-size:11px" href="<?= site_url('admin/dashboard') . ($val === 'all' ? '' : '?period=' . $val) ?>"><?= $label ?></a>
        <?php endforeach; ?>
      </div>
      <span class="chart-live-dot">Live</span>
    </div>
  </div>
  <div class="vbar-chart">
    <?php foreach ($itemStats as $s) : ?>
      <div class="vbar-col">
        <span class="vbar-value"><?= App\Libraries\DataStore::fmt($s['revenue']) ?></span>
        <div class="vbar-track"><div class="vbar-fill" style="height:<?= $s['pct'] ?>%"></div></div>
        <span class="vbar-label"><?= $s['emoji'] ?> <?= esc($s['name']) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div>
    <h3 style="font-size:13px;color:var(--brown3);font-weight:500;margin-bottom:12px">Recent Orders</h3>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
        <tbody>
          <?php if (empty($recent)) : ?>
            <tr><td colspan="6" style="text-align:center;color:var(--gray3);padding:20px">No active orders.</td></tr>
          <?php else : ?>
            <?php foreach ($recent as $o) : ?>
              <tr>
                <td><strong><?= esc($o['id']) ?></strong></td>
                <td><?= esc($o['custName']) ?></td>
                <td><?= esc($o['itemsText']) ?></td>
                <td style="color:var(--orange);font-weight:500"><?= App\Libraries\DataStore::fmt($o['total']) ?></td>
                <td><?= view('partials/payment_badge', ['o' => $o]) ?></td>
                <td><?= view('partials/status_select', ['o' => $o, 'action' => site_url('admin/orders/update-status/' . $o['id'])]) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div>
    <h3 style="font-size:13px;color:var(--brown3);font-weight:500;margin-bottom:12px">Best Selling Items</h3>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr><th>Item</th><th>Orders</th><th>Revenue</th></tr></thead>
        <tbody>
          <?php foreach ($itemStats as $s) : ?>
            <tr><td><?= $s['emoji'] ?> <?= esc($s['name']) ?></td><td><?= $s['qty'] ?></td><td style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($s['revenue']) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?= $this->endSection() ?>