<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3)">List of Inventory</h2>
</div>

<div class="stat-grid">
  <div class="stat-card"><p class="stat-label">Tracked Items</p><p class="stat-val"><?= $trackedCount ?></p><p class="stat-sub">Items with a stock count</p></div>
  <div class="stat-card"><p class="stat-label">Units on Hand</p><p class="stat-val"><?= $unitsOnHand ?></p><p class="stat-sub">Ready to sell</p></div>
  <div class="stat-card"><p class="stat-label">Low Stock</p><p class="stat-val" style="<?= $lowCount ? 'color:#856404' : '' ?>"><?= $lowCount ?></p><p class="stat-sub">At or below alert level</p></div>
  <div class="stat-card"><p class="stat-label">Out of Stock</p><p class="stat-val" style="<?= $outCount ? 'color:#842029' : '' ?>"><?= $outCount ?></p><p class="stat-sub">Auto-marked Sold Out</p></div>
</div>

<div style="display:flex;gap:4px;margin-bottom:12px">
  <?php foreach (['all' => 'All', 'low' => 'Low Stock', 'out' => 'Out of Stock', 'untracked' => 'Not Tracked'] as $val => $label) : ?>
    <a class="btn btn-sm <?= $filter === $val ? 'btn-brown' : 'btn-outline' ?>" style="padding:4px 10px;font-size:11px" href="<?= site_url('admin/inventory') . ($val === 'all' ? '' : '?filter=' . $val) ?>"><?= $label ?></a>
  <?php endforeach; ?>
</div>

<div class="table-wrap" style="margin-bottom:28px">
  <table class="tbl">
    <thead><tr><th>Item</th><th>In Stock</th><th>Alert At</th><th>Status</th><th>Quick Update</th><th></th></tr></thead>
    <tbody>
      <?php if (empty($items)) : ?>
        <tr><td colspan="6" style="text-align:center;color:var(--gray3);padding:24px">No items here.</td></tr>
      <?php else : ?>
        <?php foreach ($items as $p) : $tracked = $p['stock'] !== null; ?>
          <tr>
            <td><span style="font-size:16px;margin-right:8px"><?= $p['emoji'] ?? '🍽️' ?></span><strong><?= esc($p['name']) ?></strong></td>
            <td style="font-size:15px;font-weight:500;color:var(--brown3)"><?= $tracked ? (int) $p['stock'] : '<span style="color:var(--gray3);font-size:12px;font-weight:400">—</span>' ?></td>
            <td style="color:var(--gray3)"><?= $tracked ? '≤ ' . (int) $p['lowStock'] : '—' ?></td>
            <td><?= view('partials/stock_badge', ['status' => $p['stockStatus']]) ?></td>
            <td>
              <?php if ($tracked) : ?>
                <form method="post" action="<?= site_url('admin/inventory/restock/' . $p['id']) ?>" class="inv-inline">
                  <input type="number" name="qty" min="1" step="1" placeholder="Qty" required>
                  <button type="submit" class="btn btn-orange btn-sm">+ Add</button>
                </form>
              <?php else : ?>
                <form method="post" action="<?= site_url('admin/inventory/set/' . $p['id']) ?>" class="inv-inline">
                  <input type="number" name="count" min="0" step="1" placeholder="Count" required>
                  <button type="submit" class="btn btn-brown btn-sm">Track</button>
                </form>
              <?php endif; ?>
            </td>
            <td><a class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px" href="<?= site_url('admin/inventory/' . $p['id']) ?>">Manage</a></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<h3 style="font-size:13px;color:var(--brown3);font-weight:500;margin-bottom:12px">Recent Stock Movements</h3>
<?= view('partials/inventory_log_table', ['logs' => $logs, 'showItem' => true]) ?>

<p style="font-size:11px;color:var(--gray3);margin-top:14px;line-height:1.6">
  Stock is deducted automatically when a customer checks out and returned when an order is cancelled.
  When a tracked item reaches 0 it is marked <strong>Sold Out</strong> on the menu, and goes back on sale once restocked.
  Items that are <strong>Not Tracked</strong> have no limit (made to order).
</p>

<?= $this->endSection() ?>