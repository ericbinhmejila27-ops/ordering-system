<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<?php $tracked = $item['stock'] !== null; ?>
<a class="btn btn-outline btn-sm" href="<?= site_url('admin/inventory') ?>" style="margin-bottom:18px">← Back to inventory</a>

<div style="display:flex;align-items:center;gap:14px;margin-bottom:20px">
  <span style="font-size:30px"><?= $item['emoji'] ?? '🍽️' ?></span>
  <div>
    <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3);line-height:1.1"><?= esc($item['name']) ?></h2>
    <div style="margin-top:6px;display:flex;gap:6px;align-items:center">
      <?= view('partials/stock_badge', ['status' => $item['stockStatus']]) ?>
      <span class="sbadge <?= $item['avail'] ? 's-delivered' : 's-cancelled' ?>">Menu: <?= $item['avail'] ? 'Available' : 'Sold Out' ?></span>
    </div>
  </div>
  <div style="margin-left:auto;text-align:right">
    <p class="stat-label">In Stock</p>
    <p style="font-size:34px;font-weight:500;color:var(--brown3);line-height:1"><?= $tracked ? (int) $item['stock'] : '—' ?></p>
  </div>
</div>

<div class="inv-panels">
  <?php if ($tracked) : ?>
    <div class="inv-panel">
      <h3>Restock</h3>
      <p>Add a new batch to the current stock.</p>
      <form method="post" action="<?= site_url('admin/inventory/restock/' . $item['id']) ?>">
        <input class="auth-input" type="number" name="qty" min="1" step="1" placeholder="How many to add" required>
        <input class="auth-input" name="note" maxlength="200" placeholder="Note (optional) — e.g. Morning batch">
        <button type="submit" class="btn btn-orange" style="width:100%">+ Add Stock</button>
      </form>
    </div>
  <?php endif; ?>

  <div class="inv-panel">
    <h3><?= $tracked ? 'Set Exact Count' : 'Start Tracking' ?></h3>
    <p><?= $tracked ? 'Use after a physical count, or to remove spoiled / damaged items.' : 'Enter how many are ready to sell. Customers can\'t order more than this.' ?></p>
    <form method="post" action="<?= site_url('admin/inventory/set/' . $item['id']) ?>">
      <input class="auth-input" type="number" name="count" min="0" step="1" placeholder="Actual count" value="<?= $tracked ? (int) $item['stock'] : '' ?>" required>
      <?php if ($tracked) : ?>
        <select class="auth-input" name="reason">
          <option value="Count correction">Count correction</option>
          <option value="Spoiled / expired">Spoiled / expired</option>
          <option value="Damaged">Damaged</option>
          <option value="Personal / given away">Personal / given away</option>
          <option value="Other">Other</option>
        </select>
        <input class="auth-input" name="note" maxlength="150" placeholder="Note (optional)">
      <?php endif; ?>
      <button type="submit" class="btn btn-brown" style="width:100%"><?= $tracked ? 'Save Count' : 'Start Tracking' ?></button>
    </form>
  </div>

  <?php if ($tracked) : ?>
    <div class="inv-panel">
      <h3>Low-Stock Alert</h3>
      <p>Show a warning when stock drops to this number or below.</p>
      <form method="post" action="<?= site_url('admin/inventory/threshold/' . $item['id']) ?>">
        <input class="auth-input" type="number" name="low_stock" min="0" step="1" value="<?= (int) $item['lowStock'] ?>" required>
        <button type="submit" class="btn btn-outline" style="width:100%">Save Alert Level</button>
      </form>
      <form method="post" action="<?= site_url('admin/inventory/untrack/' . $item['id']) ?>" style="margin-top:18px;padding-top:14px;border-top:1px solid var(--gray2)" onsubmit="return confirm('Stop tracking stock for &quot;<?= esc($item['name']) ?>&quot;? It will have no order limit.')">
        <button type="submit" class="btn btn-outline btn-sm" style="width:100%;justify-content:center;border-color:#b3261e;color:#b3261e">Stop Tracking</button>
      </form>
    </div>
  <?php endif; ?>
</div>

<h3 style="font-size:13px;color:var(--brown3);font-weight:500;margin:26px 0 12px">Stock History</h3>
<?= view('partials/inventory_log_table', ['logs' => $logs, 'showItem' => false]) ?>

<?= $this->endSection() ?>