<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
  <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3)">List of Menu</h2>
  <a class="btn btn-orange btn-sm" href="<?= site_url('admin/menu/create') ?>">+ Add Item</a>
</div>

<div class="table-wrap">
  <table class="tbl">
    <thead><tr><th>Item</th><th>Category</th><th>Price</th><th>Badge</th><th>Stock</th><th>Menu Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php if (empty($menu)) : ?>
        <tr><td colspan="7" style="text-align:center;color:var(--gray3);padding:24px">No menu items yet. Click "+ Add Item" to create one.</td></tr>
      <?php else : ?>
        <?php foreach ($menu as $p) : $avail = ($p['avail'] ?? true) !== false; ?>
          <tr>
            <td><span style="font-size:16px;margin-right:8px"><?= $p['emoji'] ?? '🍽️' ?></span><strong><?= esc($p['name']) ?></strong></td>
            <td style="text-transform:capitalize"><?= esc($p['cat']) ?></td>
            <td style="color:var(--orange);font-weight:500"><?= App\Libraries\DataStore::fmt($p['price']) ?></td>
            <td><?php if (! empty($p['badge'])) : ?><span class="mc-badge badge-<?= esc($p['badge']) ?>" style="position:static;display:inline-block"><?= esc($p['badge']) ?></span><?php else : ?>—<?php endif; ?></td>
            <td><a href="<?= site_url('admin/inventory/' . $p['id']) ?>" style="text-decoration:none;color:var(--brown3)"><?= $p['stock'] !== null ? '<strong>' . (int) $p['stock'] . '</strong>' : '<span style="color:var(--gray3)">Not tracked</span>' ?></a></td>
            <td><span class="sbadge <?= $avail ? 's-delivered' : 's-cancelled' ?>"><?= $avail ? 'Available' : 'Sold Out' ?></span></td>
            <td>
              <a class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px" href="<?= site_url('admin/menu/edit/' . $p['id']) ?>">Update</a>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?= $this->endSection() ?>