<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<?php $editing = $item !== null; ?>
<div id="tapBack" data-back="<?= site_url('admin/menu') ?>" style="max-width:420px;margin:0 auto;min-height:60vh;cursor:pointer">
  <p style="text-align:center;font-size:10px;color:var(--gray3);letter-spacing:.05em;text-transform:uppercase;margin-bottom:12px">Tap outside the form to go back</p>
  <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:28px 24px">
    <h2 style="font-family:var(--serif);font-weight:400;font-size:22px;color:var(--brown3);margin-bottom:18px"><?= $editing ? 'Update Item' : 'Add New Item' ?></h2>

    <?php $lockedStyle = $editing ? 'background:var(--gray1);color:var(--gray3);cursor:not-allowed' : ''; ?>
    <form method="post" action="<?= $editing ? site_url('admin/menu/edit/' . $item['id']) : site_url('admin/menu/create') ?>" enctype="multipart/form-data">
      <input class="auth-input" name="name" placeholder="Item name" value="<?= esc(old('name') ?? ($item['name'] ?? '')) ?>" style="<?= $lockedStyle ?>" <?= $editing ? 'readonly' : 'required' ?>>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
        <?php $selectedCategory = old('cat') ?? ($item['cat'] ?? ($categories[0]['name'] ?? '')); ?>
        <select class="auth-input" name="cat" style="margin-bottom:0;<?= $lockedStyle ?>" <?= $editing ? 'disabled' : '' ?>>
          <?php foreach ($categories as $category) : ?>
            <option value="<?= esc($category['name']) ?>" <?= $selectedCategory === $category['name'] ? 'selected' : '' ?>><?= esc(ucfirst($category['name'])) ?></option>
          <?php endforeach; ?>
        </select>
        <input class="auth-input" name="price" type="number" min="0" step="0.01" placeholder="Price (₱)" value="<?= esc(old('price') ?? ($item['price'] ?? '')) ?>" style="margin-bottom:0" required>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
        <input class="auth-input" name="emoji" maxlength="4" placeholder="Emoji (e.g. 🍝)" value="<?= esc(old('emoji') ?? ($item['emoji'] ?? '')) ?>" style="margin-bottom:0;<?= $lockedStyle ?>" <?= $editing ? 'readonly' : '' ?>>
        <select class="auth-input" name="badge" style="margin-bottom:0;<?= $lockedStyle ?>" <?= $editing ? 'disabled' : '' ?>>
          <option value="" <?= empty($item['badge']) ? 'selected' : '' ?>>No badge</option>
          <option value="bestseller" <?= ($item['badge'] ?? '') === 'bestseller' ? 'selected' : '' ?>>Best Seller</option>
          <option value="new" <?= ($item['badge'] ?? '') === 'new' ? 'selected' : '' ?>>New</option>
          <option value="seasonal" <?= ($item['badge'] ?? '') === 'seasonal' ? 'selected' : '' ?>>Seasonal</option>
        </select>
      </div>

      <?php if (! empty($item['img'])) : ?>
        <div style="margin-bottom:8px">
          <img src="<?= base_url($item['img']) ?>" alt="Current photo" style="width:100%;max-height:150px;object-fit:cover;border-radius:6px;border:1px solid var(--gray2)">
        </div>
      <?php endif; ?>
      <?php if (! $editing) : ?>
        <label style="display:block;font-size:11px;color:var(--brown3);margin-bottom:4px">Photo</label>
        <input class="auth-input" name="photo" type="file" accept="image/*" style="margin-bottom:10px">
      <?php else : ?>
        <p style="font-size:11px;color:var(--gray3);margin-bottom:10px">Photo can't be changed once the item is added.</p>
      <?php endif; ?>
      <textarea name="desc" placeholder="Description" style="width:100%;min-height:70px;padding:11px 14px;border:1px solid var(--gray2);border-radius:6px;font-family:var(--sans);font-size:13px;background:var(--cream);color:var(--brown);margin-bottom:10px;resize:vertical;<?= $lockedStyle ?>" <?= $editing ? 'readonly' : '' ?>><?= esc(old('desc') ?? ($item['desc'] ?? '')) ?></textarea>

      <?php if (! $editing) : ?>
        <label style="display:block;font-size:11px;color:var(--brown3);margin-bottom:4px">Starting stock <span style="color:var(--gray3)">(optional — leave blank if made to order)</span></label>
        <input class="auth-input" name="stock" type="number" min="0" step="1" placeholder="e.g. 10" value="<?= esc(old('stock') ?? '') ?>">
      <?php else : ?>
        <p style="font-size:12px;color:var(--brown3);margin-bottom:10px">
          Stock: <strong><?= $item['stock'] !== null ? (int) $item['stock'] : 'Not tracked' ?></strong>
          · <a href="<?= site_url('admin/inventory/' . $item['id']) ?>" style="color:var(--orange)">Manage inventory</a>
        </p>
      <?php endif; ?>

      <label style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--brown3);margin-bottom:18px;cursor:pointer">
        <input type="checkbox" name="avail" <?= ($item['avail'] ?? true) !== false ? 'checked' : '' ?>> Available for order
      </label>
      <?php if ($editing) : ?>
        <p style="font-size:11px;color:var(--gray3);margin-top:-14px;margin-bottom:14px">Only price and availability can be updated here.</p>
      <?php endif; ?>

      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-orange" style="flex:1"><?= $editing ? 'Save changes' : 'Add item' ?></button>
      </div>
    </form>

    <?php if ($editing) : ?>
      <form method="post" action="<?= site_url('admin/menu/unavailable/' . $item['id']) ?>" style="margin-top:8px" onsubmit="return confirm('Mark &quot;<?= esc($item['name']) ?>&quot; as not available?')">
        <button type="submit" class="btn btn-outline" style="width:100%;border-color:#b3261e;color:#b3261e">Not Available</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
document.addEventListener('click', function (e) {
  if (e.target.closest('a, button, input, select, textarea, form, label')) return;
  window.location.href = document.getElementById('tapBack').dataset.back;
});
</script>

<?= $this->endSection() ?>