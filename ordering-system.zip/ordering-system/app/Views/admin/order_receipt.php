<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div id="tapBack" data-back="<?= esc($backUrl ?? site_url('admin/orders')) ?>" style="max-width:380px;margin:0 auto;min-height:60vh;cursor:pointer">
  <p style="text-align:center;font-size:10px;color:var(--gray3);letter-spacing:.05em;text-transform:uppercase;margin-bottom:12px">Tap anywhere to go back</p>
  <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:28px 24px">
    <div style="text-align:center;margin-bottom:14px">
      <p style="font-family:var(--serif);font-size:20px;color:var(--brown3)">Alyanah's Homemade</p>
      <p style="font-size:11px;color:var(--gray3);margin-top:2px"><?= esc($o['id']) ?> · <?= esc($o['date']) ?></p>
    </div>
    <div style="border-top:1px dashed var(--gray2);border-bottom:1px dashed var(--gray2);padding:12px 0;margin-bottom:12px">
      <p style="font-size:11px;color:var(--gray3);margin-bottom:2px">Customer</p>
      <p style="font-size:13px;color:var(--brown3);margin-bottom:8px"><?= esc($o['custName']) ?></p>
      <p style="font-size:11px;color:var(--gray3);margin-bottom:2px">Delivery</p>
      <p style="font-size:13px;color:var(--brown3)"><?= esc($o['del']) ?></p>
    </div>
    <div style="margin-bottom:12px">
      <?php foreach (array_filter(array_map('trim', explode(',', $o['itemsText'] ?? ''))) as $line) : ?>
        <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--brown3);padding:4px 0"><?= esc($line) ?></div>
      <?php endforeach; ?>
    </div>
    <div style="border-top:1px solid var(--gray2);padding-top:10px;display:flex;justify-content:space-between;font-weight:500;color:var(--brown3)">
      <span>Total</span><span style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($o['total']) ?></span>
    </div>
    <?php if (($o['paymentType'] ?? 'full') === 'partial') : ?>
      <div style="margin-top:8px;padding-top:8px;border-top:1px dashed var(--gray2);font-size:12px;color:var(--gray3)">
        <div style="display:flex;justify-content:space-between"><span>Down payment paid</span><span><?= App\Libraries\DataStore::fmt($o['amountPaid'] ?? 0) ?></span></div>
        <div style="display:flex;justify-content:space-between;font-weight:600;color:var(--brown3)"><span>Balance on delivery</span><span><?= App\Libraries\DataStore::fmt($o['balance'] ?? 0) ?></span></div>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
document.addEventListener('click', function (e) {
  if (e.target.closest('a, button, input, select, textarea, form, label')) return;
  window.location.href = document.getElementById('tapBack').dataset.back;
});
</script>

<?= $this->endSection() ?>