<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
  <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3)">List of Order</h2>
  <div style="display:flex;gap:6px">
    <?php foreach (['Pending', 'Preparing', 'On Delivery'] as $f) : ?>
      <a class="btn btn-sm <?= $status === $f ? 'btn-brown' : 'btn-outline' ?>" href="<?= site_url('admin/orders') ?>?status=<?= urlencode($f) ?>"><?= $f ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="table-wrap">
  <table class="tbl">
    <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Delivery</th><th>Total</th><th>Payment Method</th><th>Payment Status</th><th>Order Status</th><th>Date</th></tr></thead>
    <tbody>
      <?php if (empty($orders)) : ?>
        <tr><td colspan="9" style="text-align:center;color:var(--gray3);padding:24px">No orders in this status.</td></tr>
      <?php else : ?>
        <?php foreach ($orders as $o) : ?>
          <tr>
            <td><strong><?= esc($o['id']) ?></strong></td>
            <td><?= esc($o['custName']) ?></td>
            <td><a href="<?= site_url('admin/orders/view/' . $o['id']) ?>" style="color:var(--orange);text-decoration:underline;font-size:12px">View items</a></td>
            <td><?= esc($o['del']) ?></td>
            <td style="color:var(--orange);font-weight:500"><?= App\Libraries\DataStore::fmt($o['total']) ?></td>
            <td><?= view('partials/payment_method', ['o' => $o]) ?></td>
            <td><?= view('partials/payment_status', ['o' => $o]) ?></td>
            <td><?= view('partials/status_select', ['o' => $o, 'action' => site_url('admin/orders/update-status/' . $o['id'])]) ?></td>
            <td style="color:var(--gray3)"><?= esc($o['date']) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?= $this->endSection() ?>