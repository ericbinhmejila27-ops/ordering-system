<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<?php
$payMethod = $o['paymentMethod'] ?? 'cod';
$payLabel  = $o['paymentLabel'] ?? ($payMethod === 'cod' ? 'Cash on Delivery' : $payMethod);
?>
<div id="tapBack" data-back="<?= site_url('admin/orders') ?>" style="max-width:380px;margin:0 auto;min-height:60vh;cursor:pointer">
  <p style="text-align:center;font-size:10px;color:var(--gray3);letter-spacing:.05em;text-transform:uppercase;margin-bottom:12px">Tap anywhere to go back</p>
  <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:28px 24px">
    <div style="text-align:center;margin-bottom:14px">
      <p style="font-family:var(--serif);font-size:20px;color:var(--brown3)">Payment Details</p>
      <p style="font-size:11px;color:var(--gray3);margin-top:2px"><?= esc($o['id']) ?> · <?= esc($o['custName']) ?></p>
    </div>
    <div style="border-top:1px dashed var(--gray2);padding-top:12px">
      <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Payment method</p>
      <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= esc($payLabel) ?></p>

      <?php if ($payMethod !== 'cod') : ?>
        <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Reference number</p>
        <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= esc($o['paymentRef'] ?: '— not provided —') ?></p>

        <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Amount to verify</p>
        <?php if (($o['paymentType'] ?? 'full') === 'partial') : ?>
          <p style="font-size:16px;font-weight:600;color:var(--orange);margin-bottom:2px"><?= App\Libraries\DataStore::fmt($o['amountPaid'] ?? 0) ?> <span style="font-size:11px;font-weight:400;color:var(--gray3)">(down payment)</span></p>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:10px">Order total <?= App\Libraries\DataStore::fmt($o['total']) ?> — balance <?= App\Libraries\DataStore::fmt($o['balance'] ?? 0) ?> due on delivery (cash)</p>
        <?php else : ?>
          <p style="font-size:16px;font-weight:600;color:var(--orange);margin-bottom:10px"><?= App\Libraries\DataStore::fmt($o['amountPaid'] ?? $o['total']) ?> <span style="font-size:11px;font-weight:400;color:var(--gray3)">(full payment)</span></p>
        <?php endif; ?>
        <p style="font-size:11px;color:var(--gray3);margin-bottom:10px">Check your <?= esc($payLabel) ?> app/statement for this exact amount and reference number before marking as paid.</p>

        <?php if (! empty($o['paymentProof'])) : ?>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:6px">Payment screenshot</p>
          <img src="<?= base_url($o['paymentProof']) ?>" alt="Payment proof" style="width:100%;border-radius:8px;border:1px solid var(--gray2);margin-bottom:12px">
        <?php endif; ?>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <?php if (($o['paymentStatus'] ?? '') === 'verified') : ?>
            <span class="sbadge s-delivered">Paid ✓ verified</span>
          <?php else : ?>
            <span class="sbadge" style="background:#fff3cd;color:#856404">Awaiting verification</span>
            <form method="post" action="<?= site_url('admin/orders/verify-payment/' . $o['id']) ?>">
              <button type="submit" class="btn btn-sm btn-orange">Mark as Paid</button>
            </form>
          <?php endif; ?>
        </div>
      <?php else : ?>
        <span class="sbadge" style="background:#e2e3e5;color:#41464b">Pay on delivery</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener('click', function (e) {
  if (e.target.closest('a, button, input, select, textarea, form, label')) return;
  window.location.href = document.getElementById('tapBack').dataset.back;
});
</script>

<?= $this->endSection() ?>