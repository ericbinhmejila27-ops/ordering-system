<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<?php
if (! function_exists('reportsUrl')) {
    // Helper: build a reports URL that keeps the current filters but
    // overrides/removes specific ones (used by tabs + pagination links).
    function reportsUrl(array $query, array $overrides): string
    {
        $merged = array_merge($query, $overrides);
        $merged = array_filter($merged, fn ($v) => $v !== '' && $v !== null);

        return site_url('admin/reports') . (count($merged) ? '?' . http_build_query($merged) : '');
    }
}
?>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
  <h2 style="font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3)">List of Sales Reports</h2>
</div>

<!-- Filter bar -->
<form method="get" action="<?= site_url('admin/reports') ?>" style="background:var(--white);border:1px solid var(--gray2);border-radius:10px;padding:16px;margin-bottom:14px">
  <input type="hidden" name="tab" value="<?= esc($tab) ?>">
  <div class="rep-search">
    <span class="rep-search-icon">🔍</span>
    <input type="search" name="q" value="<?= esc($filters['q']) ?>" placeholder="Search order ID, customer, phone, item, or payment reference…" autocomplete="off">
    <?php if ($filters['q'] !== '') : ?>
      <a href="<?= reportsUrl($query, ['q' => null, 'page' => null]) ?>" class="rep-search-clear" title="Clear search">✕</a>
    <?php endif; ?>
    <button type="submit" class="btn btn-brown btn-sm">Search</button>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr;gap:10px;align-items:end">
    <div>
      <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Date From</label>
      <input type="date" name="date_from" value="<?= esc($filters['date_from']) ?>" class="auth-input" style="margin-bottom:0">
    </div>
    <div>
      <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Date To</label>
      <input type="date" name="date_to" value="<?= esc($filters['date_to']) ?>" class="auth-input" style="margin-bottom:0">
    </div>
    <div>
      <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Order Status</label>
      <select name="status" class="auth-input" style="margin-bottom:0">
        <option value="">All</option>
        <?php foreach (['paid' => 'Paid', 'complete' => 'Complete', 'cancelled' => 'Cancelled'] as $val => $label) : ?>
          <option value="<?= $val ?>" <?= $filters['status'] === $val ? 'selected' : '' ?>><?= $label ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Payment</label>
      <select name="payment" class="auth-input" style="margin-bottom:0">
        <option value="">All</option>
        <option value="cod" <?= $filters['payment'] === 'cod' ? 'selected' : '' ?>>Cash on Delivery</option>
        <option value="gcash" <?= $filters['payment'] === 'gcash' ? 'selected' : '' ?>>GCash</option>
        <option value="bank" <?= $filters['payment'] === 'bank' ? 'selected' : '' ?>>Bank Transfer</option>
      </select>
    </div>
    <div>
      <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Delivery</label>
      <select name="delivery" class="auth-input" style="margin-bottom:0">
        <option value="">All</option>
        <?php foreach ($deliveryMethods as $method) : ?>
          <option value="<?= esc($method['name']) ?>" <?= $filters['delivery'] === $method['name'] ? 'selected' : '' ?>><?= esc($method['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
    <button type="submit" class="btn btn-brown btn-sm">Apply Filter</button>
    <a class="btn btn-orange btn-sm" href="<?= site_url('admin/reports/export-csv') ?>?<?= http_build_query(array_filter($filters + ['tab' => $tab])) ?>">⬇ Export CSV</a>
  </div>
</form>

<?php if ($filters['q'] !== '') : ?>
  <p style="font-size:12px;color:var(--gray3);margin-bottom:10px"><?= $totalRows ?> result<?= $totalRows === 1 ? '' : 's' ?> for “<strong style="color:var(--brown3)"><?= esc($filters['q']) ?></strong>”</p>
<?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:6px;margin-bottom:12px">
  <?php foreach (['Paid', 'Complete', 'Cancelled'] as $t) : ?>
    <a class="btn btn-sm <?= $tab === $t ? 'btn-brown' : 'btn-outline' ?>" href="<?= reportsUrl($query, ['tab' => $t, 'status' => null, 'page' => null]) ?>"><?= strtoupper($t) ?></a>
  <?php endforeach; ?>
</div>

<div class="table-wrap">
  <table class="tbl">
    <thead><tr><th>Order ID</th><th>Customer</th><th>Delivery</th><th>Total</th><th>Payment</th><th>Order Status</th><th>Date</th><th>Action</th></tr></thead>
    <tbody>
      <?php if (empty($rows)) : ?>
        <tr><td colspan="8" style="text-align:center;color:var(--gray3);padding:24px"><?= $filters['q'] !== '' ? 'No transactions match “' . esc($filters['q']) . '”.' : 'No transactions match these filters.' ?></td></tr>
      <?php else : ?>
        <?php foreach ($rows as $o) : ?>
          <tr>
            <td><strong><?= esc($o['id']) ?></strong></td>
            <td><?= esc($o['custName']) ?></td>
            <td><?= esc($o['del']) ?></td>
            <td style="color:var(--orange);font-weight:500"><?= App\Libraries\DataStore::fmt($o['total']) ?></td>
            <td><?= view('partials/payment_badge', ['o' => $o]) ?></td>
            <?php $rs = App\Libraries\DataStore::reportStatus($o); ?>
            <td><span class="sbadge s-<?= esc($rs) ?>"><?= $rs === 'unpaid' ? 'Unpaid' : ucfirst($rs) ?></span></td>
            <td style="color:var(--gray3)"><?= esc($o['date']) ?></td>
            <td>
              <?php $refund = $o['refundStatus'] ?? 'none'; ?>
              <?php if ($o['status'] === 'cancelled' && $refund === 'pending') : ?>
                <form method="post" action="<?= site_url('admin/orders/refund/' . $o['id']) ?>" onsubmit="return confirm('Mark <?= esc($o['id']) ?> as refunded? Send the money via <?= esc($o['paymentLabel'] ?? 'GCash/Bank') ?> first.')">
                  <button type="submit" class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px;border-color:#b3261e;color:#b3261e">Mark Refunded</button>
                </form>
              <?php elseif ($o['status'] === 'cancelled' && $refund === 'refunded') : ?>
                <span class="sbadge s-delivered">Refunded</span>
              <?php else : ?>
                <a href="<?= site_url('admin/orders/view/' . $o['id']) ?>" style="color:var(--orange);text-decoration:underline;font-size:12px">View</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if ($lastPage > 1) : ?>
<div style="display:flex;justify-content:flex-end;gap:4px;margin-top:14px">
  <?php for ($p = 1; $p <= $lastPage; $p++) : ?>
    <a class="btn btn-sm <?= $p === $page ? 'btn-brown' : 'btn-outline' ?>" style="padding:4px 10px" href="<?= reportsUrl($query, ['page' => $p]) ?>"><?= $p ?></a>
  <?php endfor; ?>
  <?php if ($page < $lastPage) : ?>
    <a class="btn btn-sm btn-outline" style="padding:4px 10px" href="<?= reportsUrl($query, ['page' => $page + 1]) ?>">Next</a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?= $this->endSection() ?>