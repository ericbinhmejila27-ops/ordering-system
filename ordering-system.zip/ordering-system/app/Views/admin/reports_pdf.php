<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Transaction Report — Alyanah's Homemade</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #2a1d13; padding: 32px; }
  h1 { font-size: 20px; margin-bottom: 2px; }
  .meta { font-size: 11px; color: #6b6055; margin-bottom: 20px; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; }
  th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
  th { background: #f5efe4; text-transform: uppercase; font-size: 9px; letter-spacing: .05em; }
  tfoot td { font-weight: bold; background: #faf6ef; }
  .no-print { margin-bottom: 16px; }
  @media print {
    .no-print { display: none; }
    body { padding: 0; }
  }
</style>
</head>
<body>

<div class="no-print">
  <button onclick="window.print()" style="padding:8px 16px;font-size:12px;cursor:pointer">🖨 Print / Save as PDF</button>
</div>

<h1>Alyanah's Homemade — Transaction Report</h1>
<p class="meta">Generated <?= esc($generated) ?> · <?= count($orders) ?> transaction<?= count($orders) === 1 ? '' : 's' ?></p>

<table>
  <thead>
    <tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Delivery</th><th>Payment</th><th>Status</th><th>Date</th><th>Total</th></tr>
  </thead>
  <tbody>
    <?php if (empty($orders)) : ?>
      <tr><td colspan="8" style="text-align:center;color:#888">No transactions match these filters.</td></tr>
    <?php else : ?>
      <?php foreach ($orders as $o) : ?>
        <tr>
          <td><?= esc($o['id']) ?></td>
          <td><?= esc($o['custName']) ?></td>
          <td><?= esc($o['itemsText']) ?></td>
          <td><?= esc($o['del']) ?></td>
          <td><?= esc($o['paymentLabel'] ?? 'Cash on Delivery') ?></td>
          <td><?= esc($o['status']) ?></td>
          <td><?= esc($o['date']) ?></td>
          <td><?= App\Libraries\DataStore::fmt($o['total']) ?></td>
        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
  <tfoot>
    <tr><td colspan="7">Total</td><td><?= App\Libraries\DataStore::fmt($total) ?></td></tr>
  </tfoot>
</table>

<script>window.onload = () => window.print();</script>
</body>
</html>
