<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $title ?? "Sign in — Alyanah's Homemade" ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<nav>
  <a class="logo" href="<?= site_url('/') ?>">Alyanah's <span>Homemade</span></a>
  <div class="nav-right">
    <a class="nbtn" href="<?= site_url('/') ?>">Back to site</a>
  </div>
</nav>

<div style="position:relative;min-height:calc(100svh - 54px);display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,var(--brown) 0%,var(--brown2) 55%,var(--orange) 170%);overflow:hidden">
  <img src="<?= base_url('assets/images/Background.png') ?>" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.55" onerror="this.style.display='none'">
  <div style="position:absolute;inset:0;background:linear-gradient(165deg,rgba(67,44,20,.65),rgba(67,44,20,.35))"></div>

  <div class="auth-card" style="position:relative;z-index:1;margin:20px auto">
    <div class="auth-logo">
      <img src="<?= base_url('assets/images/Logo.png') ?>" alt="Alyanah's Homemade logo" onerror="this.outerHTML='<div class=&quot;auth-logo-badge&quot;>A</div>'">
    </div>
    <h1 class="auth-title">Welcome back</h1>

    <?php if (session()->getFlashdata('error')) : ?>
      <p style="background:#fdeceb;color:#c0392b;border:1px solid #f3c6c1;border-radius:6px;padding:10px 14px;font-size:12px;margin-bottom:14px">
        <?= esc(session()->getFlashdata('error')) ?>
      </p>
    <?php endif; ?>

    <?php if (session()->getFlashdata('message')) : ?>
      <p style="background:#eafaf1;color:#1e7e45;border:1px solid #bfe8cf;border-radius:6px;padding:10px 14px;font-size:12px;margin-bottom:14px">
        <?= esc(session()->getFlashdata('message')) ?>
      </p>
    <?php endif; ?>

    <form method="post" action="<?= site_url('login') ?>">
      <input class="auth-input" type="email" name="email" placeholder="Email address" value="<?= esc(old('email')) ?>" required autofocus>
      <input class="auth-input" type="password" name="password" placeholder="Password" required>
      <button type="submit" class="btn btn-orange" style="width:100%;justify-content:center;margin-top:4px">Sign in</button>
    </form>

    <p style="text-align:center;margin-top:14px;font-size:12px;color:var(--gray3)">
      No account? <a href="<?= site_url('register') ?>" style="color:var(--orange);text-decoration:underline">Create one</a>
    </p>
    <p style="text-align:center;margin-top:8px;font-size:11px;color:var(--gray2)">
      Demo: use <strong>admin@alyanah.com</strong> for admin access
    </p>
  </div>
</div>

<?= view('layouts/_footer') ?>

</body>
</html>
