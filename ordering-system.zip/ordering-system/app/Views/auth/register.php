<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $title ?? "Create account — Alyanah's Homemade" ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<nav>
  <a class="logo" href="<?= site_url('/') ?>">Alyanah's <span>Homemade</span></a>
  <div class="nav-right">
    <a class="nbtn" href="<?= site_url('/') ?>">Back to site</a>
  </div>
</nav>

<div class="auth-page">
  <div class="auth-visual">
    <img class="auth-bg-img" src="<?= base_url('assets/images/Background.png') ?>" alt="" onerror="this.style.display='none'">
    <div class="auth-bg-overlay"></div>
    <div class="auth-visual-text">
      <h2>Join Alyanah's Homemade</h2>
      <p>Create an account to order, track your deliveries, and keep a history of everything you've ordered.</p>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-logo">
      <img src="<?= base_url('assets/images/Logo.png') ?>" alt="Alyanah's Homemade logo" onerror="this.outerHTML='<div class=&quot;auth-logo-badge&quot;>A</div>'">
    </div>
    <div class="auth-card">
      <h1 class="auth-title">Create account</h1>

      <?php if (session()->getFlashdata('error')) : ?>
        <p style="background:#fdeceb;color:#c0392b;border:1px solid #f3c6c1;border-radius:6px;padding:10px 14px;font-size:12px;margin-bottom:14px">
          <?= esc(session()->getFlashdata('error')) ?>
        </p>
      <?php endif; ?>

      <form method="post" action="<?= site_url('register') ?>">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
          <input class="auth-input" type="text" name="fname" placeholder="First name" value="<?= esc(old('fname')) ?>" style="margin-bottom:0" required>
          <input class="auth-input" type="text" name="lname" placeholder="Last name" value="<?= esc(old('lname')) ?>" style="margin-bottom:0">
        </div>
        <input class="auth-input" type="email" name="email" placeholder="Email address" value="<?= esc(old('email')) ?>" required>
        <input class="auth-input" type="tel" name="phone" placeholder="Phone number" value="<?= esc(old('phone')) ?>">
        <input class="auth-input" type="text" name="address" placeholder="Home address" value="<?= esc(old('address')) ?>">
        <input class="auth-input" type="password" name="password" placeholder="Password (min 6 characters)" required>
        <button type="submit" class="btn btn-orange" style="width:100%;justify-content:center;margin-top:4px">Create account</button>
      </form>

      <p style="text-align:center;margin-top:14px;font-size:12px;color:var(--gray3)">
        Already have an account? <a href="<?= site_url('login') ?>" style="color:var(--orange);text-decoration:underline">Sign in</a>
      </p>
    </div>
  </div>
</div>

<?= view('layouts/_footer') ?>

</body>
</html>