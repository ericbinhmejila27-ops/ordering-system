<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<?php if (empty($lines)) : ?>
  <div class="empty-state">
    <h2>Your cart is empty</h2>
    <p>Browse our menu and add your favorites.</p>
    <a class="btn btn-orange" href="<?= site_url('customer/menu') ?>">Browse Menu</a>
  </div>
<?php else : ?>
  <div class="cart-page">
    <h1 class="cart-title">Your Cart</h1>
    <div class="cart-layout">
      <div>
        <?php foreach ($lines as $item) : ?>
          <div class="cart-item">
            <div class="ci-img" style="background:<?= esc($item['bg'] ?? '#f5e0d0') ?>;overflow:hidden">
              <?php if (! empty($item['img'])) : ?>
                <img src="<?= base_url($item['img']) ?>" alt="<?= esc($item['name']) ?>" style="width:100%;height:100%;object-fit:cover" onerror="this.outerHTML='<?= esc($item['emoji'] ?? '🍽️') ?>'">
              <?php else : ?>
                <?= $item['emoji'] ?? '🍽️' ?>
              <?php endif; ?>
            </div>
            <div style="flex:1">
              <p class="ci-name"><?= esc($item['name']) ?></p>
              <p class="ci-variant"><?= App\Libraries\DataStore::fmt($item['price']) ?> each</p>
              <?php $stock = $item['stock'] ?? null; $atMax = $stock !== null && $item['qty'] >= $stock; ?>
              <?php if ($stock !== null && $item['qty'] > $stock) : ?>
                <p style="font-size:11px;color:#842029;margin-bottom:4px"><?= $stock > 0 ? "Only {$stock} left — please lower the quantity." : 'Sold out — please remove this item.' ?></p>
              <?php elseif ($atMax) : ?>
                <p style="font-size:11px;color:#856404;margin-bottom:4px">That's all we have left.</p>
              <?php endif; ?>
              <form method="post" action="<?= site_url('customer/cart/update/' . $item['id']) ?>" class="qty-row">
                <button type="submit" class="qbtn" name="qty" value="<?= $item['qty'] - 1 ?>">−</button>
                <span style="font-size:13px;min-width:18px;text-align:center"><?= $item['qty'] ?></span>
                <button type="submit" class="qbtn" name="qty" value="<?= $item['qty'] + 1 ?>" <?= $atMax ? 'disabled style="opacity:.35;cursor:not-allowed"' : '' ?>>+</button>
              </form>
              <form method="post" action="<?= site_url('customer/cart/remove/' . $item['id']) ?>" style="margin-top:4px">
                <button type="submit" class="rm-btn">Remove</button>
              </form>
            </div>
            <strong style="font-size:14px;color:var(--brown3)"><?= App\Libraries\DataStore::fmt($item['lineTotal']) ?></strong>
          </div>
        <?php endforeach; ?>
        <a class="btn btn-outline btn-sm" href="<?= site_url('customer/menu') ?>" style="margin-top:16px">+ Add more items</a>
      </div>
      <div class="order-summary">
        <p class="os-title">Order Summary</p>
        <?php foreach ($lines as $item) : ?>
          <div class="os-row"><span><?= esc($item['name']) ?> ×<?= $item['qty'] ?></span><span><?= App\Libraries\DataStore::fmt($item['lineTotal']) ?></span></div>
        <?php endforeach; ?>
        <div class="os-row"><span>Delivery fee</span><span><?= $deliveryFee === 0 ? '<span style="color:#27ae60">Free</span>' : App\Libraries\DataStore::fmt($deliveryFee) ?></span></div>
        <div class="os-total"><span>Total</span><span style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($total) ?></span></div>
        <a class="btn btn-orange" style="width:100%;justify-content:center" href="<?= site_url('customer/checkout') ?>">Proceed to checkout</a>
        <?php if ($subtotal < 500) : ?>
          <p style="font-size:11px;color:var(--gray3);text-align:center;margin-top:10px">Add <?= App\Libraries\DataStore::fmt(500 - $subtotal) ?> more for free delivery!</p>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endif; ?>

<?= $this->endSection() ?>  