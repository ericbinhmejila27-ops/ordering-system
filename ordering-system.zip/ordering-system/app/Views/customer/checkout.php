<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<style>
  /* Compact checkout: everything fits on one screen without scrolling */
  .co-wrap{max-width:880px;margin:0 auto;padding:22px 28px 28px}
  .co-title{font-family:var(--serif);font-weight:400;font-size:26px;color:var(--brown3);margin-bottom:14px}
  .co-grid{display:grid;grid-template-columns:1fr 280px;gap:22px;align-items:start}
  .co-h{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--gray3);margin:12px 0 8px}
  .co-h:first-child{margin-top:0}
  .co-2{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
  .co-3{display:grid;grid-template-columns:repeat(3,1fr);gap:0 8px}
  .co-wrap .auth-input{margin-bottom:8px;padding:9px 12px}
  .co-wrap .del-opt{padding:8px 10px;margin-bottom:0}
  .co-wrap .order-summary{position:sticky;top:12px}
  @media (max-width:760px){.co-grid,.co-2,.co-3{grid-template-columns:1fr}.co-wrap .del-opt{margin-bottom:6px}}
</style>

<div class="co-wrap">
  <h1 class="co-title">Checkout</h1>
  <form method="post" action="<?= site_url('customer/checkout') ?>" enctype="multipart/form-data">
    <div class="co-grid">
      <div>
        <h3 class="co-h">Delivery details</h3>
        <div class="co-2">
          <input class="auth-input" name="name" placeholder="Full name" value="<?= esc(old('name') ?? session()->get('name')) ?>" required>
          <input class="auth-input" name="phone" placeholder="Phone number" type="tel" value="<?= esc(old('phone') ?? session()->get('phone')) ?>" required>
          <input class="auth-input" name="address" placeholder="Delivery address" value="<?= esc(old('address') ?? session()->get('address')) ?>">
          <input class="auth-input" name="notes" placeholder="Order notes (e.g. no onions)">
        </div>

        <h3 class="co-h">Delivery method</h3>
        <div class="co-2">
          <label class="del-opt"><input type="radio" name="delivery" value="delivery" checked> 🛵 Delivery</label>
          <label class="del-opt"><input type="radio" name="delivery" value="pickup"> 🏠 Pick-up</label>
        </div>

        <h3 class="co-h">Payment method</h3>
        <div class="co-3">
          <label class="del-opt"><input type="radio" name="payment" value="cod" checked onclick="showPaymentInfo('cod')"> Cash on Delivery</label>
          <label class="del-opt"><input type="radio" name="payment" value="gcash" onclick="showPaymentInfo('gcash')"> GCash</label>
          <label class="del-opt"><input type="radio" name="payment" value="bank" onclick="showPaymentInfo('bank')"> Bank Transfer</label>
        </div>

        <?php $pay = App\Libraries\DataStore::paymentInfo(); ?>
        <div id="gcash-info" style="display:none;margin-top:8px;padding:8px 12px;background:var(--cream2);border:1px solid var(--gray2);border-radius:8px;font-size:12px;color:var(--brown3)">
          Send payment to GCash <strong><?= esc($pay['gcash_number']) ?></strong> (<?= esc($pay['gcash_name']) ?>)
        </div>
        <div id="bank-info" style="display:none;margin-top:8px;padding:8px 12px;background:var(--cream2);border:1px solid var(--gray2);border-radius:8px;font-size:12px;color:var(--brown3)">
          Send payment to <strong><?= esc($pay['bank_name']) ?></strong> — <?= esc($pay['bank_account_name']) ?> — Acct # <strong><?= esc($pay['bank_account_number']) ?></strong>
        </div>

        <div id="gcash-qr" style="display:none;margin-top:12px;padding:14px;background:var(--white);border:1px solid var(--gray2);border-radius:10px;text-align:center">
          <img src="<?= base_url($pay['gcash_qr']) ?>" alt="GCash QR code" style="width:180px;height:180px;object-fit:contain;border-radius:8px;background:#fff">
        </div>
        <div id="bank-qr" style="display:none;margin-top:12px;padding:14px;background:var(--white);border:1px solid var(--gray2);border-radius:10px;text-align:center">
          <img src="<?= base_url($pay['bank_qr']) ?>" alt="Bank QR code" style="width:180px;height:180px;object-fit:contain;border-radius:8px;background:#fff">
        </div>

        <div id="payment-proof-fields" style="display:none;margin-top:8px;padding:10px 12px;background:var(--white);border:1px solid var(--gray2);border-radius:8px">
          <p style="font-size:11px;color:var(--gray3);line-height:1.5;margin-bottom:8px">Send your payment first, then enter the reference number (screenshot optional) so we can confirm it.</p>

          <label style="display:block;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--gray3);margin-bottom:6px">How much are you paying now?</label>
          <div class="co-2" style="margin-bottom:8px">
          <label class="del-opt"><input type="radio" name="payment_type" value="full" checked onclick="document.getElementById('downpayment-note').style.display='none'"> <span>Full payment now (<span class="dp-total"><?= App\Libraries\DataStore::fmt($total) ?></span>)</span></label>
          <label class="del-opt"><input type="radio" name="payment_type" value="partial" onclick="document.getElementById('downpayment-note').style.display='block'"> 50% down payment now</label>
          </div>
          <p id="downpayment-note" style="display:none;font-size:11px;color:var(--gray3);line-height:1.6;margin:0 0 8px">A 50% down payment (<span class="dp-half"><?= App\Libraries\DataStore::fmt((int) round($total / 2)) ?></span>) is required now. The remaining <span class="dp-half"><?= App\Libraries\DataStore::fmt($total - (int) round($total / 2)) ?></span> is paid on delivery.</p>

          <div class="co-2">
            <input class="auth-input" name="payref" placeholder="Reference / transaction number" style="margin-bottom:0">
            <input type="file" name="payproof" accept="image/*" class="auth-input" title="Payment screenshot (optional)" style="padding:6px;margin-bottom:0">
          </div>
        </div>
      </div>
      <div class="order-summary">
        <p class="os-title">Your Order</p>
        <?php foreach ($lines as $item) : ?>
          <div class="os-row"><span><?= $item['emoji'] ?? '' ?> <?= esc($item['name']) ?> ×<?= $item['qty'] ?></span><span><?= App\Libraries\DataStore::fmt($item['lineTotal']) ?></span></div>
        <?php endforeach; ?>
        <div class="os-row"><span>Delivery</span><span><?= $deliveryFee === 0 ? 'Free' : App\Libraries\DataStore::fmt($deliveryFee) ?></span></div>
        <div class="os-total"><span>Total</span><span style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($total) ?></span></div>
        <div class="os-row" id="due-now-row" style="display:none;font-weight:600"><span>Due now (50% down payment)</span><span style="color:var(--orange)"><?= App\Libraries\DataStore::fmt((int) round($total / 2)) ?></span></div>
        <button type="submit" class="btn btn-orange" style="width:100%;justify-content:center">Place Order</button>
      </div>
    </div>
  </form>
</div>

<script>
  function showPaymentInfo(method) {
    document.getElementById('payment-proof-fields').style.display = (method === 'cod') ? 'none' : 'block';
    document.getElementById('gcash-info').style.display = (method === 'gcash') ? 'block' : 'none';
    document.getElementById('bank-info').style.display = (method === 'bank') ? 'block' : 'none';
    document.getElementById('gcash-qr').style.display = (method === 'gcash') ? 'block' : 'none';
    document.getElementById('bank-qr').style.display = (method === 'bank') ? 'block' : 'none';
  }
  document.querySelectorAll('input[name="payment_type"]').forEach(function (r) {
    r.addEventListener('change', function () {
      document.getElementById('due-now-row').style.display = (this.value === 'partial') ? 'flex' : 'none';
    });
  });
  document.querySelectorAll('input[name="payment"]').forEach(function (r) {
    r.addEventListener('change', function () {
      if (this.value === 'cod') {
        document.getElementById('due-now-row').style.display = 'none';
      }
    });
  });
</script>

<?= $this->endSection() ?>