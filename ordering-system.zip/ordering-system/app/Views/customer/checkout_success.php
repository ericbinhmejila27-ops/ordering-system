<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<div style="text-align:center;padding:80px 40px;background:var(--cream)">
  <div style="font-size:56px;margin-bottom:16px">🎉</div>
  <h2 style="font-family:var(--serif);font-weight:400;font-size:30px;color:var(--brown3);margin-bottom:10px">Order placed!</h2>
  <p style="color:var(--gray3);font-size:13px;margin-bottom:8px">Your order <strong><?= esc($order['id']) ?></strong> has been received.</p>
  <p style="color:var(--gray3);font-size:13px;margin-bottom:8px">We'll prepare it fresh and notify you when it's ready.</p>
  <?php if (($order['paymentType'] ?? 'full') === 'partial') : ?>
    <p style="color:var(--brown3);font-size:13px;font-weight:600;margin-bottom:28px">Down payment received: <?= App\Libraries\DataStore::fmt($order['amountPaid']) ?> — balance of <?= App\Libraries\DataStore::fmt($order['balance']) ?> due on delivery.</p>
  <?php else : ?>
    <p style="margin-bottom:28px"></p>
  <?php endif; ?>
  <div style="display:flex;gap:10px;justify-content:center">
    <a class="btn btn-orange" href="<?= site_url('customer/track-order') ?>">Track my order</a>
    <a class="btn btn-outline" href="<?= site_url('customer/menu') ?>">Order more</a>
  </div>
</div>

<?= $this->endSection() ?>