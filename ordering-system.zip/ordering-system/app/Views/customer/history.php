<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<div class="section section-tight-top order-page">
  <div class="section-hdr section-hdr-left" style="margin-bottom:2px">
    <p class="eyebrow">Your account</p>
  </div>

  <div style="display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:4px">
    <h2 class="section-title" style="margin:0">Order History</h2>

    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <?php foreach (['all' => 'All time', 'month' => 'This month', '3months' => 'Last 3 months'] as $val => $label) : ?>
        <a class="btn btn-sm <?= $period === $val ? 'btn-brown' : 'btn-outline' ?>" href="<?= site_url('customer/history') . ($val === 'all' ? '' : '?period=' . $val) ?>"><?= $label ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <p class="section-sub" style="margin:0 0 14px">All your past orders with Alyanah's Homemade.</p>

  <?php if (empty($orders)) : ?>
    <p style="font-size:12px;color:var(--gray3)">
      <?php if ($period !== 'all') : ?>
        No delivered orders in this period. <a href="<?= site_url('customer/history') ?>" style="color:var(--orange)">View all time</a>.
      <?php else : ?>
        You haven't placed any orders yet. <a href="<?= site_url('customer/menu') ?>" style="color:var(--orange)">Browse the menu</a> to get started!
      <?php endif; ?>
    </p>
  <?php else : ?>
    <?php foreach ($orders as $o) : ?>
      <?php $statusClass = $o['status'] === 'on delivery' ? 'ready' : $o['status']; ?>
      <div class="orow">
        <div><strong style="font-size:13px;color:var(--brown3)"><?= esc($o['id']) ?></strong><br><span style="font-size:11px;color:var(--gray3)"><?= esc($o['date']) ?></span></div>
        <span class="sbadge s-<?= esc($statusClass) ?>"><?= esc(ucfirst($o['status'])) ?></span>
        <strong style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($o['total']) ?></strong>
        <a href="<?= site_url('customer/order/view/' . $o['id']) ?>" class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px">View Details</a>
      </div>
    <?php endforeach; ?>
    <?php if ($totalPages > 1) : ?>
      <nav class="order-pagination" aria-label="Order history pages">
        <?php for ($pageNumber = 1; $pageNumber <= $totalPages; $pageNumber++) : ?>
          <a class="<?= $page === $pageNumber ? 'active' : '' ?>"
             href="<?= site_url('customer/history') . '?' . http_build_query(array_filter(['period' => $period === 'all' ? null : $period, 'page' => $pageNumber > 1 ? $pageNumber : null])) ?>"
             <?= $page === $pageNumber ? 'aria-current="page"' : '' ?>><?= $pageNumber ?></a>
        <?php endfor; ?>
      </nav>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?= $this->endSection() ?>