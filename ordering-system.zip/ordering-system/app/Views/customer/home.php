<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<div class="hero" style="position:relative;background:radial-gradient(ellipse 700px 550px at center,rgba(15,10,6,.72) 0%,rgba(15,10,6,.45) 45%,rgba(15,10,6,.1) 75%,transparent 100%),url('<?= base_url('assets/images/Background.png') ?>') top center/cover no-repeat">
  <div class="hero-left">
    <p class="hero-tag">Homemade with love — Cagayan de Oro</p>
    <h1 class="hero-title">Fresh from<br>Alyanah's<br><em>Kitchen</em></h1>
    <p class="hero-sub">Order our signature homemade lasagna, leche flan, brownies, butterscotch, and lengua de gato — delivered right to your door.</p>
    <div class="hero-btns">
      <a class="btn btn-orange" href="<?= site_url('customer/menu') ?>">Order Now</a>
    </div>
  </div>
</div>

<div class="section">
  <div class="section-hdr">
    <p class="eyebrow">What we make</p>
    <h2 class="section-title">Our Menu</h2>
    <p class="section-sub">All items are made fresh per order — homemade with quality ingredients and lots of love.</p>
  </div>

  <div class="menu-grid">
    <?php foreach ($menu as $p) : ?>
      <?= view('partials/menu_card', ['p' => $p, 'context' => 'customer']) ?>
    <?php endforeach; ?>
  </div>

  <div style="text-align:center;margin-top:28px">
    <a class="btn btn-brown" href="<?= site_url('customer/menu') ?>">View Full Menu</a>
  </div>
</div>

<div class="delivery-section">
  <p class="eyebrow" style="color:var(--orange2)">Delivery options</p>
  <h2 style="font-family:var(--serif);font-size:30px;font-weight:400;margin-bottom:8px">Pick your delivery method</h2>
  <p style="font-size:13px;color:rgba(255,255,255,.45);max-width:400px;margin:0 auto">Choose how you want to receive your order — we work with your preferred platform.</p>
  <div class="delivery-cards">
    <div class="del-card">
      <div class="del-icon">🟢</div>
      <div class="del-name">GrabFood</div>
      <div class="del-desc">Order through Grab for fast delivery tracked right on your phone.</div>
    </div>
    <div class="del-card">
      <div class="del-icon">🟡</div>
      <div class="del-name">FoodPanda</div>
      <div class="del-desc">Order via FoodPanda for convenient delivery with live tracking.</div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
