<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<?php
$statusLabels = ['pending' => 'Pending', 'preparing' => 'Preparing', 'on delivery' => 'On Delivery', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
$statusClass  = $o['status'] === 'on delivery' ? 'ready' : $o['status'];
$payMethod    = $o['paymentMethod'] ?? 'cod';
$payLabel     = $o['paymentLabel'] ?? ($payMethod === 'cod' ? 'Cash on Delivery' : $payMethod);
$backTo       = $o['status'] === 'delivered' ? 'customer/history' : 'customer/track-order';
?>

<div style="max-width:480px;margin:0 auto;padding:56px 28px">
  <a class="btn btn-outline btn-sm" href="<?= site_url($backTo) ?>" style="margin-bottom:18px;display:inline-block">← Back</a>

  <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:28px 24px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div>
        <p style="font-family:var(--serif);font-size:20px;color:var(--brown3)"><?= esc($o['id']) ?></p>
        <p style="font-size:11px;color:var(--gray3);margin-top:2px"><?= esc($o['date']) ?></p>
      </div>
      <span class="sbadge s-<?= esc($statusClass) ?>"><?= esc($statusLabels[$o['status']] ?? $o['status']) ?></span>
    </div>

    <?php if (($o['refundStatus'] ?? 'none') !== 'none') : ?>
      <div style="margin-bottom:14px">
        <?php if ($o['refundStatus'] === 'pending') : ?>
          <span class="sbadge" style="background:#fff3cd;color:#856404">Refund Pending</span>
        <?php else : ?>
          <span class="sbadge s-delivered">Refunded</span>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div style="border-top:1px dashed var(--gray2);border-bottom:1px dashed var(--gray2);padding:14px 0;margin-bottom:14px">
      <p style="font-size:11px;color:var(--gray3);margin-bottom:2px">Customer</p>
      <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= esc($o['custName']) ?><?= ! empty($o['custPhone']) ? ' · ' . esc($o['custPhone']) : '' ?></p>
      <p style="font-size:11px;color:var(--gray3);margin-bottom:2px">Delivery address</p>
      <p style="font-size:13px;color:var(--brown3)"><?= esc($o['del'] ?? '—') ?></p>
    </div>

    <div style="margin-bottom:14px">
      <p style="font-size:11px;color:var(--gray3);margin-bottom:6px">Items</p>
      <?php foreach (array_filter(array_map('trim', explode(',', $o['itemsText'] ?? ''))) as $line) : ?>
        <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--brown3);padding:4px 0"><?= esc($line) ?></div>
      <?php endforeach; ?>
    </div>

    <div style="border-top:1px solid var(--gray2);padding-top:10px;display:flex;justify-content:space-between;font-weight:500;color:var(--brown3);margin-bottom:14px">
      <span>Total</span><span style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($o['total']) ?></span>
    </div>

    <div style="border-top:1px dashed var(--gray2);padding-top:14px">
      <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Payment method</p>
      <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= esc($payLabel) ?></p>

      <?php if ($payMethod !== 'cod') : ?>
        <?php if (($o['paymentType'] ?? 'full') === 'partial') : ?>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Down payment paid</p>
          <p style="font-size:13px;color:var(--brown3);margin-bottom:6px"><?= App\Libraries\DataStore::fmt($o['amountPaid'] ?? 0) ?></p>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Balance on delivery (cash)</p>
          <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= App\Libraries\DataStore::fmt($o['balance'] ?? 0) ?></p>
        <?php else : ?>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Amount paid</p>
          <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= App\Libraries\DataStore::fmt($o['amountPaid'] ?? $o['total']) ?></p>
        <?php endif; ?>

        <?php if (! empty($o['paymentRef'])) : ?>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:4px">Reference number</p>
          <p style="font-size:13px;color:var(--brown3);margin-bottom:10px"><?= esc($o['paymentRef']) ?></p>
        <?php endif; ?>

        <?php if (! empty($o['paymentProof'])) : ?>
          <p style="font-size:11px;color:var(--gray3);margin-bottom:6px">Payment screenshot you submitted</p>
          <img src="<?= base_url($o['paymentProof']) ?>" alt="Payment proof" style="width:100%;border-radius:8px;border:1px solid var(--gray2);margin-bottom:10px">
        <?php endif; ?>

        <?php if (($o['paymentStatus'] ?? '') === 'verified') : ?>
          <span class="sbadge s-delivered">Payment verified</span>
        <?php else : ?>
          <span class="sbadge" style="background:#fff3cd;color:#856404">Awaiting verification</span>
        <?php endif; ?>
      <?php else : ?>
        <span class="sbadge" style="background:#e2e3e5;color:#41464b">Pay on delivery</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<?= $this->endSection() ?>