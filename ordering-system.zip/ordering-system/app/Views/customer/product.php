<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<?php
$available = ($item['avail'] ?? true) !== false;
$stock     = $item['stock'] ?? null;
$maxQty    = $stock !== null ? max(1, min(20, $stock)) : 20;
?>
<div style="max-width:800px;margin:0 auto;padding:48px 28px">
  <a class="btn btn-outline btn-sm" href="<?= site_url('customer/menu') ?>" style="margin-bottom:24px">← Back to menu</a>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;background:var(--white);border:1px solid var(--gray2);border-radius:12px;overflow:hidden">
    <div style="background:<?= esc($item['bg'] ?? '#f5e0d0') ?>;display:flex;align-items:center;justify-content:center;min-height:280px;font-size:100px;overflow:hidden">
      <?php if (! empty($item['img'])) : ?>
        <img src="<?= base_url($item['img']) ?>" alt="<?= esc($item['name']) ?>" style="width:100%;height:100%;object-fit:cover" onerror="this.outerHTML='<?= esc($item['emoji'] ?? '🍽️') ?>'">
      <?php else : ?>
        <?= $item['emoji'] ?? '🍽️' ?>
      <?php endif; ?>
    </div>
    <div style="padding:32px">
      <?php if (! empty($item['badge'])) : ?>
        <span class="mc-badge badge-<?= esc($item['badge']) ?>" style="display:inline-block;margin-bottom:12px"><?= $item['badge'] === 'bestseller' ? 'Best Seller' : ucfirst($item['badge']) ?></span>
      <?php endif; ?>
      <h1 style="font-family:var(--serif);font-size:28px;font-weight:400;color:var(--brown3);margin-bottom:10px"><?= esc($item['name']) ?></h1>
      <p style="font-size:13px;color:var(--gray3);line-height:1.7;margin-bottom:16px"><?= esc($item['desc']) ?></p>
      <p style="font-size:22px;font-weight:500;color:var(--orange);margin-bottom:20px"><?= App\Libraries\DataStore::fmt($item['price']) ?></p>

      <?php if ($available) : ?>
        <form method="post" action="<?= site_url('customer/cart/add/' . $item['id']) ?>">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px">
            <select name="qty" style="border:1px solid var(--gray2);border-radius:4px;font-size:13px;padding:8px 10px;background:var(--cream)">
              <?php for ($i = 1; $i <= $maxQty; $i++) : ?><option value="<?= $i ?>"><?= $i ?></option><?php endfor; ?>
            </select>
          </div>
          <div style="display:flex;gap:8px">
            <button type="submit" class="btn btn-orange" style="flex:1">Add to cart</button>
            <a class="btn btn-outline" href="<?= site_url('customer/cart') ?>">View cart</a>
          </div>
        </form>
        <?php if ($stock !== null && $stock <= ($item['lowStock'] ?? 5)) : ?>
          <p style="font-size:11px;color:#b3261e;margin-top:14px;font-weight:500">Only <?= $stock ?> left — order soon!</p>
        <?php elseif ($stock !== null) : ?>
          <p style="font-size:11px;color:#27ae60;margin-top:14px;font-weight:500">✓ In stock — <?= $stock ?> available</p>
        <?php else : ?>
          <p style="font-size:11px;color:#27ae60;margin-top:14px;font-weight:500">✓ Available — made fresh per order</p>
        <?php endif; ?>
      <?php else : ?>
        <p style="font-size:12px;color:#842029;font-weight:500;padding:12px 14px;background:#f8d7da;border-radius:6px;margin-bottom:14px">This item is currently sold out. Please check back later or browse our other items.</p>
        <a class="btn btn-outline" href="<?= site_url('customer/menu') ?>">Browse other items</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?= $this->endSection() ?>