<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<div style="max-width:420px;margin:0 auto;padding:56px 28px">
  <a href="javascript:history.back()" class="btn btn-sm btn-outline" style="margin-bottom:16px;display:inline-flex">← Back</a>
  <div class="section-hdr">
    <p class="eyebrow">Your account</p>
    <h2 class="section-title">Profile</h2>
    <p class="section-sub" style="margin-top:8px">Update your details below. Looking for your orders? Check <a href="<?= site_url('customer/history') ?>" style="color:var(--orange)">Order History</a>.</p>
  </div>
  <form method="post" action="<?= site_url('customer/profile') ?>">
    <input class="auth-input" name="name" value="<?= esc(old('name') ?? $customerName) ?>" placeholder="Name">
    <input class="auth-input" value="<?= esc($customerEmail) ?>" placeholder="Email" type="email" disabled style="background:var(--gray);color:var(--gray3);cursor:not-allowed">
    <input class="auth-input" name="phone" value="<?= esc(old('phone') ?? $customerPhone) ?>" placeholder="Phone number" type="tel">
    <input class="auth-input" name="address" value="<?= esc(old('address') ?? $customerAddress) ?>" placeholder="Home address">
    <button type="submit" class="btn btn-orange" style="width:100%;justify-content:center;margin-top:4px">Save changes</button>
  </form>
</div>

<?= $this->endSection() ?>