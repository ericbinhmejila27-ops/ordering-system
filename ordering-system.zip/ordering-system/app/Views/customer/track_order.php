<?= $this->extend('layouts/customer_layout') ?>
<?= $this->section('content') ?>

<div class="section section-tight-top order-page">
  <div class="section-hdr section-hdr-left" style="margin-bottom:2px">
    <p class="eyebrow">Order tracking</p>
  </div>

  <div style="display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:4px">
    <h2 class="section-title" style="margin:0">Track your order</h2>

    <form method="post" action="<?= site_url('customer/track-order') ?>" style="display:flex;gap:8px;width:100%;max-width:360px">
      <input class="auth-input" name="order_id" placeholder="e.g. ORD-1234" style="flex:1;margin-bottom:0" value="<?= esc($trackId ?? '') ?>">
      <button type="submit" class="btn btn-orange">Track</button>
    </form>
  </div>

  <p class="section-sub" style="margin:0 0 28px">Enter your order number to check the status.</p>

  <?php if ($trackId !== null) : ?>
    <?php if ($found === false && $isDelivered) : ?>
      <p style="font-size:12px;color:var(--gray3)">This order has already been delivered. Check <a href="<?= site_url('customer/history') ?>" style="color:var(--orange)">Order History</a> for the details.</p>
    <?php elseif ($found === false) : ?>
      <p style="font-size:12px;color:#842029">Order number not found.</p>
    <?php elseif ($found) :
      $steps  = ['pending', 'preparing', 'on delivery', 'delivered'];
      $idx    = array_search($found['status'], $steps, true);
      $labels = ['pending' => 'Order received', 'preparing' => 'Being prepared', 'on delivery' => 'On Delivery', 'delivered' => 'Delivered'];
      $statusClass = $found['status'] === 'on delivery' ? 'ready' : $found['status'];
      $isCancelled = $found['status'] === 'cancelled';
    ?>
      <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:24px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
          <div><strong style="color:var(--brown3);font-size:15px"><?= esc($found['id']) ?></strong></div>
          <span class="sbadge s-<?= esc($statusClass) ?>"><?= esc($labels[$found['status']] ?? $found['status']) ?></span>
        </div>
        <?php if ($isCancelled) : ?>
          <p style="color:#842029;font-size:12px;text-align:center;margin-bottom:16px">This order was cancelled.</p>
        <?php else : ?>
          <div style="display:flex;align-items:center;gap:0;margin-bottom:16px">
            <?php foreach ($steps as $i => $s) : ?>
              <div style="flex:1;display:flex;flex-direction:column;align-items:center;position:relative">
                <?php if ($i < count($steps) - 1) : ?>
                  <div style="position:absolute;top:13px;left:50%;width:100%;height:2px;background:<?= $i < $idx ? 'var(--orange)' : 'var(--gray2)' ?>"></div>
                <?php endif; ?>
                <div style="width:26px;height:26px;border-radius:50%;background:<?= $i <= $idx ? 'var(--orange)' : 'var(--gray2)' ?>;display:flex;align-items:center;justify-content:center;position:relative;z-index:1">
                  <?= $i <= $idx ? '<span style="color:#fff;font-size:11px">✓</span>' : '' ?>
                </div>
                <p style="font-size:9px;text-transform:uppercase;letter-spacing:.06em;color:<?= $i <= $idx ? 'var(--brown3)' : 'var(--gray3)' ?>;margin-top:6px;text-align:center;font-weight:<?= $i === $idx ? '500' : '400' ?>"><?= $labels[$s] ?></p>
              </div>
            <?php endforeach; ?>
          </div>
          <p style="font-size:12px;color:var(--gray3);text-align:center">Estimated delivery: 30–45 minutes</p>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($mine) :
    $rowLabels = ['pending' => 'Pending', 'preparing' => 'Preparing', 'on delivery' => 'On Delivery', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
  ?>
    <div style="margin-top:20px">
      <h3 style="font-family:var(--serif);font-weight:400;font-size:20px;color:var(--brown3);margin-bottom:12px">Your recent orders</h3>
      <?php foreach ($mine as $o) : ?>
        <?php $statusClass = $o['status'] === 'on delivery' ? 'ready' : $o['status']; ?>
        <div class="orow">
          <div><strong style="font-size:13px;color:var(--brown3)"><?= esc($o['id']) ?></strong><br><span style="font-size:11px;color:var(--gray3)"><?= esc($o['itemsText']) ?> · <?= esc($o['date']) ?></span></div>
          <span class="sbadge s-<?= esc($statusClass) ?>"><?= esc($rowLabels[$o['status']] ?? $o['status']) ?></span>
          <?php if (($o['refundStatus'] ?? 'none') === 'pending') : ?>
            <span class="sbadge" style="background:#fff3cd;color:#856404">Refund Pending</span>
          <?php elseif (($o['refundStatus'] ?? 'none') === 'refunded') : ?>
            <span class="sbadge s-delivered">Refunded</span>
          <?php endif; ?>
          <strong style="color:var(--orange)"><?= App\Libraries\DataStore::fmt($o['total']) ?></strong>
          <a href="<?= site_url('customer/order/view/' . $o['id']) ?>" class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px">View Details</a>
          <?php if ($o['status'] === 'pending') : ?>
            <form method="post" action="<?= site_url('customer/history/cancel/' . $o['id']) ?>" onsubmit="return confirm('Cancel order <?= esc($o['id']) ?>? This can\'t be undone.')">
              <button type="submit" class="btn btn-sm btn-outline" style="padding:4px 10px;font-size:10px;border-color:#b3261e;color:#b3261e">Cancel</button>
            </form>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?php if ($totalPages > 1) : ?>
        <nav class="order-pagination" aria-label="Recent order pages">
          <?php for ($pageNumber = 1; $pageNumber <= $totalPages; $pageNumber++) : ?>
            <a class="<?= $page === $pageNumber ? 'active' : '' ?>"
               href="<?= site_url('customer/track-order') . ($pageNumber > 1 ? '?page=' . $pageNumber : '') ?>"
               <?= $page === $pageNumber ? 'aria-current="page"' : '' ?>><?= $pageNumber ?></a>
          <?php endfor; ?>
        </nav>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<?= $this->endSection() ?>