<?= $this->extend('layouts/guest_layout') ?>
<?= $this->section('content') ?>

<div class="about-section">
  <div class="about-inner">
    <div class="about-img">
      <img src="<?= base_url('assets/images/Profile.png') ?>" alt="Assorted homemade desserts by Alyanah's Homemade" style="width:100%;height:100%;object-fit:contain;border-radius:12px" onerror="this.outerHTML='<span class=&quot;about-big&quot;>A</span>'">
    </div>
    <div>
      <p class="about-tag">Our story</p>
      <h2 class="about-title">Made from scratch,<br>made with love</h2>
      <p class="about-body">Alyanah's Homemade started as a small passion project — a love for cooking and sharing food with family and friends. What began in a home kitchen in Cagayan de Oro grew into a beloved local brand known for rich, comforting homemade food.</p>
      <p class="about-body">Every lasagna, every leche flan, every batch of cookies is made fresh — no preservatives, no shortcuts. Just real ingredients and real care in every single order.</p>
      <a class="btn btn-orange" href="<?= site_url('menu') ?>">Order now</a>
    </div>
  </div>
</div>

<div class="section section-alt" style="text-align:center">
  <p class="eyebrow">Why choose us</p>
  <h2 class="section-title" style="margin-bottom:32px">The Alyanah's difference</h2>
  <div class="about-feature-grid">
    <div style="background:var(--cream);border:1px solid var(--gray2);border-radius:12px;padding:24px">
      <div style="font-size:32px;margin-bottom:12px">🏠</div>
      <p style="font-family:var(--serif);font-size:16px;color:var(--brown3);margin-bottom:8px">Made at home</p>
      <p style="font-size:12px;color:var(--gray3);line-height:1.6">Every item is made in our home kitchen with fresh, quality ingredients.</p>
    </div>
    <div style="background:var(--cream);border:1px solid var(--gray2);border-radius:12px;padding:24px">
      <div style="font-size:32px;margin-bottom:12px">🍳</div>
      <p style="font-family:var(--serif);font-size:16px;color:var(--brown3);margin-bottom:8px">Made to order</p>
      <p style="font-size:12px;color:var(--gray3);line-height:1.6">We make your food only when you order — no pre-made or stored items.</p>
    </div>
    <div style="background:var(--cream);border:1px solid var(--gray2);border-radius:12px;padding:24px">
      <div style="font-size:32px;margin-bottom:12px">❤️</div>
      <p style="font-family:var(--serif);font-size:16px;color:var(--brown3);margin-bottom:8px">Made with love</p>
      <p style="font-size:12px;color:var(--gray3);line-height:1.6">Every batch carries the care and passion of a home cook, not a factory.</p>
    </div>
  </div>
</div>

<div class="section" id="contact">
  <div class="section-hdr">
    <p class="eyebrow">Get in touch</p>
    <h2 class="section-title">Contact Us</h2>
    <p class="section-sub">Have a question about an order, bulk orders, or just want to say hi? Reach us here.</p>
  </div>
  <div class="about-contact-grid">
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px;text-align:center">
      <div style="font-size:28px;margin-bottom:10px">📞</div>
      <p style="font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Phone</p>
      <a href="tel:+639171234567" style="font-size:13px;color:var(--brown3);text-decoration:none;font-weight:500">0917 123 4567</a>
    </div>
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px;text-align:center">
      <div style="font-size:28px;margin-bottom:10px">✉️</div>
      <p style="font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Email</p>
      <a href="mailto:hello@alyanahshomemade.com" style="font-size:13px;color:var(--brown3);text-decoration:none;font-weight:500">hello@alyanahshomemade.com</a>
    </div>
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px;text-align:center">
      <div style="font-size:28px;margin-bottom:10px">📷</div>
      <p style="font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Facebook / Instagram</p>
      <a href="#" style="font-size:13px;color:var(--brown3);text-decoration:none;font-weight:500">@alyanahshomemade</a>
    </div>
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px;text-align:center">
      <div style="font-size:28px;margin-bottom:10px">📍</div>
      <p style="font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);margin-bottom:4px">Location</p>
      <p style="font-size:13px;color:var(--brown3);font-weight:500">Cagayan de Oro City</p>
    </div>
  </div>
</div>

<?= $this->endSection() ?>