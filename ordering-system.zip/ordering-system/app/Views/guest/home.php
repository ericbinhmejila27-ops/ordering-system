<?= $this->extend('layouts/guest_layout') ?>
<?= $this->section('content') ?>

<div class="hero" style="position:relative;background:radial-gradient(ellipse 700px 550px at center,rgba(15,10,6,.72) 0%,rgba(15,10,6,.45) 45%,rgba(15,10,6,.1) 75%,transparent 100%),url('<?= base_url('assets/images/Background.png') ?>') top center/cover no-repeat">
  <div class="hero-left">
    <p class="hero-tag">Homemade with love — Cagayan de Oro</p>
    <h1 class="hero-title">Fresh from<br>Alyanah's<br><em>Kitchen</em></h1>
    <p class="hero-sub">Order our signature homemade lasagna, leche flan, brownies, butterscotch, and lengua de gato — delivered right to your door.</p>
    <div class="hero-btns">
      <a class="btn btn-orange" href="<?= site_url('menu') ?>">Order Now</a>
      <a class="btn btn-outline-light" href="<?= site_url('about') ?>">Our Story</a>
    </div>
  </div>
</div>

<div class="section">
  <div class="section-hdr">
    <p class="eyebrow">What we make</p>
    <h2 class="section-title">Our Menu</h2>
    <p class="section-sub">All items are made fresh per order — homemade with quality ingredients and lots of love.</p>
  </div>

  <div class="menu-grid">
    <?php foreach ($menu as $p) : ?>
      <?= view('partials/menu_card', ['p' => $p, 'context' => 'guest']) ?>
    <?php endforeach; ?>
  </div>

  <div style="text-align:center;margin-top:28px">
    <a class="btn btn-brown" href="<?= site_url('menu') ?>">View Full Menu</a>
  </div>
</div>

<div class="section section-alt">
  <div class="section-hdr">
    <p class="eyebrow">How it works</p>
    <h2 class="section-title">Order in 4 easy steps</h2>
  </div>
  <div class="how-grid">
    <div class="how-card"><div class="how-num">1</div><p class="how-title">Browse the menu</p><p class="how-desc">Pick your favorites from our selection of homemade goodies.</p></div>
    <div class="how-card"><div class="how-num">2</div><p class="how-title">Place your order</p><p class="how-desc">Add items to your cart and checkout with your delivery details.</p></div>
    <div class="how-card"><div class="how-num">3</div><p class="how-title">We prepare it fresh</p><p class="how-desc">Your order is made fresh once confirmed — no pre-made items.</p></div>
    <div class="how-card"><div class="how-num">4</div><p class="how-title">Delivered to you</p><p class="how-desc">Receive your order via GrabFood, FoodPanda, or pick-up.</p></div>
  </div>
</div>

<div class="delivery-section">
  <p class="eyebrow" style="color:var(--orange2)">Delivery options</p>
  <h2 style="font-family:var(--serif);font-size:30px;font-weight:400;margin-bottom:8px">Pick your delivery method</h2>
  <p style="font-size:13px;color:rgba(255,255,255,.45);max-width:400px;margin:0 auto">Choose how you want to receive your order — we work with your preferred platform.</p>
  <div class="delivery-cards">
    <div class="del-card">
      <div class="del-icon">🟢</div>
      <div class="del-name">GrabFood</div>
      <div class="del-desc">Order through Grab for fast delivery tracked right on your phone.</div>
      <a class="btn btn-orange btn-sm" style="margin-top:14px;width:100%;justify-content:center" href="<?= site_url('menu') ?>">Order via Grab</a>
    </div>
    <div class="del-card">
      <div class="del-icon">🟡</div>
      <div class="del-name">FoodPanda</div>
      <div class="del-desc">Order via FoodPanda for convenient delivery with live tracking.</div>
      <a class="btn btn-orange btn-sm" style="margin-top:14px;width:100%;justify-content:center" href="<?= site_url('menu') ?>">Order via Panda</a>
    </div>
  </div>
</div>

<div class="section" style="background:var(--cream2)">
  <div class="section-hdr">
    <p class="eyebrow">What customers say</p>
    <h2 class="section-title">Made with love, loved by many</h2>
  </div>
  <div class="review-grid">
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px">
      <div style="font-size:13px;margin-bottom:4px">⭐⭐⭐⭐⭐</div>
      <p style="font-family:var(--serif);font-size:14px;font-style:italic;color:var(--brown2);line-height:1.6;margin-bottom:12px">"The lasagna is absolutely incredible. Tastes just like home — rich, cheesy, and so filling!"</p>
      <p style="font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);font-weight:500">— Maria S.</p>
    </div>
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px">
      <div style="font-size:13px;margin-bottom:4px">⭐⭐⭐⭐⭐</div>
      <p style="font-family:var(--serif);font-size:14px;font-style:italic;color:var(--brown2);line-height:1.6;margin-bottom:12px">"Leche flan is the best I've ever had. Smooth and perfectly sweet. Will order again!"</p>
      <p style="font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);font-weight:500">— John P.</p>
    </div>
    <div style="background:var(--white);border:1px solid var(--gray2);border-radius:12px;padding:22px">
      <div style="font-size:13px;margin-bottom:4px">⭐⭐⭐⭐⭐</div>
      <p style="font-family:var(--serif);font-size:14px;font-style:italic;color:var(--brown2);line-height:1.6;margin-bottom:12px">"Lengua de gato is so crispy and buttery. Perfect pasalubong. Fast delivery too!"</p>
      <p style="font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--gray3);font-weight:500">— Ana R.</p>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
