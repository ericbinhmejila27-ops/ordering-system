<?= $this->extend('layouts/guest_layout') ?>
<?= $this->section('content') ?>

<div class="section section-tight-top">
  <div class="section-hdr section-hdr-left" style="margin-bottom:2px">
    <p class="eyebrow">Fresh & homemade</p>
  </div>

  <div style="display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:4px">
    <h2 class="section-title" style="margin:0">Our Full Menu</h2>

    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <?php foreach (['All', 'Savory', 'Desserts', 'Best Sellers'] as $f) : ?>
        <a class="btn btn-sm <?= $filter === $f ? 'btn-brown' : 'btn-outline' ?>" href="<?= site_url('menu') . ($f === 'All' ? '' : '?filter=' . urlencode($f)) ?>"><?= $f ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <p class="section-sub" style="margin:0 0 14px">All items are made to order — fresh, homemade, and packed with love.</p>

  <div class="menu-grid">
    <?php if (empty($menu)) : ?>
      <p style="grid-column:1/-1;text-align:center;color:var(--gray3);font-size:13px">No items in this category yet.</p>
    <?php endif; ?>
    <?php foreach ($menu as $p) : ?>
      <?= view('partials/menu_card', ['p' => $p, 'context' => 'guest']) ?>
    <?php endforeach; ?>
  </div>
</div>

<?= $this->endSection() ?>