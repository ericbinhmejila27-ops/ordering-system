<?php if (session()->getFlashdata('message')) : ?>
  <div class="flash-msg flash-success"><?= esc(session()->getFlashdata('message')) ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('error')) : ?>
  <div class="flash-msg flash-error"><?= esc(session()->getFlashdata('error')) ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('info')) : ?>
  <div class="flash-msg flash-info"><?= esc(session()->getFlashdata('info')) ?></div>
<?php endif; ?>
