<footer>
  <div class="footer-grid">
    <div class="footer-brand">
      <span class="logo" style="color:var(--cream)">Alyanah's <span style="color:var(--orange2);font-style:italic">Homemade</span></span>
      <p>Lovingly made Filipino homemade food — lasagna, leche flan, brownies, butterscotch, and lengua de gato. Order online, delivered fresh.</p>
    </div>
    <div class="fcol">
      <h4>Menu</h4>
      <ul class="flinks">
        <li><a href="<?= site_url('menu') ?>">Lasagna</a></li>
        <li><a href="<?= site_url('menu') ?>">Leche Flan</a></li>
        <li><a href="<?= site_url('menu') ?>">Brownies</a></li>
        <li><a href="<?= site_url('menu') ?>">Butterscotch</a></li>
        <li><a href="<?= site_url('menu') ?>">Lengua de Gato</a></li>
      </ul>
    </div>
    <div class="fcol">
      <h4>Info</h4>
      <ul class="flinks">
        <li><a href="<?= site_url('about') ?>">About Alyanah's</a></li>
        <li>Delivery Areas</li>
        <li>Order via GrabFood</li>
        <li>Order via FoodPanda</li>
        <li><a href="<?= site_url('about') ?>#contact">Contact Us</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 Alyanah's Homemade. All rights reserved.</span>
    <span>Cagayan de Oro, Philippines</span>
  </div>
</footer>