<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $title ?? "Admin - Alyanah's Homemade" ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<nav>
  <a class="logo" href="<?= site_url('admin/dashboard') ?>" style="display:flex;align-items:center;gap:9px">
    <img src="<?= base_url('assets/images/Logo.png') ?>" alt="Alyanah's Homemade logo" style="height:34px;width:34px;object-fit:cover;border-radius:50%" onerror="this.style.display='none'">
    Alyanah's <span>Homemade</span> <span style="color:rgba(255,255,255,.4);font-style:normal;font-size:12px">— Admin</span>
  </a>
  <div class="nav-right">
    <a class="user-btn" href="<?= site_url('logout') ?>">Log out</a>
  </div>
</nav>

<div class="admin-layout">
  <div class="admin-nav">
    <h3>Admin Panel</h3>
    <a class="admin-tab <?= ($active ?? '') === 'dashboard' ? 'active' : '' ?>" href="<?= site_url('admin/dashboard') ?>">📊 Dashboard</a>
    <a class="admin-tab <?= ($active ?? '') === 'menu' ? 'active' : '' ?>" href="<?= site_url('admin/menu') ?>">🍝 Menu</a>
    <a class="admin-tab <?= ($active ?? '') === 'inventory' ? 'active' : '' ?>" href="<?= site_url('admin/inventory') ?>">📋 Inventory</a>
    <a class="admin-tab <?= ($active ?? '') === 'orders' ? 'active' : '' ?>" href="<?= site_url('admin/orders') ?>">📦 Orders</a>
    <a class="admin-tab <?= ($active ?? '') === 'customers' ? 'active' : '' ?>" href="<?= site_url('admin/customers') ?>">👥 Customers</a>
    <a class="admin-tab <?= ($active ?? '') === 'reports' ? 'active' : '' ?>" href="<?= site_url('admin/reports') ?>">🧾 Reports</a>
  </div>
  <div class="admin-body">
    <?= view('layouts/_flash') ?>
    <?= $this->renderSection('content') ?>
  </div>
</div>

</body>
</html>