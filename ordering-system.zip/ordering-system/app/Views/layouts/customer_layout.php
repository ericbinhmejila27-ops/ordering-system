<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $title ?? "Alyanah's Homemade" ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<nav>
  <a class="logo" href="<?= site_url('customer/home') ?>" style="display:flex;align-items:center;gap:9px">
    <img src="<?= base_url('assets/images/Logo.png') ?>" alt="Alyanah's Homemade logo" style="height:34px;width:34px;object-fit:cover;border-radius:50%" onerror="this.style.display='none'">
    Alyanah's <span>Homemade</span>
  </a>
  <div class="nav-links">
    <a class="nlink <?= ($active ?? '') === 'home' ? 'active' : '' ?>" href="<?= site_url('customer/home') ?>">Home</a>
    <a class="nlink <?= ($active ?? '') === 'menu' ? 'active' : '' ?>" href="<?= site_url('customer/menu') ?>">Menu</a>
    <a class="nlink <?= ($active ?? '') === 'track' ? 'active' : '' ?>" href="<?= site_url('customer/track-order') ?>">Track Order</a>
    <a class="nlink <?= ($active ?? '') === 'history' ? 'active' : '' ?>" href="<?= site_url('customer/history') ?>">History</a>
  </div>
  <div class="nav-right">
    <div class="user-menu" id="userMenu">
      <div class="user-avatar"><?= substr(esc(session()->get('name') ?? 'C'), 0, 1) ?></div>
      <button type="button" class="user-btn" id="userMenuToggle" style="cursor:pointer;background:none">
        <span class="user-label">Hi,</span><?= esc(session()->get('name') ?? 'Customer') ?>
      </button>
      <div class="user-dropdown" id="userDropdown">
        <a href="<?= site_url('customer/profile') ?>">Profile</a>
        <a class="danger" href="<?= site_url('logout') ?>">Log out</a>
      </div>
    </div>
    <script>
    (function(){
      var toggle = document.getElementById('userMenuToggle');
      var dropdown = document.getElementById('userDropdown');
      var menu = document.getElementById('userMenu');
      if (!toggle || !dropdown) return;
      toggle.addEventListener('click', function(e){
        e.stopPropagation();
        dropdown.classList.toggle('show');
      });
      document.addEventListener('click', function(e){
        if (!menu.contains(e.target)) dropdown.classList.remove('show');
      });
    })();
    </script>
    <a class="nbtn nbtn-cart" href="<?= site_url('customer/cart') ?>">
      Cart <span class="cart-badge"><?= (int) ($cartCount ?? 0) ?></span>
    </a>
  </div>
</nav>


<main>
<?= view('layouts/_flash') ?>
<?= $this->renderSection('content') ?>
</main>

<?= view('layouts/_footer') ?>

</body>
</html>