<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $title ?? "Alyanah's Homemade" ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<nav>
  <a class="logo" href="<?= site_url('/') ?>" style="display:flex;align-items:center;gap:9px">
    <img src="<?= base_url('assets/images/Logo.png') ?>" alt="Alyanah's Homemade logo" style="height:34px;width:34px;object-fit:cover;border-radius:50%" onerror="this.style.display='none'">
    Alyanah's <span>Homemade</span>
  </a>
  <div class="nav-links">
    <a class="nlink <?= ($active ?? '') === 'home' ? 'active' : '' ?>" href="<?= site_url('/') ?>">Home</a>
    <a class="nlink <?= ($active ?? '') === 'menu' ? 'active' : '' ?>" href="<?= site_url('menu') ?>">Menu</a>
    <a class="nlink <?= ($active ?? '') === 'about' ? 'active' : '' ?>" href="<?= site_url('about') ?>">About</a>
  </div>
  <div class="nav-right">
    <a class="user-btn" href="<?= site_url('login') ?>">Sign in</a>
  </div>
</nav>


<main>
<?= view('layouts/_flash') ?>
<?= $this->renderSection('content') ?>
</main>

<?= view('layouts/_footer') ?>

</body>
</html>