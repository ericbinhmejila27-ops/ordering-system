<?php
/**
 * Expects: $logs (rows from DataStore::getInventoryLogs()), $showItem (bool)
 */
$typeMap = [
    'restock' => ['s-delivered', 'Restock'],
    'order'   => ['s-preparing', 'Order'],
    'cancel'  => ['s-pending', 'Returned'],
    'adjust'  => ['s-untracked', 'Adjusted'],
];
$cols = $showItem ? 6 : 5;
?>
<div class="table-wrap">
  <table class="tbl">
    <thead><tr><th>Date</th><?php if ($showItem) : ?><th>Item</th><?php endif; ?><th>Type</th><th>Change</th><th>Stock After</th><th>Reference / Note</th></tr></thead>
    <tbody>
      <?php if (empty($logs)) : ?>
        <tr><td colspan="<?= $cols ?>" style="text-align:center;color:var(--gray3);padding:20px">No stock movements yet.</td></tr>
      <?php else : ?>
        <?php foreach ($logs as $l) : [$cls, $label] = $typeMap[$l['type']] ?? ['s-untracked', ucfirst($l['type'])]; $chg = (int) $l['change_qty']; ?>
          <tr>
            <td style="white-space:nowrap;color:var(--gray3)"><?= esc(date('M j, Y g:i A', strtotime($l['created_at']))) ?></td>
            <?php if ($showItem) : ?>
              <td><a href="<?= site_url('admin/inventory/' . $l['menu_id']) ?>" style="color:var(--brown3);text-decoration:none"><strong><?= esc($l['item_name']) ?></strong></a></td>
            <?php endif; ?>
            <td><span class="sbadge <?= $cls ?>"><?= $label ?></span></td>
            <td style="font-weight:500;color:<?= $chg > 0 ? '#0f5132' : ($chg < 0 ? '#842029' : 'var(--gray3)') ?>"><?= $chg > 0 ? '+' . $chg : $chg ?></td>
            <td><?= (int) $l['stock_after'] ?></td>
            <td>
              <?php if (! empty($l['reference'])) : ?>
                <a href="<?= site_url('admin/orders/view/' . $l['reference']) ?>" style="color:var(--orange)"><?= esc($l['reference']) ?></a>
              <?php endif; ?>
              <?php if (! empty($l['note'])) : ?><span style="color:var(--gray3)"><?= ! empty($l['reference']) ? ' · ' : '' ?><?= esc($l['note']) ?></span><?php endif; ?>
              <?php if (empty($l['reference']) && empty($l['note'])) : ?>—<?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>