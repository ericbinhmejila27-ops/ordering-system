<?php
/**
 * Expects: $p (menu item array), $context ('guest'|'customer'|'admin')
 */
$available = ($p['avail'] ?? true) !== false;
$stock     = $p['stock'] ?? null;
$lowStock  = $available && $stock !== null && $stock <= ($p['lowStock'] ?? 5);
$badge     = $p['badge'] ?? null;
$badgeLabel = $badge === 'bestseller' ? 'Best Seller' : ($badge ? ucfirst($badge) : '');
$detailUrl = $context === 'admin'
    ? site_url('admin/menu/edit/' . $p['id'])
    : ($context === 'customer' ? site_url('customer/menu/' . $p['id']) : site_url('menu/' . $p['id']));
?>
<div class="menu-card">
  <a href="<?= $detailUrl ?>" style="text-decoration:none;display:block">
    <div class="mc-img" style="background:<?= esc($p['bg'] ?? '#f5e0d0') ?>">
      <?php if (! empty($p['img'])) : ?>
        <img src="<?= base_url($p['img']) ?>" alt="<?= esc($p['name']) ?>" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;<?= $available ? '' : 'filter:grayscale(70%);opacity:.55' ?>" onerror="this.style.display='none'">
      <?php else : ?>
        <span class="mc-emoji" style="<?= $available ? '' : 'filter:grayscale(70%);opacity:.55' ?>"><?= $p['emoji'] ?? '🍽️' ?></span>
      <?php endif; ?>
      <?php if ($badge) : ?>
        <span class="mc-badge badge-<?= esc($badge) ?>"><?= esc($badgeLabel) ?></span>
      <?php endif; ?>
      <?php if (! $available) : ?>
        <span class="mc-badge" style="background:#5a5048;color:#fff;left:auto;right:10px">Sold Out</span>
      <?php endif; ?>
    </div>
    <div class="mc-body">
      <p class="mc-name"><?= esc($p['name']) ?></p>
      <p class="mc-desc"><?= esc($p['desc']) ?></p>
      <div class="mc-foot">
        <span class="mc-price"><?= App\Libraries\DataStore::fmt($p['price']) ?></span>
        <span class="mc-avail" style="<?= $available && ! $lowStock ? '' : 'color:#b3261e' ?>"><?= ! $available ? '✕ Sold out' : ($lowStock ? "Only {$stock} left" : '✓ Available') ?></span>
      </div>
    </div>
  </a>
  <?php if ($context === 'customer' && $available) : ?>
    <form method="post" action="<?= site_url('customer/cart/add/' . $p['id']) ?>" style="padding:0 16px 14px">
      <button type="submit" class="btn btn-orange btn-sm" style="width:100%">Add to cart</button>
    </form>
  <?php elseif ($context === 'guest') : ?>
    <div style="padding:0 16px 14px">
      <a href="<?= site_url('login') ?>" class="btn btn-outline btn-sm" style="width:100%;justify-content:center">Sign in to order</a>
    </div>
  <?php elseif ($context === 'admin') : ?>
    <div style="padding:0 16px 14px">
      <a href="<?= site_url('admin/menu/edit/' . $p['id']) ?>" class="btn btn-outline btn-sm" style="width:100%;justify-content:center">Edit item</a>
    </div>
  <?php endif; ?>
</div>