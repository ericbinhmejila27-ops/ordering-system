<?php
/** Expects: $o (order array) */
$method = $o['paymentMethod'] ?? 'cod';
$label  = $method === 'cod' ? 'COD' : ($method === 'gcash' ? 'GCash' : ($method === 'bank' ? 'Bank' : ucfirst($method)));
$url    = site_url('admin/orders/payment/' . $o['id']);
?>
<?php if ($method === 'cod') : ?>
  <a href="<?= $url ?>" class="sbadge" style="background:#e2e3e5;color:#41464b;text-decoration:none"><?= $label ?></a>
<?php elseif (($o['paymentStatus'] ?? '') === 'verified') : ?>
  <a href="<?= $url ?>" class="sbadge s-delivered" style="text-decoration:none">Paid</a>
<?php else : ?>
  <a href="<?= $url ?>" class="sbadge" style="background:#fff3cd;color:#856404;text-decoration:none"><?= $label ?></a>
<?php endif; ?>
