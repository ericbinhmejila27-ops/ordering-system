<?php
/** Expects: $o (order array) — shows HOW the customer pays */
$method = $o['paymentMethod'] ?? 'cod';
$labels = ['cod' => 'COD', 'gcash' => 'GCash', 'bank' => 'Bank Transfer'];
$colors = [
    'cod'   => 'background:#e2e3e5;color:#41464b',
    'gcash' => 'background:#cfe2ff;color:#084298',
    'bank'  => 'background:#e0d7f5;color:#4a2a8a',
];
?>
<a href="<?= site_url('admin/orders/payment/' . $o['id']) ?>" class="sbadge" style="<?= $colors[$method] ?? $colors['cod'] ?>;text-decoration:none"><?= $labels[$method] ?? ucfirst($method) ?></a>