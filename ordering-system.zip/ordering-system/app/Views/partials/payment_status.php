<?php
/** Expects: $o (order array) — shows WHETHER the customer has paid */
$method    = $o['paymentMethod'] ?? 'cod';
$payStatus = $o['paymentStatus'] ?? 'pending';
$isPartial = ($o['paymentType'] ?? 'full') === 'partial' && (float) ($o['balance'] ?? 0) > 0;

if ($payStatus === 'verified' && ! $isPartial) {
    [$label, $style] = ['Paid', 'background:#d1e7dd;color:#0f5132'];
} elseif ($payStatus === 'verified' && $isPartial) {
    [$label, $style] = ['50% Paid', 'background:#cfe2ff;color:#084298'];
} elseif ($method === 'cod') {
    [$label, $style] = ['Unpaid', 'background:#f8d7da;color:#842029'];
} else {
    // GCash / Bank — proof uploaded, admin still needs to check it
    [$label, $style] = ['To Verify', 'background:#fff3cd;color:#856404'];
}
?>
<a href="<?= site_url('admin/orders/payment/' . $o['id']) ?>" class="sbadge" style="<?= $style ?>;text-decoration:none"><?= $label ?></a>
<?php if ($payStatus === 'verified' && $isPartial) : ?>
  <span style="display:block;font-size:10px;color:var(--gray3);margin-top:3px">Bal. <?= App\Libraries\DataStore::fmt($o['balance']) ?></span>
<?php endif; ?>