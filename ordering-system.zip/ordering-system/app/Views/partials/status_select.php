<?php
/** Expects: $o (order array), $action (form action URL) */
$sequence   = ['pending', 'preparing', 'on delivery', 'delivered'];
$currentIdx = array_search($o['status'], $sequence, true);
$isFinal    = in_array($o['status'], ['delivered', 'cancelled'], true);
?>
<?php if ($isFinal) : ?>
  <span class="sbadge s-<?= esc($o['status']) ?>"><?= esc($o['status']) ?></span>
<?php else : ?>
  <form method="post" action="<?= $action ?>">
    <select name="status" onchange="this.form.submit()" style="font-size:10px;padding:2px 4px;border:1px solid var(--gray2);border-radius:3px;background:#fff;cursor:pointer">
      <?php foreach ($sequence as $s) : ?>
        <?php if (array_search($s, $sequence, true) < $currentIdx) continue; // no going backward ?>
        <option value="<?= $s ?>" <?= $s === $o['status'] ? 'selected' : '' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select>
    <noscript><button type="submit" class="btn btn-sm btn-outline" style="margin-left:4px">Save</button></noscript>
  </form>
<?php endif; ?>