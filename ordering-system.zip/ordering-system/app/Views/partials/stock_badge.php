<?php
/**
 * Expects: $status ('untracked'|'out'|'low'|'ok')
 */
$map = [
    'ok'        => ['s-delivered', 'In Stock'],
    'low'       => ['s-pending', 'Low Stock'],
    'out'       => ['s-cancelled', 'Out of Stock'],
    'untracked' => ['s-untracked', 'Not Tracked'],
];
[$cls, $label] = $map[$status] ?? $map['untracked'];
?>
<span class="sbadge <?= $cls ?>"><?= $label ?></span>