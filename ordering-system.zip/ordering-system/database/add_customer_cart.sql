-- Run once on an existing alyanah_db database to enable persistent customer carts.

CREATE TABLE IF NOT EXISTS customer_cart_items (
  user_id    INT UNSIGNED NOT NULL,
  menu_id    INT UNSIGNED NOT NULL,
  quantity   INT UNSIGNED NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, menu_id),
  KEY idx_customer_cart_menu (menu_id),
  CONSTRAINT fk_customer_cart_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_customer_cart_menu FOREIGN KEY (menu_id)
    REFERENCES menu_items (menu_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
