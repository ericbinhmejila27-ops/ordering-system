-- Alyanah's Homemade — normalized 3NF schema for alyanah_db.
-- Import this file for a fresh install. For an existing 5-table database,
-- run `php database/migrate.php` instead; that script preserves old tables.

CREATE DATABASE IF NOT EXISTS alyanah_db
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE alyanah_db;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  user_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email      VARCHAR(150) NOT NULL,
  user_name  VARCHAR(150) NOT NULL,
  phone      VARCHAR(20) NULL,
  address    VARCHAR(255) NULL,
  password   VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  role       ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
  category_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(50) NOT NULL,
  bg_color    VARCHAR(7) NOT NULL DEFAULT '#f5e0d0',
  UNIQUE KEY uq_categories_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS menu_items (
  menu_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id  INT UNSIGNED NOT NULL,
  menu_name    VARCHAR(150) NOT NULL,
  emoji        VARCHAR(16) NULL,
  image        VARCHAR(255) NULL,
  description  TEXT NULL,
  price        DECIMAL(10,2) NOT NULL,
  badge        ENUM('bestseller','new','seasonal') NULL,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  is_archived  TINYINT(1) NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_menu_category (category_id),
  CONSTRAINT fk_menu_category FOREIGN KEY (category_id)
    REFERENCES categories (category_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory (
  menu_id      INT UNSIGNED NOT NULL PRIMARY KEY,
  stock        INT NULL DEFAULT NULL,
  low_stock    INT NOT NULL DEFAULT 5,
  auto_soldout TINYINT(1) NOT NULL DEFAULT 0,
  updated_at   DATETIME NULL,
  CONSTRAINT fk_inventory_menu FOREIGN KEY (menu_id)
    REFERENCES menu_items (menu_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS delivery_methods (
  delivery_method_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  delivery_code      VARCHAR(20) NOT NULL,
  delivery_name      VARCHAR(50) NOT NULL,
  UNIQUE KEY uq_delivery_code (delivery_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_methods (
  payment_method_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payment_code      VARCHAR(20) NOT NULL,
  payment_name      VARCHAR(50) NOT NULL,
  bank_name         VARCHAR(50) NULL,
  account_name      VARCHAR(100) NULL,
  account_number    VARCHAR(50) NULL,
  qr_image          VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'QR shown at checkout',
  UNIQUE KEY uq_payment_code (payment_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customer_cart_items (
  user_id    INT UNSIGNED NOT NULL,
  menu_id    INT UNSIGNED NOT NULL,
  quantity   INT UNSIGNED NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, menu_id),
  KEY idx_customer_cart_menu (menu_id),
  CONSTRAINT fk_customer_cart_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_customer_cart_menu FOREIGN KEY (menu_id)
    REFERENCES menu_items (menu_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  order_id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id            INT UNSIGNED NOT NULL,
  delivery_method_id INT UNSIGNED NOT NULL,
  status             ENUM('pending','preparing','on delivery','delivered','cancelled') NOT NULL DEFAULT 'pending',
  delivery_fee       DECIMAL(10,2) NOT NULL DEFAULT 0,
  order_date         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_orders_user (user_id),
  KEY idx_orders_status (status),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_orders_delivery FOREIGN KEY (delivery_method_id)
    REFERENCES delivery_methods (delivery_method_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1001;

CREATE TABLE IF NOT EXISTS order_details (
  order_item_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id      INT UNSIGNED NOT NULL,
  menu_id       INT UNSIGNED NOT NULL,
  quantity      INT UNSIGNED NOT NULL,
  unit_price    DECIMAL(10,2) NOT NULL,
  UNIQUE KEY uq_order_item (order_id, menu_id),
  KEY idx_order_details_menu (menu_id),
  CONSTRAINT fk_items_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_items_menu FOREIGN KEY (menu_id)
    REFERENCES menu_items (menu_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
  payment_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id          INT UNSIGNED NOT NULL,
  payment_method_id INT UNSIGNED NOT NULL,
  payment_type      ENUM('full','partial') NOT NULL DEFAULT 'full',
  amount_paid       DECIMAL(10,2) NOT NULL DEFAULT 0,
  reference_no      VARCHAR(50) NULL,
  proof_image       VARCHAR(255) NULL,
  status            ENUM('cod','pending_verification','verified') NOT NULL DEFAULT 'pending_verification',
  refund_status     ENUM('none','pending','refunded') NOT NULL DEFAULT 'none',
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_payments_order (order_id),
  KEY idx_payments_method (payment_method_id),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_payments_method FOREIGN KEY (payment_method_id)
    REFERENCES payment_methods (payment_method_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_logs (
  log_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  menu_id     INT UNSIGNED NOT NULL,
  order_id    INT UNSIGNED NULL,
  type        ENUM('restock','adjust','order','cancel') NOT NULL,
  change_qty  INT NOT NULL,
  stock_after INT NOT NULL,
  note        VARCHAR(255) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_inv_logs_menu (menu_id),
  KEY idx_inv_logs_order (order_id),
  CONSTRAINT fk_logs_menu FOREIGN KEY (menu_id)
    REFERENCES menu_items (menu_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_logs_order FOREIGN KEY (order_id)
    REFERENCES orders (order_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

INSERT IGNORE INTO categories (category_id, category_name, bg_color) VALUES
  (1, 'savory', '#fde8d0'),
  (2, 'dessert', '#fdf0c8');

INSERT IGNORE INTO delivery_methods (delivery_method_id, delivery_code, delivery_name) VALUES
  (1, 'delivery', 'Delivery'),
  (2, 'pickup', 'Pick-up'),
  (3, 'foodpanda', 'FoodPanda');

INSERT IGNORE INTO payment_methods
  (payment_method_id, payment_code, payment_name, bank_name, account_name, account_number, qr_image)
VALUES
  (1, 'cod', 'Cash on Delivery', NULL, NULL, NULL, ''),
  (2, 'gcash', 'GCash', NULL, 'Alyanah''s Homemade', '0912-345-6789', 'assets/images/qr/gcash-qr.png'),
  (3, 'bank', 'Bank Transfer', 'BDO', 'Alyanah''s Homemade', '1234-5678-9012', 'assets/images/qr/bank-qr.png');

-- Password is bcrypt for `admin123`.
INSERT IGNORE INTO users (email, user_name, phone, address, password, role) VALUES
  ('admin@alyanah.com', 'Alyanah', '', '', '$2y$10$NJ.tP.ldtQv6tNFv9.dxBOFCVg7gAhidtErYBvhrAL7k6anX5o/E.', 'admin');

-- Sample menu rows for fresh installations only. migrate.php stops before
-- this marker so migrated data is not mixed with sample content.
-- @@SAMPLE_DATA
INSERT IGNORE INTO menu_items
  (menu_id, category_id, menu_name, emoji, image, description, price, badge, is_available)
VALUES
  (1, 1, 'Lasagna', '🍝', 'assets/images/Lasagna.png', 'Oven-baked homestyle lasagna with rich meat sauce and creamy béchamel, layered to perfection.', 320, 'bestseller', 1),
  (2, 2, 'Leche Flan', '🍮', 'assets/images/Leche_Flan.png', 'Classic silky Filipino caramel custard, steamed to a smooth, melt-in-your-mouth finish.', 180, 'bestseller', 1),
  (3, 2, 'Brownies', '🍫', 'assets/images/Brownies.png', 'Rich, fudgy homemade brownies made with real chocolate — dense, moist, and deeply satisfying.', 150, 'new', 1),
  (4, 2, 'Butterscotch', '🍯', 'assets/images/Butterscotch.png', 'Sweet, buttery Filipino-style butterscotch bars with a golden caramel flavor in every bite.', 160, NULL, 1),
  (5, 2, 'Lengua de Gato', '🍪', 'assets/images/Lengua_de_Gato.png', 'Crisp, melt-in-your-mouth butter cookies — delicate, light, and perfect with coffee or tea.', 120, 'seasonal', 1);
