-- Run this after qr_image has been added to payment_methods.
-- It assigns the configured QR paths, clears non-applicable methods, and
-- prevents future NULL values in qr_image.

UPDATE payment_methods
SET qr_image = CASE payment_code
  WHEN 'gcash' THEN 'assets/images/qr/gcash-qr.png'
  WHEN 'bank' THEN 'assets/images/qr/bank-qr.png'
  ELSE ''
END
WHERE qr_image IS NULL;

ALTER TABLE payment_methods
  MODIFY COLUMN qr_image VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'QR shown at checkout';
