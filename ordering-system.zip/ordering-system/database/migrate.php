<?php

declare(strict_types=1);

const DB_NAME = 'alyanah_db';

$tables = ['users', 'menu_items', 'orders', 'inventory', 'inventory_logs'];
$newTables = [
    'inventory_logs',
    'payments',
    'order_details',
    'orders',
    'inventory',
    'menu_items',
    'payment_methods',
    'delivery_methods',
    'categories',
    'users',
];
$renamed = false;
$pdo = null;

function output(string $message): void
{
    echo $message . PHP_EOL;
}

function queryRows(PDO $pdo, string $table): array
{
    return $pdo->query("SELECT * FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);
}

function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?'
    );
    $stmt->execute([DB_NAME, $table]);

    return (int) $stmt->fetchColumn() > 0;
}

function splitSchemaStatements(string $sql): array
{
    $marker = '-- @@SAMPLE_DATA';
    $sampleStart = strpos($sql, $marker);
    if ($sampleStart !== false) {
        $sql = substr($sql, 0, $sampleStart);
    }

    $sql = preg_replace('/^[ \t]*--[^\r\n]*(?:\r?\n|$)/m', '', $sql);
    $statements = array_map('trim', explode(';', (string) $sql));

    return array_values(array_filter($statements, static fn ($statement) => $statement !== ''));
}

function money($value): float
{
    return round((float) $value, 2);
}

function normalizeDate($value): string
{
    if ($value === null || trim((string) $value) === '') {
        return date('Y-m-d H:i:s');
    }

    $timestamp = strtotime((string) $value);
    if ($timestamp === false) {
        throw new RuntimeException("Cannot parse legacy order date: {$value}");
    }

    return date('Y-m-d H:i:s', $timestamp);
}

function legacyOrderNumber(string $id): int
{
    if (! preg_match('/(?:ORD-)?(\d+)$/i', trim($id), $matches)) {
        throw new RuntimeException("Legacy order ID '{$id}' does not contain a numeric order number.");
    }

    return (int) $matches[1];
}

function methodCode(string $value, string $kind): string
{
    $value = strtolower(trim($value));

    if ($kind === 'delivery') {
        if (str_contains($value, 'foodpanda')) {
            return 'foodpanda';
        }
        if (str_contains($value, 'pick')) {
            return 'pickup';
        }

        return 'delivery';
    }

    if (str_contains($value, 'gcash')) {
        return 'gcash';
    }
    if (str_contains($value, 'bank') || str_contains($value, 'bdo') || str_contains($value, 'transfer')) {
        return 'bank';
    }

    return 'cod';
}

function legacyLines(string $text): array
{
    $lines = [];
    foreach (preg_split('/\s*,\s*/u', trim($text), -1, PREG_SPLIT_NO_EMPTY) as $part) {
        if (! preg_match('/^(.*?)\s*[×x]\s*(\d+)\s*$/iu', trim($part), $matches)) {
            throw new RuntimeException("Cannot parse legacy order item '{$part}'.");
        }

        $name = trim($matches[1]);
        $qty = (int) $matches[2];
        if ($name === '' || $qty < 1) {
            throw new RuntimeException("Invalid legacy order item '{$part}'.");
        }

        $lines[$name] = ($lines[$name] ?? 0) + $qty;
    }

    return $lines;
}

function categoryId(PDO $pdo, string $name, string $color = '#f5e0d0'): int
{
    $name = trim($name) !== '' ? trim($name) : 'savory';
    $stmt = $pdo->prepare(
        'INSERT INTO categories (category_name, bg_color) VALUES (?, ?) ON DUPLICATE KEY UPDATE bg_color = VALUES(bg_color)'
    );
    $stmt->execute([$name, $color]);

    $stmt = $pdo->prepare('SELECT category_id FROM categories WHERE category_name = ?');
    $stmt->execute([$name]);

    return (int) $stmt->fetchColumn();
}

function ensureArchivedMenuItem(PDO $pdo, int $menuId, string $name): void
{
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM menu_items WHERE menu_id = ?');
    $stmt->execute([$menuId]);
    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $category = categoryId($pdo, 'legacy');
    $stmt = $pdo->prepare(
        'INSERT INTO menu_items (menu_id, category_id, menu_name, price, is_available, is_archived) VALUES (?, ?, ?, 0, 0, 1)'
    );
    $stmt->execute([$menuId, $category, $name !== '' ? $name : "Archived item #{$menuId}"]);
}

try {
    $pdo = new PDO(
        'mysql:host=localhost;dbname=' . DB_NAME . ';charset=utf8mb4',
        'root',
        '',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    foreach ($tables as $table) {
        if (! tableExists($pdo, $table)) {
            throw new RuntimeException("Required legacy table '{$table}' was not found.");
        }
        if (tableExists($pdo, 'old_' . $table)) {
            throw new RuntimeException("Backup table 'old_{$table}' already exists; rename or back it up before migrating.");
        }
    }
    foreach (['categories', 'delivery_methods', 'payment_methods', 'order_details', 'payments'] as $table) {
        if (tableExists($pdo, $table)) {
            throw new RuntimeException("Target table '{$table}' already exists; refusing to overwrite a partial or previous migration.");
        }
    }

    $renameSql = implode(', ', array_map(
        static fn ($table) => "`{$table}` TO `old_{$table}`",
        $tables
    ));
    $pdo->exec('RENAME TABLE ' . $renameSql);
    $renamed = true;
    output('Renamed legacy tables to old_*; originals are retained.');

    $schema = file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'alyanah_db.sql');
    if ($schema === false) {
        throw new RuntimeException('Unable to read database/alyanah_db.sql.');
    }
    foreach (splitSchemaStatements($schema) as $statement) {
        $pdo->exec($statement);
    }

    $oldUsers = queryRows($pdo, 'old_users');
    $userInsert = $pdo->prepare(
        'INSERT INTO users (email, user_name, phone, address, password, role, created_at)
         VALUES (?, ?, ?, ?, ?, \'customer\', ?)
         ON DUPLICATE KEY UPDATE user_name = VALUES(user_name), phone = VALUES(phone), address = VALUES(address)'
    );
    foreach ($oldUsers as $user) {
        $email = strtolower(trim((string) ($user['email'] ?? '')));
        if ($email === '') {
            throw new RuntimeException('A legacy user has no email address.');
        }
        $password = (string) ($user['password'] ?? '');
        $passwordInfo = password_get_info($password);
        if (($passwordInfo['algoName'] ?? 'unknown') === 'unknown') {
            $password = password_hash($password, PASSWORD_BCRYPT);
        }
        $createdAt = isset($user['created_at']) ? normalizeDate($user['created_at']) : date('Y-m-d H:i:s');
        $userInsert->execute([
            $email,
            (string) ($user['name'] ?? ''),
            (string) ($user['phone'] ?? ''),
            (string) ($user['address'] ?? ''),
            $password,
            $createdAt,
        ]);
    }

    $legacyMenu = queryRows($pdo, 'old_menu_items');
    $menuInsert = $pdo->prepare(
        'INSERT INTO menu_items (menu_id, category_id, menu_name, emoji, image, description, price, badge, is_available)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $menuByName = [];
    foreach ($legacyMenu as $item) {
        $cat = strtolower(trim((string) ($item['category'] ?? 'savory')));
        $bg = trim((string) ($item['bg'] ?? '#f5e0d0'));
        $category = categoryId($pdo, $cat, preg_match('/^#[0-9a-f]{6}$/i', $bg) ? $bg : '#f5e0d0');
        $name = trim((string) ($item['name'] ?? ''));
        $badge = in_array(($item['badge'] ?? null), ['bestseller', 'new', 'seasonal'], true)
            ? $item['badge']
            : null;
        $menuInsert->execute([
            (int) $item['menu_id'],
            $category,
            $name,
            $item['emoji'] ?? null,
            $item['img'] ?? null,
            $item['description'] ?? null,
            money($item['price'] ?? 0),
            $badge,
            (int) ($item['avail'] ?? $item['available'] ?? 1),
        ]);
        $menuByName[strtolower($name)] = [
            'menu_id' => (int) $item['menu_id'],
            'price' => money($item['price'] ?? 0),
        ];
    }

    $oldInventory = queryRows($pdo, 'old_inventory');
    $oldLogs = queryRows($pdo, 'old_inventory_logs');
    foreach ($oldLogs as $row) {
        ensureArchivedMenuItem($pdo, (int) $row['menu_id'], (string) ($row['item_name'] ?? ''));
    }
    foreach ($oldInventory as $row) {
        ensureArchivedMenuItem($pdo, (int) $row['menu_id'], '');
    }

    $inventoryInsert = $pdo->prepare(
        'INSERT INTO inventory (menu_id, stock, low_stock, auto_soldout, updated_at) VALUES (?, ?, ?, ?, ?)'
    );
    foreach ($oldInventory as $row) {
        $inventoryInsert->execute([
            (int) $row['menu_id'],
            $row['stock'] === null ? null : (int) $row['stock'],
            (int) ($row['low_stock'] ?? 5),
            (int) ($row['auto_soldout'] ?? 0),
            $row['updated_at'] ?? null,
        ]);
    }

    $deliveryIds = [];
    foreach ($pdo->query('SELECT delivery_method_id, delivery_code FROM delivery_methods') as $row) {
        $deliveryIds[$row['delivery_code']] = (int) $row['delivery_method_id'];
    }
    $paymentIds = [];
    foreach ($pdo->query('SELECT payment_method_id, payment_code FROM payment_methods') as $row) {
        $paymentIds[$row['payment_code']] = (int) $row['payment_method_id'];
    }
    $usersByEmail = [];
    foreach ($pdo->query('SELECT user_id, email FROM users') as $row) {
        $usersByEmail[strtolower($row['email'])] = (int) $row['user_id'];
    }

    $legacyOrders = queryRows($pdo, 'old_orders');
    $orderIdMap = [];
    $orderInsert = $pdo->prepare(
        'INSERT INTO orders (order_id, user_id, delivery_method_id, status, delivery_fee, order_date)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $itemInsert = $pdo->prepare(
        'INSERT INTO order_details (order_id, menu_id, quantity, unit_price) VALUES (?, ?, ?, ?)'
    );
    $paymentInsert = $pdo->prepare(
        'INSERT INTO payments
         (order_id, payment_method_id, payment_type, amount_paid, reference_no, proof_image, status, refund_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $ordersToVerify = [];
    foreach ($legacyOrders as $order) {
        $oldId = (string) $order['order_id'];
        $orderId = legacyOrderNumber($oldId);
        if (isset($orderIdMap[$orderId])) {
            throw new RuntimeException("Duplicate numeric order ID {$orderId} in legacy orders.");
        }
        $email = strtolower(trim((string) ($order['cust_email'] ?? '')));
        if ($email === '') {
            $email = 'legacy-order-' . $orderId . '@invalid.local';
        }
        if (! isset($usersByEmail[$email])) {
            $temporaryHash = password_hash(bin2hex(random_bytes(24)), PASSWORD_BCRYPT);
            $stmt = $pdo->prepare(
                'INSERT INTO users (email, user_name, phone, address, password, role) VALUES (?, ?, ?, \'\', ?, \'customer\')'
            );
            $stmt->execute([
                $email,
                (string) ($order['cust_name'] ?? ''),
                (string) ($order['cust_phone'] ?? ''),
                $temporaryHash,
            ]);
            $usersByEmail[$email] = (int) $pdo->lastInsertId();
        }

        $status = strtolower(trim((string) ($order['status'] ?? 'pending')));
        if ($status === 'ready') {
            $status = 'on delivery';
        }
        if (! in_array($status, ['pending', 'preparing', 'on delivery', 'delivered', 'cancelled'], true)) {
            $status = 'pending';
        }

        $lines = legacyLines((string) ($order['items_text'] ?? ''));
        $resolvedLines = [];
        $itemsTotal = 0.0;
        foreach ($lines as $name => $quantity) {
            $key = strtolower($name);
            if (! isset($menuByName[$key])) {
                $category = categoryId($pdo, 'legacy');
                $stmt = $pdo->prepare(
                    'INSERT INTO menu_items (category_id, menu_name, price, is_available, is_archived) VALUES (?, ?, 0, 0, 1)'
                );
                $stmt->execute([$category, $name]);
                $menuByName[$key] = ['menu_id' => (int) $pdo->lastInsertId(), 'price' => 0.0];
                output("Warning: '{$name}' was missing from the legacy menu; archived at zero price because its historical price is unavailable.");
            }
            $menuItem = $menuByName[$key];
            $resolvedLines[] = [$menuItem['menu_id'], $quantity, $menuItem['price']];
            $itemsTotal += $menuItem['price'] * $quantity;
        }

        $oldTotal = money($order['total'] ?? 0);
        $deliveryFee = money($oldTotal - $itemsTotal);
        if ($deliveryFee < 0) {
            output(
                "Warning: {$oldId} is below current menu-price subtotal by " .
                number_format(abs($deliveryFee), 2) .
                '; preserving the legacy total as a negative delivery adjustment.'
            );
        }

        $deliveryCode = methodCode((string) ($order['delivery'] ?? ''), 'delivery');
        $orderInsert->execute([
            $orderId,
            $usersByEmail[$email],
            $deliveryIds[$deliveryCode],
            $status,
            $deliveryFee,
            normalizeDate($order['order_date'] ?? $order['created_at'] ?? null),
        ]);
        $orderIdMap[$orderId] = $orderId;
        foreach ($resolvedLines as [$menuId, $quantity, $unitPrice]) {
            $itemInsert->execute([$orderId, $menuId, $quantity, $unitPrice]);
        }

        $payCode = methodCode(
            (string) (($order['payment_method'] ?? '') . ' ' . ($order['payment_label'] ?? '')),
            'payment'
        );
        $paymentStatus = strtolower(trim((string) ($order['payment_status'] ?? 'pending_verification')));
        if ($payCode === 'cod') {
            $paymentStatus = 'cod';
        } elseif (! in_array($paymentStatus, ['pending_verification', 'verified'], true)) {
            $paymentStatus = 'pending_verification';
        }
        $paymentType = strtolower((string) ($order['payment_type'] ?? 'full')) === 'partial' ? 'partial' : 'full';
        $refundStatus = strtolower((string) ($order['refund_status'] ?? 'none'));
        if (! in_array($refundStatus, ['none', 'pending', 'refunded'], true)) {
            $refundStatus = 'none';
        }
        $paymentInsert->execute([
            $orderId,
            $paymentIds[$payCode],
            $paymentType,
            money($order['amount_paid'] ?? 0),
            $order['payment_ref'] ?? null,
            $order['payment_proof'] ?? null,
            $paymentStatus,
            $refundStatus,
        ]);
        $ordersToVerify[] = ['id' => $orderId, 'old_total' => $oldTotal];
    }

    $logInsert = $pdo->prepare(
        'INSERT INTO inventory_logs (menu_id, order_id, type, change_qty, stock_after, note, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $logTypes = ['restock', 'adjust', 'order', 'cancel'];
    foreach ($oldLogs as $log) {
        $oldReference = trim((string) ($log['reference'] ?? ''));
        $linkedOrderId = null;
        if (preg_match('/^ORD-(\d+)$/i', $oldReference, $matches) && isset($orderIdMap[(int) $matches[1]])) {
            $linkedOrderId = (int) $matches[1];
        }
        $type = strtolower((string) ($log['type'] ?? 'adjust'));
        if (! in_array($type, $logTypes, true)) {
            $type = 'adjust';
        }
        $note = trim((string) ($log['note'] ?? ''));
        if ($oldReference !== '' && $linkedOrderId === null) {
            $note = trim('Legacy reference: ' . $oldReference . ($note !== '' ? '; ' . $note : ''));
        }
        $logInsert->execute([
            (int) $log['menu_id'],
            $linkedOrderId,
            $type,
            (int) ($log['change_qty'] ?? 0),
            (int) ($log['stock_after'] ?? 0),
            $note !== '' ? mb_substr($note, 0, 255) : null,
            $log['created_at'] ?? date('Y-m-d H:i:s'),
        ]);
    }

    $maxOrderId = $orderIdMap ? max(array_keys($orderIdMap)) : 1000;
    $pdo->exec('ALTER TABLE orders AUTO_INCREMENT = ' . max(1001, $maxOrderId + 1));

    output('');
    output('Migration row counts:');
    foreach (['users', 'categories', 'menu_items', 'inventory', 'inventory_logs', 'delivery_methods', 'payment_methods', 'orders', 'order_details', 'payments'] as $table) {
        output(sprintf('  %-18s %d', $table, (int) $pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn()));
    }

    output('');
    output('Order total verification (old total compared with computed line items + delivery fee):');
    $verify = $pdo->prepare(
        'SELECT o.order_id, COALESCE(SUM(oi.quantity * oi.unit_price), 0) + o.delivery_fee AS computed_total
         FROM orders o LEFT JOIN order_details oi ON oi.order_id = o.order_id
         WHERE o.order_id = ? GROUP BY o.order_id'
    );
    $allMatch = true;
    foreach ($ordersToVerify as $check) {
        $verify->execute([$check['id']]);
        $computedRow = $verify->fetch(\PDO::FETCH_ASSOC);
        $computed = money($computedRow['computed_total'] ?? 0);
        $matches = abs($computed - $check['old_total']) < 0.01;
        $allMatch = $allMatch && $matches;
        output(sprintf(
            '  ORD-%d: old %0.2f / computed %0.2f — %s',
            $check['id'],
            $check['old_total'],
            $computed,
            $matches ? 'MATCH' : 'MISMATCH'
        ));
    }
    if (! $allMatch) {
        throw new RuntimeException('One or more migrated order totals did not match the legacy totals.');
    }

    output('');
    output('Migration completed. Legacy data remains in the old_* tables.');
} catch (Throwable $exception) {
    if ($renamed && $pdo instanceof PDO) {
        output('Migration failed: ' . $exception->getMessage());
        output('Attempting to remove the incomplete normalized schema and restore the legacy table names...');
        try {
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
            foreach ($newTables as $table) {
                $pdo->exec("DROP TABLE IF EXISTS `{$table}`");
            }
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
            $restoreSql = implode(', ', array_map(
                static fn ($table) => "`old_{$table}` TO `{$table}`",
                $tables
            ));
            $pdo->exec('RENAME TABLE ' . $restoreSql);
            output('Legacy table names restored successfully.');
        } catch (Throwable $restoreException) {
            output('AUTOMATIC RESTORE FAILED: ' . $restoreException->getMessage());
            output('The source data is still in the old_* tables; do not delete them.');
        }
    } else {
        output('Migration failed before legacy table renaming: ' . $exception->getMessage());
    }
    exit(1);
}
