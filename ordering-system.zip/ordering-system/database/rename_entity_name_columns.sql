-- Rename generic entity-name columns to distinguish their meanings.
-- Existing alyanah_db installations should run this once after backing up the database.
USE alyanah_db;

ALTER TABLE users
  CHANGE COLUMN name user_name VARCHAR(150) NOT NULL;

ALTER TABLE categories
  CHANGE COLUMN name category_name VARCHAR(50) NOT NULL;

ALTER TABLE menu_items
  CHANGE COLUMN name menu_name VARCHAR(150) NOT NULL;

ALTER TABLE delivery_methods
  CHANGE COLUMN name delivery_name VARCHAR(50) NOT NULL;

ALTER TABLE payment_methods
  CHANGE COLUMN name payment_name VARCHAR(50) NOT NULL;
