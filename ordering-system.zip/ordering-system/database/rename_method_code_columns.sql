-- Run once on an existing alyanah_db database after backing it up.
USE alyanah_db;

ALTER TABLE delivery_methods
  CHANGE COLUMN code delivery_code VARCHAR(20) NOT NULL;

ALTER TABLE payment_methods
  CHANGE COLUMN code payment_code VARCHAR(20) NOT NULL;
