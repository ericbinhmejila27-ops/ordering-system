<?php

echo "<h2>Database Extension Diagnostic</h2>\n";

echo "<h3>Available PHP Modules:</h3>\n";
$modules = get_loaded_extensions();
echo "<ul>\n";
foreach ($modules as $mod) {
    if (stripos($mod, 'mysql') !== false || stripos($mod, 'pdo') !== false) {
        echo "<li><strong>$mod</strong></li>\n";
    }
}
echo "</ul>\n";

echo "<h3>Database Classes Available:</h3>\n";
$classes = ['mysqli', 'PDO'];
foreach ($classes as $class) {
    $exists = class_exists($class);
    $status = $exists ? "✓ YES" : "✗ NO";
    echo "<p>$class: <strong style='color: " . ($exists ? "green" : "red") . ";'>$status</strong></p>\n";
}

echo "<h3>Test Connections:</h3>\n";

// Test PDO
echo "<h4>PDO MySQL Connection:</h4>\n";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=alyanah_db;charset=utf8mb4', 'root', '');
    $result = $pdo->query("SELECT COUNT(*) as total FROM users");
    $row = $result->fetch(PDO::FETCH_ASSOC);
    echo "<p style='color: green;'>✓ PDO Connection SUCCESS - Users in DB: " . $row['total'] . "</p>\n";
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ PDO Connection FAILED: " . $e->getMessage() . "</p>\n";
}

// Test MySQLi
echo "<h4>MySQLi Connection:</h4>\n";
if (class_exists('mysqli')) {
    try {
        $mysqli = new mysqli('localhost', 'root', '', 'alyanah_db');
        if ($mysqli->connect_error) {
            echo "<p style='color: red;'>✗ MySQLi FAILED: " . $mysqli->connect_error . "</p>\n";
        } else {
            echo "<p style='color: green;'>✓ MySQLi Connection SUCCESS</p>\n";
            $mysqli->close();
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>✗ MySQLi Exception: " . $e->getMessage() . "</p>\n";
    }
} else {
    echo "<p style='color: red;'>✗ MySQLi class not available</p>\n";
}

echo "<h3>PHP Configuration:</h3>\n";
echo "<p>PHP Version: " . phpversion() . "</p>\n";
echo "<p>Extension Dir: " . ini_get('extension_dir') . "</p>\n";

?>
