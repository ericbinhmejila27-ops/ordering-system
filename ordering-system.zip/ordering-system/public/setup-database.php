<?php

http_response_code(410);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Database setup moved</title>
</head>
<body>
  <h1>Database setup has moved</h1>
  <p>For a fresh install, import <code>database/alyanah_db.sql</code> in phpMyAdmin.</p>
  <p>To preserve an existing five-table database, run
    <code>C:\xampp\php\php.exe database\migrate.php</code> from the project directory.</p>
  <p>This page no longer imports or modifies database contents.</p>
</body>
</html>
