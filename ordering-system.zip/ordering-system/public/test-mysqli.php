<?php

echo "<h2>MySQLi Diagnostic Test</h2>\n";

// Check if MySQLi extension is loaded
echo "<h3>Extension Status:</h3>\n";
echo "<ul>\n";
echo "<li>MySQLi loaded: " . (extension_loaded('mysqli') ? "✓ YES" : "✗ NO") . "</li>\n";
echo "<li>PDO loaded: " . (extension_loaded('pdo') ? "✓ YES" : "✗ NO") . "</li>\n";
echo "<li>PDO MySQL: " . (extension_loaded('pdo_mysql') ? "✓ YES" : "✗ NO") . "</li>\n";
echo "</ul>\n";

// Test MySQLi constants
echo "<h3>MySQLi Constants:</h3>\n";
if (defined('MYSQLI_STORE_RESULT')) {
    echo "<p style='color: green;'>✓ MYSQLI_STORE_RESULT is defined</p>\n";
} else {
    echo "<p style='color: red;'>✗ MYSQLI_STORE_RESULT is NOT defined</p>\n";
}

// List available MySQLi constants
echo "<h3>Available MySQLi Constants:</h3>\n";
$constants = get_defined_constants();
$mysqliConstants = array_filter($constants, function($key) {
    return strpos($key, 'MYSQLI_') === 0;
}, ARRAY_FILTER_USE_KEY);

if (!empty($mysqliConstants)) {
    echo "<pre>";
    echo implode("\n", array_keys(array_slice($mysqliConstants, 0, 10)));
    echo "\n... and " . (count($mysqliConstants) - 10) . " more\n";
    echo "</pre>\n";
    echo "<p>Total MySQLi constants: " . count($mysqliConstants) . "</p>\n";
} else {
    echo "<p style='color: red;'>✗ No MySQLi constants found!</p>\n";
}

// Test direct MySQLi connection
echo "<h3>Direct MySQLi Connection Test:</h3>\n";
try {
    $mysqli = new mysqli('localhost', 'root', '', 'alyanah_db');
    if ($mysqli->connect_error) {
        echo "<p style='color: red;'>✗ Connection Error: " . $mysqli->connect_error . "</p>\n";
    } else {
        echo "<p style='color: green;'>✓ Connection successful</p>\n";
        $result = $mysqli->query("SELECT COUNT(*) as total FROM users");
        $row = $result->fetch_assoc();
        echo "<p>Users in database: " . $row['total'] . "</p>\n";
        $mysqli->close();
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>\n";
}

// Try PDO Connection as alternative
echo "<h3>PDO Connection Test (Alternative):</h3>\n";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=alyanah_db;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ PDO connection successful</p>\n";
    $result = $pdo->query("SELECT COUNT(*) as total FROM users");
    $row = $result->fetch(PDO::FETCH_ASSOC);
    echo "<p>Users in database: " . $row['total'] . "</p>\n";
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>\n";
}

// Display PHP info
echo "<h3>PHP Info:</h3>\n";
echo "<p>PHP Version: " . phpversion() . "</p>\n";
echo "<p>Loaded Extensions: " . implode(", ", get_loaded_extensions()) . "</p>\n";

?>
