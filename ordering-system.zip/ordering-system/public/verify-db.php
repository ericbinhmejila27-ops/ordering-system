<?php

// Test database connection and user registration functionality
ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO('mysql:host=localhost;dbname=alyanah_db;charset=utf8mb4', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<h2 style='color: green;'>✓ Database Connection: SUCCESS</h2>\n";
} catch (PDOException $e) {
    die("<h2 style='color: red;'>✗ Connection failed: " . $e->getMessage() . "</h2>");
}

echo "<h3>Users in Database:</h3>\n";
echo "<table border='1' cellpadding='10'>\n";
echo "<tr><th>Email</th><th>Name</th><th>Phone</th><th>Role</th><th>Created</th></tr>\n";

$stmt = $pdo->query("SELECT email, user_name AS name, phone, role, created_at FROM users ORDER BY created_at DESC");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
    echo "<td><strong>" . htmlspecialchars($row['role']) . "</strong></td>";
    echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
    echo "</tr>\n";
}
echo "</table>\n";

echo "<h3>Total Users: " . $stmt->rowCount() . "</h3>\n";

echo "<hr><h3>What was changed:</h3>";
echo "<ul>";
echo "<li><strong>Created UserModel.php</strong> - Database model for user operations</li>";
echo "<li><strong>Updated AuthController.php</strong> - Now saves new registrations to MySQL instead of JSON</li>";
echo "<li><strong>Database configured</strong> - Connected to alyanah_db with root user</li>";
echo "</ul>";

echo "<hr><h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Go to <a href='http://localhost/ordering-system/register'>/register</a></li>";
echo "<li>Create a new customer account</li>";
echo "<li>Refresh this page to see the new user in the database</li>";
echo "<li>Test login with the new account</li>";
echo "</ol>";

?>
